(function(){
 'use strict';
 const native=window.Capacitor;
 if(!native?.isNativePlatform?.())return;
 const plugin=native.Plugins?.ExteriorFiles||(typeof native.registerPlugin==='function'?native.registerPlugin('ExteriorFiles'):null);
 let ocupado=false,updateShown=false;
 function base64(blob){
  return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=()=>reject(r.error);r.readAsDataURL(blob);});
 }
 async function guardar(blob,nombre){
  if(!plugin)throw Error('El gestor de archivos de Android no está disponible.');
  if(ocupado)throw Error('Hay una descarga en curso.');
  ocupado=true;
  try{
   await plugin.begin({name:nombre,size:blob.size});
   const bloque=256*1024;
   for(let i=0;i<blob.size;i+=bloque){
    const data=await base64(blob.slice(i,Math.min(i+bloque,blob.size)));
    await plugin.append({data});
   }
   await plugin.finish();
  }catch(error){try{await plugin.abort();}catch(_){}throw error;}
  finally{ocupado=false;}
 }
 window.exteriorGuardarAndroid=guardar;
 document.addEventListener('click',event=>{
  const link=event.target.closest?.('a[download]');
  if(!link||!link.href.startsWith('blob:'))return;
  event.preventDefault();event.stopImmediatePropagation();
  const nombre=(link.getAttribute('download')||'Exterior.png').replace(/[\\/:*?"<>|]/g,'_');
  fetch(link.href).then(response=>response.blob()).then(blob=>guardar(blob,nombre)).catch(()=>{});
 },true);

 let local=Number(window.EXTERIOR_ANDROID_VERSION_CODE||1);
 const live=window.exteriorLivePlugin?.();
 const canInstall=Number(window.EXTERIOR_ANDROID_VERSION_CODE)>=47&&typeof plugin?.installUpdate==='function';
 const version=String(window.EXTERIOR_ANDROID_VERSION_NAME||local);
 const footer=document.querySelector('#osStage .os-stage-footer');
 if(!footer||!plugin?.checkRelease)return;
 const panel=document.createElement('section');
 panel.className='exterior-android-updates';
 panel.setAttribute('aria-label','Actualizaciones de Exterior');
 const title=document.createElement('strong');title.textContent='Actualizaciones';
 const installed=document.createElement('span');installed.textContent='Versión instalada: '+version;
 const status=document.createElement('p');status.setAttribute('role','status');status.setAttribute('aria-live','polite');status.textContent='Consultar si hay una nueva versión.';
 const progressBox=document.createElement('div');progressBox.className='and-update-progress';progressBox.hidden=true;
 const progressLabel=document.createElement('span');progressLabel.className='and-update-progress-label';
 const progressBar=document.createElement('progress');progressBar.max=100;progressBar.setAttribute('aria-label','Avance de la actualización');
 progressBox.append(progressLabel,progressBar);
 let progressKind='',busy=false;
 function beginProgress(kind){
  progressKind=kind;progressBox.hidden=false;progressBar.removeAttribute('value');progressLabel.textContent='Preparando descarga…';
 }
 function endProgress(){progressKind='';progressBox.hidden=true;}
 function reportProgress(kind,event){
  if(!busy||progressKind!==kind)return;
  const total=Number(event.total),written=Math.max(0,Number(event.written)||0);
  if(event.phase==='download'){
   if(total>0&&Number.isFinite(total)){const percent=Math.min(100,Math.floor(written*100/total));progressBar.value=percent;progressLabel.textContent='Descargando · '+percent+' %';}
   else{progressBar.removeAttribute('value');progressLabel.textContent='Descargando · '+(written/1048576).toFixed(1)+' MB';}
  }else{progressBar.removeAttribute('value');progressLabel.textContent=event.phase==='verify'?'Verificando integridad y firma…':event.phase==='prepare'?'Preparando recursos…':event.phase==='install'?'Abriendo el instalador de Android…':'Preparando actualización…';}
 }
 try{Promise.resolve(plugin.addListener?.('updateProgress',event=>reportProgress('apk',event))).catch(()=>{});}catch(_){}
 try{Promise.resolve(live?.addListener?.('updateProgress',event=>reportProgress('resources',event))).catch(()=>{});}catch(_){}
 const controls=document.createElement('div');controls.className='exterior-android-update-actions';
 const check=document.createElement('button');check.type='button';check.textContent='Buscar actualizaciones';
 const update=document.createElement('button');update.type='button';update.textContent='Descargar actualización';update.hidden=true;
 const restore=document.createElement('button');restore.type='button';restore.textContent='Recuperar versión anterior';restore.hidden=true;
 const restart=document.createElement('button');restart.type='button';restart.textContent='Reiniciar y aplicar';restart.hidden=true;
 controls.append(check,update,restart,restore);panel.append(title,installed,status,progressBox,controls);
 function hasEdition(){return document.querySelector('.and-nav [data-and-nav="editar"]:not([disabled])')!==null;}
 function allowRestart(){return !hasEdition()||window.confirm('La aplicación se reiniciará. Descargar o finalizar el arte antes de continuar. ¿Reiniciar de todos modos?');}
 function showRestore(){panel.dataset.andNews='true';status.textContent='Restauración preparada. Reiniciar Exterior para aplicarla.';restart.hidden=typeof live?.restart!=='function';}
 restart.addEventListener('click',async()=>{
  if(busy||!allowRestart())return;
  busy=true;restart.disabled=true;check.disabled=true;update.disabled=true;restore.disabled=true;
  status.textContent='Reiniciando Exterior…';
  try{await live.restart();}catch(_){status.textContent='No se pudo reiniciar automáticamente. Cerrar y volver a abrir Exterior.';}
  finally{busy=false;restart.disabled=false;check.disabled=false;update.disabled=false;restore.disabled=false;}
 });
 function showState(state){
  local=Number(state.binaryVersion||local);
  installed.textContent='Aplicación: 1.0.'+local+' · Recursos: 1.0.'+Number(state.contentVersion||local);
  const label=document.getElementById('andVersion');if(label)label.textContent='1.0.'+local;
  const resourceLabel=document.getElementById('andResourcesVersion');if(resourceLabel)resourceLabel.textContent='1.0.'+Number(state.contentVersion||local);
  restore.hidden=!state.canRestore;
 }
 function showPending(state){
  panel.dataset.andNews='true';
  const canRestart=typeof live?.restart==='function';
  status.textContent='Recursos 1.0.'+state.pendingVersion+' preparados. '+(canRestart?'Reiniciar Exterior para aplicar la actualización.':'Finalizar la edición y volver a abrir Exterior.');
  restart.hidden=!canRestart;
  check.textContent='Buscar actualizaciones';
 }
 if(live?.info)live.info().then(state=>{showState(state);if(state.restoreRequested)showRestore();else if(state.pendingVersion>0)showPending(state);}).catch(()=>{});
 footer.insertBefore(panel,footer.querySelector('.ux-home-guide'));
 let checking=false,latest=null,lastCheck=0,noticeVersion=0;
 async function comprobar(manual=false){
  if(busy||checking||update.disabled||restore.disabled||(!manual&&Date.now()-lastCheck<60000))return;
  checking=true;lastCheck=Date.now();check.disabled=true;update.hidden=true;restart.hidden=true;latest=null;panel.dataset.andNews='false';
  status.textContent='Buscando actualizaciones…';
  let pending=null;
  try{
   if(live){
    const state=await live.info();showState(state);
    if(state.restoreRequested){showRestore();return;}
    if(state.pendingVersion>0)pending=state;
    const resource=await live.check();showState(resource);
    if(resource.available===true){
     latest={...resource,kind:'resources'};panel.dataset.andNews='true';
     status.textContent='Recursos 1.0.'+resource.versionCode+' disponibles ('+Math.ceil(Number(resource.size)/1048576)+' MB). Incluyen las mejoras anteriores. No requieren instalar una APK.';
     update.textContent='Preparar actualización interna';update.hidden=false;
     if(!manual)check.textContent='Nueva versión disponible';
     return;
    }
    if(!resource.requiresApk){
     if(pending){showPending(pending);return;}
     status.textContent=state.failedVersion>0?'Se recuperó una versión anterior. Se esperará una nueva publicación compatible.':'Exterior está actualizado.';
     return;
    }
   }
   const data=await plugin.checkRelease();
   if(data?.available===true&&Number(data.versionCode)>local&&typeof data.apkUrl==='string'&&data.apkUrl){
    latest={...data,kind:'apk'};panel.dataset.andNews='true';update.textContent=canInstall?'Instalar actualización':'Descargar actualización';status.textContent='Versión '+String(data.versionName||data.versionCode)+' disponible.'+(canInstall?' Android solicitará confirmar la instalación.':live?' Requiere actualizar la aplicación Android.':'');
    update.hidden=false;
    if(!manual&&noticeVersion!==Number(data.versionCode)&&!document.getElementById('osStage')?.hidden){
     noticeVersion=Number(data.versionCode);check.textContent='Nueva versión disponible';
    }
   }else if(data?.published===true&&data?.signed===true&&data?.compatible===false){
    status.textContent='La firma ha cambiado. Descargar Exterior desde la página web y reinstalar si Android lo solicita.';
   }else if(data?.published===true&&data?.signed===true&&data?.compatible===true&&Number(data.versionCode)===local){
    status.textContent='Exterior está actualizado.';
   }else if(data?.published===true&&data?.signed!==true){
    status.textContent='La firma de distribución aún no está disponible.';
   }else{
    status.textContent='No hay una actualización compatible disponible.';
   }
  }catch(_){if(pending)showPending(pending);else status.textContent=live?'No se pudo verificar la actualización. Se conserva la versión actual.':'No se pudo consultar. Volver a intentar cuando haya conexión.';}
  finally{checking=false;check.disabled=false;if(check.textContent!=='Nueva versión disponible'||!latest)check.textContent='Buscar actualizaciones';}
 }
 check.addEventListener('click',()=>{check.textContent='Buscar actualizaciones';comprobar(true);});
 update.addEventListener('click',async()=>{
  if(!latest||busy)return;
  if(latest.kind==='apk'&&!allowRestart())return;
  busy=true;update.disabled=true;check.disabled=true;restore.disabled=true;restart.disabled=true;
  try{
   if(latest.kind==='resources'){
    status.textContent='Consultando la versión más reciente…';
    const current=await live.check();
    if(!current.available){
     if(current.pendingVersion>0&&!current.requiresApk){showState(current);showPending(current);latest=null;update.hidden=true;return;}
     throw Error('La publicación cambió.');
    }
    status.textContent='Descargando y verificando recursos 1.0.'+current.versionCode+'…';
    beginProgress('resources');
    const state=await live.download({versionCode:Number(current.versionCode)});
    showState(state);showPending(state);latest=null;update.hidden=true;
   }else if(canInstall){
    status.textContent='Descargando y verificando la aplicación…';beginProgress('apk');
    const result=await plugin.installUpdate({versionCode:Number(latest.versionCode)});
    if(result.permissionRequired){
     status.textContent='Autorizar la instalación de aplicaciones desde Exterior en Ajustes de Android. Regresar y seleccionar Instalar actualización.';
    }else if(result.installerOpened){
     status.textContent='Confirmar la actualización en el instalador de Android. Al finalizar, seleccionar Abrir.';
    }else throw Error('No se abrió el instalador.');
   }else{await plugin.openUpdate({url:latest.apkUrl});status.textContent='Continuar la instalación desde Android.';}
  }
  catch(error){
   const details={APK_MANIFEST:'No se pudo verificar la publicación de la aplicación.',APK_VERSION:'La versión solicitada no es válida.',APK_BUSY:'Ya hay una actualización en curso.',APK_PERMISSION:'No se pudo abrir el permiso de instalación.',APK_STORAGE:'Comprobar el espacio disponible en el dispositivo.',APK_DOWNLOAD:'No se completó la descarga de la aplicación.',APK_INTEGRITY:'La aplicación no superó la verificación de integridad y firma.',APK_INSTALL:'No se pudo abrir el instalador de Android.',UPDATE_MANIFEST:'No se pudo verificar la publicación.',UPDATE_VERSION:'La publicación cambió. Consultar la versión más reciente.',UPDATE_STORAGE:'Comprobar el espacio disponible en el dispositivo.',UPDATE_DOWNLOAD:'No se completó la descarga. Comprobar la conexión.',UPDATE_INTEGRITY:'La descarga no superó la verificación de integridad.',UPDATE_EXTRACTION:'No se pudieron extraer los recursos.',UPDATE_STAGING:'No se pudieron preparar los recursos en el dispositivo.'};
   status.textContent=(details[error?.code]||'No se pudo preparar la actualización.')+' Se conserva la versión actual.';
  }
  finally{endProgress();busy=false;update.disabled=false;check.disabled=false;restore.disabled=false;restart.disabled=false;}
 });
 restore.addEventListener('click',async()=>{
  if(!live||!window.confirm('¿Recuperar la versión anterior de los recursos al volver a abrir Exterior?'))return;
  check.disabled=true;update.disabled=true;restore.disabled=true;
  try{await live.restore();latest=null;update.hidden=true;showRestore();}
  catch(_){status.textContent='No se pudo preparar la restauración.';}
  finally{check.disabled=false;update.disabled=false;restore.disabled=false;}
 });
 // Comprobar sin interrumpir el arte que se está editando.
 setTimeout(()=>comprobar(),2200);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)comprobar();});
})();
