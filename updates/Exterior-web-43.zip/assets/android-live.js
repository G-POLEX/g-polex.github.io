(function(){
 'use strict';
 let failed=false;
 // A resource error or uncaught startup error prevents acknowledgment of a new bundle.
 window.addEventListener('error',event=>{
  const tag=event.target?.tagName;
  if(event instanceof ErrorEvent||tag==='SCRIPT'||tag==='LINK')failed=true;
 },true);
 window.addEventListener('unhandledrejection',()=>{failed=true;});
 window.exteriorLivePlugin=function(){
  const native=window.Capacitor;
  if(!native?.isNativePlatform?.())return null;
  if(native.isPluginAvailable&&!native.isPluginAvailable('ExteriorUpdates'))return null;
  return native.Plugins?.ExteriorUpdates||(native.isPluginAvailable?.('ExteriorUpdates')?native.registerPlugin('ExteriorUpdates'):null);
 };
 window.addEventListener('load',()=>{
  const plugin=window.exteriorLivePlugin();if(!plugin?.ready)return;
  const started=Date.now();
  function acknowledge(){
   if(failed)return;
   const ready=document.documentElement.classList.contains('and-ui-ready')&&
    document.querySelectorAll('#osFamilyList button[data-os-family]').length===8&&
    typeof window.exteriorGuardarAndroid==='function'&&typeof abrirEntradaCatalogo==='function';
   if(ready){
    plugin.ready({versionCode:Number(window.EXTERIOR_ANDROID_VERSION_CODE)}).catch(()=>{});
   }else if(Date.now()-started<30000)setTimeout(acknowledge,150);
  }
  setTimeout(acknowledge,500);
 },{once:true});
})();
