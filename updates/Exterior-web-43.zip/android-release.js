window.EXTERIOR_ANDROID_RELEASE = {"available":false,"versionCode":0,"versionName":"","apkUrl":"https://g-polex.github.io/downloads/Exterior-1.0.0.apk","minimumAndroid":29,"signed":false};
