/* Exterior Android: navegación de aplicación. No interviene en el render ni en la exportación. */
(function(){
 'use strict';
 if(!document.documentElement.classList.contains('exterior-native'))return;
 const $=id=>document.getElementById(id);
 const stage=$('osStage'), main=document.querySelector('main.exterior'), map=$('mapaGenerador'), layout=document.querySelector('.exterior-layout'), editor=document.querySelector('.exterior-editor');
 if(!stage||!main||!map||!layout||!editor)return;
 const root=document.documentElement;
 const icons={
  ayuda:'<circle cx="12" cy="12" r="9"/><path d="M9 9a3 3 0 1 1 4 3c-1 .5-1 1-1 2m0 3h.01"/>',
  novedades:'<path d="M18 8a6 6 0 0 0-12 0c0 6-2 7-2 9h16c0-2-2-3-2-9m-8 12a2 2 0 0 0 4 0"/>',
  inicio:'<path d="m3 10 9-7 9 7v11h-6v-7H9v7H3z"/>',
  paleta:'<path d="M12 3a9 9 0 1 0 0 18h1.2a2 2 0 0 0 1.5-3.3 1.5 1.5 0 0 1 1.1-2.5H18a3 3 0 0 0 3-3A9 9 0 0 0 12 3Z"/><circle cx="7.5" cy="10" r=".8"/><circle cx="11" cy="7" r=".8"/><circle cx="16" cy="8" r=".8"/>',
  buscar:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  reciente:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  atras:'<path d="m14 5-7 7 7 7M7 12h14"/>',
  cerrar:'<path d="m6 6 12 12M18 6 6 18"/>',
  crear:'<path d="M12 5v14M5 12h14"/>',
  editar:'<path d="M12 20H4v-8l10-10 8 8-10 10zM12 4l8 8"/>',
  ajustes:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2"/><circle cx="12" cy="12" r="8"/>',
  documento:'<path d="M6 3h8l4 4v14H6zM14 3v5h4M9 12h6m-6 4h6"/>',
  calendario:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4m10-4v4M3 10h18m-13 5h2m4 0h2"/>',
  aviso:'<path d="M3 10v4h4l11 5V5L7 10zM7 14l2 6h3"/>',
  consular:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c5 5 5 13 0 18m0-18c-5 5-5 13 0 18"/>',
  interno:'<rect x="3" y="5" width="18" height="15" rx="2"/><path d="m3 7 9 7 9-7"/>',
  sede:'<path d="M3 21h18M5 21V8l7-5 7 5v13M9 12h6m-6 4h6"/>',
  otros:'<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="8" cy="11" r="2"/><path d="M5 16c1-3 5-3 6 0m3-6h4m-4 4h4"/>'
 };
 const svg=k=>'<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">'+icons[k]+'</svg>';
 const nav=document.createElement('nav');nav.className='and-nav';nav.setAttribute('aria-label','Navegación de Exterior');
 const labels={inicio:'Inicio',buscar:'Buscar',crear:'Crear',editar:'Edición',ajustes:'Ajustes'};
 for(const [key,label] of Object.entries(labels)){
  const b=document.createElement('button');b.type='button';b.dataset.andNav=key;b.innerHTML='<span class="and-nav-icon">'+svg(key)+'</span><span>'+label+'</span>';nav.append(b);
 }
 document.body.append(nav);
 // Usar el alto real (incluida la zona segura), también al rotar o abrir el teclado.
 const measureNav=()=>root.style.setProperty('--and-nav-occupied',nav.getBoundingClientRect().height+'px');
 new ResizeObserver(measureNav).observe(nav);measureNav();
 // Inicio deja de ser modal: la navegación inferior también es accesible.
 stage.setAttribute('role','region');stage.removeAttribute('aria-modal');
 // Preferencias locales: sólo afectan la interfaz de Android.
 const prefKey='exterior.android.preferences.v1';
 const preferences={history:true,motion:true,guide:true};
 try{const stored=JSON.parse(localStorage.getItem(prefKey)||'{}');for(const k of Object.keys(preferences))if(typeof stored?.[k]==='boolean')preferences[k]=stored[k];}catch(_){}
 function applyPreferences(){
  root.classList.toggle('and-reduce-motion',!preferences.motion);
  const guide=stage.querySelector('.and-first-help');if(guide)guide.hidden=!preferences.guide;
 }
 function savePreferences(){try{localStorage.setItem(prefKey,JSON.stringify(preferences));}catch(_){}applyPreferences();}
 const settings=document.createElement('dialog');settings.className='and-settings';settings.setAttribute('aria-labelledby','andSettingsTitle');
 settings.innerHTML='<header><button type="button" data-and-close aria-label="Cerrar ajustes">‹</button><h2 id="andSettingsTitle">Ajustes</h2></header><div class="and-settings-body"><section class="and-settings-card"><h3>Preferencias de uso</h3><label class="and-preference"><span><strong>Animaciones de navegación</strong><small>Activar transiciones entre pantallas.</small></span><input type="checkbox" data-and-pref="motion" role="switch"></label><label class="and-preference"><span><strong>Guía en Inicio</strong><small>Mostrar el acceso a la guía de uso.</small></span><input type="checkbox" data-and-pref="guide" role="switch"></label></section><section class="and-settings-card"><h3>Búsqueda y privacidad</h3><label class="and-preference"><span><strong>Guardar búsquedas recientes</strong><small>Conservar consultas en este dispositivo. Desactivar elimina el historial.</small></span><input type="checkbox" data-and-pref="history" role="switch"></label><button type="button" class="and-setting-action" data-and-clear-history>Borrar historial de búsqueda</button><p class="and-pref-status" role="status"></p></section><section class="and-settings-card"><h3>Archivos exportados</h3><p>Consultar los artes en Descargas/Exterior del dispositivo.</p></section><section class="and-settings-card"><h3>Acerca de Exterior</h3><p>Aplicación: <strong id="andVersion"></strong></p><p>Recursos: <strong id="andResourcesVersion"></strong></p><p>Ministerio de Relaciones Exteriores</p></section></div>';
 document.body.append(settings);
 $('andVersion').textContent=String(window.EXTERIOR_ANDROID_VERSION_NAME||'');
 $('andResourcesVersion').textContent=String(window.EXTERIOR_ANDROID_VERSION_NAME||'');
 const news=document.createElement('dialog');news.className='and-news';news.setAttribute('aria-labelledby','andNewsTitle');
 news.innerHTML='<header><button type="button" data-and-news-close aria-label="Cerrar novedades">'+svg('atras')+'</button><h2 id="andNewsTitle">Novedades</h2></header><div class="and-news-body"><div id="andUpdateSlot"></div><section class="and-settings-card"><p class="and-kicker">Mejoras incorporadas</p><h3>Exterior</h3><div class="and-news-entry"><strong>Búsqueda de plantillas</strong><p>Consultar resultados al escribir y recuperar búsquedas recientes.</p></div><div class="and-news-entry"><strong>Inicio y navegación</strong><p>Acceder al catálogo, retomar una edición y consultar la guía de uso.</p></div><div class="and-news-entry"><strong>Actualizaciones acumulativas</strong><p>Preparar la última versión compatible de los recursos sin instalar versiones intermedias.</p></div><div class="and-news-entry"><strong>Preferencias de uso</strong><p>Configurar el historial de búsqueda, las animaciones y la guía en Inicio.</p></div></section></div>';
 document.body.append(news);
 const updates=document.querySelector('.exterior-android-updates');
 if(updates)$('andUpdateSlot').append(updates);
 else $('andUpdateSlot').textContent='El servicio de actualizaciones no está disponible en este momento.';
 news.querySelector('[data-and-news-close]').addEventListener('click',()=>news.close());
 const steps=document.createElement('div');steps.className='and-steps';steps.setAttribute('role','group');steps.setAttribute('aria-label','Etapas de edición');
 for(const [key,label] of [['form','Formulario'],['preview','Vista previa'],['export','Exportar']]){
  const b=document.createElement('button');b.type='button';b.dataset.andStep=key;b.textContent=label;b.setAttribute('aria-pressed',String(key==='form'));steps.append(b);
 }
 layout.prepend(steps);
 let mode='form',savedEditor=null,resuming=false,homeScroll=0,restoreFrame=0;
 // Búsqueda independiente: consulta el mismo índice del catálogo y conserva la pantalla de origen.
 const searchScreen=document.createElement('section');
 searchScreen.className='and-search-screen';searchScreen.hidden=true;searchScreen.setAttribute('aria-label','Buscar plantillas');
 searchScreen.innerHTML='<header class="and-search-header"><button type="button" data-and-search-back aria-label="Volver">'+svg('atras')+'</button><form class="and-search-form" role="search"><span aria-hidden="true">'+svg('buscar')+'</span><input id="andSearchInput" type="search" aria-label="Buscar plantillas" placeholder="Buscar por tema o nombre" autocomplete="off" enterkeyhint="search" maxlength="120"><button type="button" data-and-search-clear aria-label="Limpiar búsqueda" hidden>'+svg('cerrar')+'</button></form></header><div class="and-search-content"><div class="and-search-heading"><h2></h2><div class="and-search-tools"><button type="button" data-and-search-all>Ver todo</button><button type="button" data-and-search-delete>Borrar todo</button></div></div><p class="and-search-status" role="status" aria-live="polite"></p><div class="and-search-list"></div></div>';
 document.body.append(searchScreen);
 const searchInput=$('andSearchInput'),searchList=searchScreen.querySelector('.and-search-list'),searchStatus=searchScreen.querySelector('.and-search-status');
 const searchHeading=searchScreen.querySelector('h2'),searchAll=searchScreen.querySelector('[data-and-search-all]'),searchDelete=searchScreen.querySelector('[data-and-search-delete]'),searchClear=searchScreen.querySelector('[data-and-search-clear]');
 const historyKey='exterior.android.recent-searches.v1',historyLimit=20;
 const queryKey=q=>q.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('es').trim().replace(/\s+/g,' ');
 const tidy=q=>String(q||'').trim().replace(/\s+/g,' ').slice(0,120);
 let recent=[],showAll=false,searchOrigin=null;
 try{
  const stored=JSON.parse(localStorage.getItem(historyKey)||'[]');
  if(Array.isArray(stored))recent=stored.filter(q=>typeof q==='string'&&tidy(q)).map(tidy).filter((q,i,a)=>a.findIndex(x=>queryKey(x)===queryKey(q))===i).slice(0,historyLimit);
 }catch(_){}
 if(!preferences.history)recent=[];
 function persistRecent(){try{localStorage.setItem(historyKey,JSON.stringify(recent));}catch(_){}}
 function rememberQuery(value){
  const q=tidy(value);if(!q||!preferences.history)return;
  recent=[q,...recent.filter(x=>queryKey(x)!==queryKey(q))].slice(0,historyLimit);persistRecent();
 }
 function clearRecent(){recent=[];persistRecent();showAll=false;if(!searchScreen.hidden)renderSearch();}
 const prefStatus=settings.querySelector('.and-pref-status');
 const clearHistory=settings.querySelector('[data-and-clear-history]');
 for(const control of settings.querySelectorAll('[data-and-pref]')){
  const key=control.dataset.andPref;control.checked=preferences[key];
  control.addEventListener('change',()=>{
   preferences[key]=control.checked;savePreferences();
   if(key==='history'&&!preferences.history)clearRecent();
   clearHistory.disabled=!preferences.history;
   prefStatus.textContent=key==='history'&&!preferences.history?'Historial eliminado.':'';
  });
 }
 clearHistory.disabled=!preferences.history;
 clearHistory.addEventListener('click',()=>{if(window.confirm('¿Borrar todas las búsquedas recientes?')){clearRecent();prefStatus.textContent='Historial eliminado.';}});
 function catalogResults(q){
  // El motor existente es la única fuente de coincidencias. Restaurar el filtro previo antes de regresar.
  const field=$('buscarPlantillas'),previous=field.value;
  try{
   field.value=q;field.dispatchEvent(new Event('input',{bubbles:true}));
   return [...$('resultadosPlantillas').querySelectorAll(':scope > button')].map((b,index)=>({
    index,name:b.querySelector('strong')?.textContent.trim()||b.textContent.trim(),
    detail:b.querySelector('small')?.textContent.trim()||''
   }));
  }finally{field.value=previous;field.dispatchEvent(new Event('input',{bubbles:true}));}
 }
 function searchRow(icon,name,detail,action,remove){
  const row=document.createElement('div');row.className='and-search-row';
  const button=document.createElement('button');button.type='button';button.className='and-search-result';
  const mark=document.createElement('span');mark.className='and-search-mark';mark.innerHTML=svg(icon);
  const words=document.createElement('span');words.className='and-search-words';const title=document.createElement('strong');title.textContent=name;words.append(title);
  if(detail){const sub=document.createElement('small');sub.textContent=detail;words.append(sub);}
  button.append(mark,words);button.addEventListener('click',action);row.append(button);
  if(remove){
   const del=document.createElement('button');del.type='button';del.className='and-search-remove';del.setAttribute('aria-label','Eliminar búsqueda '+name);del.innerHTML=svg('cerrar');
   del.addEventListener('click',remove);row.append(del);
  }
  searchList.append(row);return button;
 }
 function renderSearch(){
  const q=tidy(searchInput.value);searchClear.hidden=!searchInput.value;searchList.replaceChildren();
  searchAll.hidden=!!q||recent.length<=6;searchDelete.hidden=!!q||recent.length===0;
  if(!q){
   searchHeading.textContent='Recientes';searchAll.textContent=showAll?'Ver menos':'Ver todo';
   searchStatus.textContent=preferences.history?(recent.length?'':'No hay búsquedas recientes.'):'El historial de búsqueda está desactivado.';
   for(const value of recent.slice(0,showAll?historyLimit:6))searchRow('reciente',value,'',()=>{
    searchInput.value=value;renderSearch();searchInput.focus({preventScroll:true});
   },()=>{recent=recent.filter(x=>queryKey(x)!==queryKey(value));persistRecent();renderSearch();});
   return;
  }
  searchHeading.textContent='Resultados';
  const results=catalogResults(q);
  searchStatus.textContent=results.length?(results.length===1?'1 resultado':results.length+' resultados'):'No se encontraron plantillas.';
  for(const result of results)searchRow('documento',result.name,result.detail,()=>chooseResult(q,result));
 }
 function openSearch(initial=''){
  if(!searchScreen.hidden){searchInput.focus({preventScroll:true});return;}
  closeSettings();searchOrigin={stageInert:stage.inert,mainInert:main.inert,stageTop:stage.scrollTop,top:window.scrollY,left:window.scrollX};
  stage.inert=true;main.inert=true;searchScreen.hidden=false;root.classList.add('and-searching');
  showAll=false;searchInput.value=tidy(initial);renderSearch();searchScreen.querySelector('.and-search-content').scrollTop=0;
  sync();searchInput.focus({preventScroll:true});
 }
 function closeSearch(){
  if(searchScreen.hidden)return;
  searchInput.blur();searchScreen.hidden=true;root.classList.remove('and-searching');
  if(searchOrigin){
   stage.inert=searchOrigin.stageInert;main.inert=searchOrigin.mainInert;
   stage.scrollTop=searchOrigin.stageTop;window.scrollTo({top:searchOrigin.top,left:searchOrigin.left,behavior:'instant'});
  }
  searchOrigin=null;sync();
 }
 function chooseResult(q,result){
  rememberQuery(q);closeSearch();saveEditor();
  if(!stage.hidden){homeScroll=stage.scrollTop;stage.querySelector('[data-os-action="map"]').click();}
  else if(map.hidden)$('abrirMapa').click();
  else if(typeof cerrarSubmenuSede==='function')cerrarSubmenuSede();
  const field=$('buscarPlantillas');field.value=q;field.dispatchEvent(new Event('input',{bubbles:true}));
  const options=[...$('resultadosPlantillas').querySelectorAll(':scope > button')];
  const match=options.find(b=>(b.querySelector('strong')?.textContent.trim()||b.textContent.trim())===result.name&&(b.querySelector('small')?.textContent.trim()||'')===result.detail)||options[result.index];
  match?.click();sync();
 }
 searchInput.addEventListener('input',renderSearch);
 searchScreen.querySelector('form').addEventListener('submit',e=>{
  e.preventDefault();const q=tidy(searchInput.value);if(!q)return;
  rememberQuery(q);const results=catalogResults(q);
  if(results.length===1)chooseResult(q,results[0]);else{renderSearch();searchInput.blur();}
 });
 searchScreen.querySelector('[data-and-search-back]').addEventListener('click',closeSearch);
 searchClear.addEventListener('click',()=>{searchInput.value='';renderSearch();searchInput.focus({preventScroll:true});});
 searchAll.addEventListener('click',()=>{showAll=!showAll;renderSearch();});
 searchDelete.addEventListener('click',()=>{if(window.confirm('¿Borrar todas las búsquedas recientes?')){recent=[];persistRecent();showAll=false;renderSearch();}});
 searchScreen.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closeSearch();}});
 // El buscador de Inicio utiliza el mismo espacio sin alterar el catálogo web.
 $('osHomeSearch').addEventListener('focus',()=>{if(searchScreen.hidden)openSearch($('osHomeSearch').value);});
 // Guardar sólo la posición y etapa de la edición; los datos siguen en el motor.
 const editorPosition=()=>({mode,top:window.scrollY,left:window.scrollX});
 const saveEditor=()=>{if(inEditor())savedEditor=editorPosition();};
 function restoreEditor(){
  if(!inEditor())return;
  const saved=savedEditor;savedEditor=null;
  if(!saved)return;
  resuming=true;setMode(saved.mode,true);
  cancelAnimationFrame(restoreFrame);
  const start=performance.now();let stable=0,previousHeight=-1;
  const stop=()=>{cancelAnimationFrame(restoreFrame);document.removeEventListener('pointerdown',stop,true);document.removeEventListener('wheel',stop,true);document.removeEventListener('touchstart',stop,true);};
  function frame(now){
   if(!inEditor()||mode!==saved.mode){stop();return;}
   const height=document.scrollingElement.scrollHeight;
   if(Math.abs(window.scrollY-saved.top)>1||Math.abs(window.scrollX-saved.left)>1)window.scrollTo({top:saved.top,left:saved.left,behavior:'instant'});
   stable=height===previousHeight?stable+1:0;previousHeight=height;
   if((stable>=8&&out.getAttribute('aria-busy')!=='true')||now-start>4000){stop();return;}
   restoreFrame=requestAnimationFrame(frame);
  }
  for(const event of ['pointerdown','wheel','touchstart'])document.addEventListener(event,stop,{capture:true,passive:true});
  restoreFrame=requestAnimationFrame(frame);
 }
 function finishResume(){requestAnimationFrame(()=>{if(inEditor())restoreEditor();resuming=false;sync();});}
 stage.addEventListener('click',()=>{if(!stage.hidden)homeScroll=stage.scrollTop;},true);
 function goHome(){
  saveEditor();closeSettings();
  if(stage.hidden){$('osHomeHeader').click();requestAnimationFrame(()=>{if(!stage.hidden)stage.scrollTop=homeScroll;});}
  sync();
 }
 const inEditor=()=>stage.hidden&&map.hidden&&!layout.hidden;
 // Reutilizar las acciones reales del motor; no duplicar paletas ni estado.
 const originalPalette=$('sedePaletaAleatoria'),originalUndo=$('sedePaletaDeshacer'),out=$('out');
 const paletteBar=document.createElement('div');paletteBar.className='and-palette-bar';paletteBar.hidden=true;
 const random=document.createElement('button');random.type='button';random.className='and-palette-random';random.innerHTML=svg('paleta')+'<span>Colores aleatorios</span>';
 const undo=document.createElement('button');undo.type='button';undo.className='and-palette-undo';undo.textContent='Deshacer';undo.setAttribute('aria-label','Deshacer combinación de colores');
 paletteBar.append(random,undo);out.before(paletteBar);
 const paletteAvailable=()=>inEditor()&&mode==='preview'&&$('m').value==='sede'&&$('sedeDiseno').value==='oficinas'&&!$('sedePanelColores').hidden&&!originalPalette.hidden;
 function syncPalette(){const available=paletteAvailable(),busy=out.getAttribute('aria-busy')==='true';paletteBar.hidden=!available;random.disabled=!available||busy||originalPalette.disabled;undo.disabled=!available||busy||originalUndo.hidden||originalUndo.disabled;}
 // La regeneración puede vaciar temporalmente #out y reducir la altura del
 // documento. Mantener su espacio y el scroll hasta que terminen los lienzos.
 let paletteScroll=null;
 function runPaletteAction(action){
  paletteScroll?.cancel();
  const scrolling=document.scrollingElement||root;
  const positions=[{el:scrolling,top:scrolling.scrollTop,left:scrolling.scrollLeft}];
  for(let el=out.parentElement;el&&el!==scrolling;el=el.parentElement){
   if(el.scrollTop||el.scrollLeft||(/auto|scroll/.test(getComputedStyle(el).overflowY)&&el.scrollHeight>el.clientHeight))positions.push({el,top:el.scrollTop,left:el.scrollLeft});
  }
  const height=out.style.getPropertyValue('min-height'),priority=out.style.getPropertyPriority('min-height');
  const minHeight=Math.max(out.getBoundingClientRect().height,parseFloat(getComputedStyle(out).minHeight)||0);
  out.style.setProperty('min-height',Math.ceil(minHeight)+'px');
  paletteBar.dataset.andPaletteRendering='true';
  const started=performance.now();let lastChange=started,frame=0,closed=false;
  const changes=new MutationObserver(()=>{lastChange=performance.now();});
  changes.observe(out,{childList:true,subtree:true,attributes:true,attributeFilter:['src','aria-busy']});
  const restore=()=>{
   if(!paletteAvailable())return;
   for(const {el,top,left} of positions){
    if(Math.abs(el.scrollTop-top)>0.5||Math.abs(el.scrollLeft-left)>0.5)el.scrollTo({top,left,behavior:'instant'});
   }
  };
  function cleanup(preserve){
   if(closed)return;closed=true;cancelAnimationFrame(frame);changes.disconnect();
   document.removeEventListener('pointerdown',interrupt,true);
   document.removeEventListener('touchstart',interrupt,true);
   document.removeEventListener('wheel',interrupt,true);
   document.removeEventListener('keydown',interrupt,true);
   if(height)out.style.setProperty('min-height',height,priority);else out.style.removeProperty('min-height');
   if(preserve)restore();
   delete paletteBar.dataset.andPaletteRendering;
   if(paletteScroll===operation)paletteScroll=null;
  }
  function interrupt(e){
   if(e.type==='keydown'&&!['ArrowDown','ArrowUp','PageDown','PageUp','Home','End',' '].includes(e.key))return;
   if(paletteBar.contains(e.target))return;
   cleanup(false);
  }
  function tick(now){
   if(closed)return;
   if(!paletteAvailable()){cleanup(false);return;}
   restore();
   const busy=out.getAttribute('aria-busy')==='true';
   const loaded=Array.from(out.querySelectorAll('img')).every(img=>img.complete);
   if((!busy&&loaded&&now-lastChange>=400)||now-started>=15000){cleanup(true);return;}
   frame=requestAnimationFrame(tick);
  }
  const operation={cancel:()=>cleanup(false)};paletteScroll=operation;
  for(const event of ['pointerdown','touchstart','wheel','keydown'])document.addEventListener(event,interrupt,{capture:true,passive:true});
  try{action.click();syncPalette();restore();frame=requestAnimationFrame(tick);}
  catch(error){cleanup(true);throw error;}
 }
 random.addEventListener('click',()=>{if(!random.disabled&&paletteAvailable())runPaletteAction(originalPalette);});
 undo.addEventListener('click',()=>{if(!undo.disabled&&paletteAvailable())runPaletteAction(originalUndo);});
 const paletteObserver=new MutationObserver(syncPalette);
 for(const el of [originalPalette,originalUndo,$('sedePanelColores'),out,stage,map,layout])paletteObserver.observe(el,{attributes:true,attributeFilter:['hidden','disabled','aria-busy']});
 document.addEventListener('change',()=>queueMicrotask(syncPalette));
 document.addEventListener('input',()=>queueMicrotask(syncPalette));
 const resumeAvailable=()=>!$('osContinue')?.hidden||(!$('cerrarMapa')?.hidden)||inEditor();
 const setMode=(next,focus=false)=>{
  mode=next;root.dataset.andEditor=mode;syncPalette();
  for(const b of steps.children)b.setAttribute('aria-pressed',String(b.dataset.andStep===mode));
  if(!inEditor()||!focus)return;
  const pdf=!$('proy').hidden;
  if(mode==='form')$('uxEdit').click();
  else if(mode==='preview')$('uxPreview').click();
  else{
   // Mantener las opciones reales de exportación y sus validaciones.
   $('uxPreview').click();
   requestAnimationFrame(()=>{
    const target=pdf?$('proyDownload'):document.querySelector('#out figure button:not([disabled])')||document.querySelector('.exterior-descargas');
    target?.scrollIntoView({block:'center',behavior:'auto'});
    target?.focus({preventScroll:true});
   });
  }
 };
 function sync(){
  const searching=[$('osHomeSearch'),$('buscarPlantillas')].includes(document.activeElement);
  const active=!searchScreen.hidden?'buscar':settings.open?'ajustes':searching?'buscar':!stage.hidden?'inicio':!map.hidden?'crear':'editar';
  for(const b of nav.children){
   if(b.dataset.andNav===active)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');
   b.disabled=b.dataset.andNav==='editar'&&!resumeAvailable();
  }
  root.classList.toggle('and-editing',inEditor());syncPalette();
 }
 function closeSettings(){if(settings.open){settings.close();stage.inert=false;main.inert=false;sync();}}
 function openSettings(){if(!settings.open){settings.show();stage.inert=true;main.inert=true;sync();}}
 settings.addEventListener('close',()=>{stage.inert=false;main.inert=false;sync();});
 settings.querySelector('[data-and-close]').addEventListener('click',closeSettings);
 const help=document.createElement('dialog');help.className='and-help';help.setAttribute('aria-labelledby','andHelpTitle');
 help.innerHTML='<header><h2 id="andHelpTitle">Ayuda</h2><button type="button" data-and-help-close aria-label="Cerrar ayuda">×</button></header><p></p>';
 document.body.append(help);
 help.querySelector('button').addEventListener('click',()=>help.close());
 function openHelp(){
  const description=!stage.hidden?'Elegir una plantilla desde los accesos rápidos o el catálogo. Para retomar un arte, seleccionar Continuar edición.':
    !map.hidden?'Buscar por nombre o seleccionar una categoría. Elegir la variante que corresponda al arte.':
    mode==='form'?'Completar los campos de la plantilla. Revisar el resultado en Vista previa.':
    mode==='preview'?'Comprobar la composición y el contenido del arte. Regresar al formulario para modificar la información.':
    'Seleccionar el formato disponible y descargar el arte. Los archivos se guardan en Descargas/Exterior.';
  help.querySelector('p').textContent=description;if(!help.open)help.showModal();
 }
 function openNews(){
  closeSearch();closeSettings();
  if(!news.open){news.showModal();news.scrollTop=0;}
 }
 function topActions(container){
  const bar=document.createElement('div');bar.className='and-top-actions';
  for(const [key,label,action] of [['ayuda','Ayuda',openHelp],['novedades','Novedades',openNews]]){
   const b=document.createElement('button');b.type='button';b.dataset.andTop=key;b.setAttribute('aria-label',label);b.title=label;
   b.innerHTML=svg(key)+(key==='novedades'?'<span class="and-news-dot" hidden></span>':'');
   b.addEventListener('click',action);bar.append(b);
  }
  container.prepend(bar);
 }
 topActions(stage.querySelector('.os-stage-toolbar'));topActions(main.querySelector('.exterior-marca'));
 function syncNews(){const available=document.querySelector('.exterior-android-updates')?.dataset.andNews==='true';for(const dot of document.querySelectorAll('.and-news-dot'))dot.hidden=!available;}
 const updatePanel=document.querySelector('.exterior-android-updates');if(updatePanel)new MutationObserver(syncNews).observe(updatePanel,{attributes:true,attributeFilter:['data-and-news']});syncNews();
 settings.addEventListener('click',e=>{if(e.target===settings){const r=settings.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeSettings();}});
 nav.addEventListener('click',e=>{
  const b=e.target.closest('[data-and-nav]');if(!b||b.disabled)return;
  const key=b.dataset.andNav;
  if(key==='buscar'){openSearch();return;}
  closeSearch();
  if(key==='ajustes'){openSettings();return;}
  if(key==='inicio'){goHome();return;}
  closeSettings();
  if(key==='crear'){
   saveEditor();if(!stage.hidden)homeScroll=stage.scrollTop;
   if(!stage.hidden)stage.querySelector('[data-os-action="map"]').click();
   else if(map.hidden)$('abrirMapa').click();
   else{ $('buscarPlantillas').value='';$('buscarPlantillas').dispatchEvent(new Event('input',{bubbles:true})); }
  }
  if(key==='editar'){
   if(inEditor()){sync();return;}
   resuming=true;
   if(!stage.hidden)$('osContinue').click();
   else{if(!map.hidden&&!$('cerrarMapa').hidden)$('cerrarMapa').click();finishResume();}
  }
  sync();
 });
 $('osContinue').addEventListener('click',()=>{resuming=true;finishResume();},true);
 for(const input of [$('osHomeSearch'),$('buscarPlantillas')]){input.addEventListener('focus',sync);input.addEventListener('blur',()=>queueMicrotask(sync));}
 steps.addEventListener('click',e=>{const b=e.target.closest('[data-and-step]');if(b)setMode(b.dataset.andStep,true);});
 // Los accesos internos y el historial preexistentes siguen funcionando.
 document.addEventListener('click',e=>{
  if(!inEditor())return;
  if(e.target.closest('#uxEdit,#volverEdicion,#proyBackEdit'))setMode('form');
  if(e.target.closest('#uxPreview,#irVistaPrevia,#proyPreviewJump')&&mode!=='export')setMode('preview');
 },true);
 let wasEditor=inEditor();
 const observer=new MutationObserver(()=>{
  const now=inEditor();
  if(now&&!wasEditor&&!resuming){savedEditor=null;setMode('form');}
  wasEditor=now;sync();
 });
 for(const el of [stage,map,layout,$('osContinue'),$('cerrarMapa')])if(el)observer.observe(el,{attributes:true,attributeFilter:['hidden']});
 const oldBack=window.exteriorAndroidBack;
 window.exteriorAndroidBack=function(){
  if(help.open){help.close();return;}
  if(news.open){news.close();return;}
  if(!searchScreen.hidden){closeSearch();return;}
  if(settings.open){closeSettings();return;}
  if(inEditor()&&mode!=='form'){setMode('form',true);return;}
  // El catálogo principal es el límite de navegación en Android.
  if(stage.hidden&&!map.hidden&&history.state?.vistaExterior==='plantillas'&&!$('buscarPlantillas').value)return;
  if(typeof oldBack==='function')oldBack();
 };
 const categoryIcons={prensa:'documento',sede:'sede',ad:'calendario',efemerides:'calendario','atencion-consular':'consular',avisos:'aviso',interno:'interno','otras-instituciones':'otros'};
 function decorate(){
  for(const b of $('osFamilyList').querySelectorAll('[data-os-family]')){
   const icon=b.querySelector('.os-stage-number');if(icon&&!icon.querySelector('svg')){icon.innerHTML=svg(categoryIcons[b.dataset.osFamily]||'documento');icon.setAttribute('aria-hidden','true');}
  }
 }
 new MutationObserver(decorate).observe($('osFamilyList'),{childList:true});decorate();
 // La identidad es informativa: no es un acceso de regreso a la portada.
 const brand=stage.querySelector('.os-stage-brand');
 if(brand){const identity=document.createElement('div');identity.className=brand.className;while(brand.firstChild)identity.append(brand.firstChild);brand.replaceWith(identity);}
 const headerBrand=$('osHomeHeader');if(headerBrand){headerBrand.removeAttribute('href');headerBrand.removeAttribute('title');headerBrand.removeAttribute('aria-label');headerBrand.setAttribute('tabindex','-1');headerBrand.addEventListener('click',e=>{if(e.isTrusted){e.preventDefault();e.stopImmediatePropagation();}},true);}
 // Unificar la identidad en catálogo, editor, vista previa y ajustes.
 if(headerBrand){const block=headerBrand.querySelector('.exterior-identidad');if(block){const ministry=document.createElement('span');ministry.className='and-ministry';ministry.textContent=stage.querySelector('.os-stage-identity span').textContent;block.append(ministry);}}
 // Inicio se concentra en la barra inferior permanente.
 const settingsHeader=settings.querySelector('header');
 const compactBrand=stage.querySelector('.os-stage-brand').cloneNode(true);compactBrand.className='and-compact-brand';for(const node of compactBrand.querySelectorAll('[id]'))node.removeAttribute('id');
 settingsHeader.insertBefore(compactBrand,settingsHeader.querySelector('h2'));
 // Accesos de uso habitual: reutilizan los botones reales del catálogo.
 const quick=document.createElement('section');quick.className='and-quick';quick.setAttribute('aria-labelledby','andQuickTitle');
 quick.innerHTML='<h2 id="andQuickTitle">Accesos rápidos</h2><div class="and-quick-grid"></div>';
 const shortcuts=[['avisos','Avisos','aviso'],['sede','Artes para sede','sede'],['atencion-consular','Atención consular','consular'],['prensa','Comunicados y prensa','documento']];
 for(const [family,label,key] of shortcuts){const b=document.createElement('button');b.type='button';b.dataset.andQuick=family;b.innerHTML=svg(key)+'<span>'+label+'</span><span class="and-quick-arrow" aria-hidden="true">›</span>';b.addEventListener('click',()=>{const target=$('osFamilyList').querySelector('[data-os-family="'+family+'"]');if(target)target.click();});quick.querySelector('.and-quick-grid').append(b);}
 stage.querySelector('.os-stage-grid').append(quick);
 // Inicio orientado a tareas: conservar la identidad y los accesos efectivos.
 const guide=stage.querySelector('.ux-home-guide p');if(guide)guide.textContent='Elegir una plantilla y completar los campos. Revisar la vista previa antes de descargar.';
 const title=$('osStageTitle');title.textContent='¿Qué desea crear?';
 const lead=stage.querySelector('.os-stage-lead');if(lead)lead.hidden=true;
 const overline=stage.querySelector('.os-stage-overline');
 if(overline){overline.textContent='Dirección de Comunicaciones';stage.querySelector('.os-stage-identity').append(overline);}
 const originalForm=$('osHomeSearchForm'),originalResults=$('osHomeSearchResults');
 if(originalForm){
  originalForm.hidden=true;
  if(originalResults)originalResults.hidden=true;
  const searchButton=document.createElement('button');searchButton.type='button';searchButton.className='and-home-search';
  searchButton.innerHTML=svg('buscar')+'<span>Buscar por tema o nombre</span>';
  searchButton.addEventListener('click',()=>openSearch());originalForm.before(searchButton);
 }
 const actions=stage.querySelector('.os-stage-actions'),resume=$('osContinue');
 if(actions&&resume){
  // Continuar sólo cuando el motor tiene una edición abierta.
  resume.textContent='Continuar edición';
  if(actions.contains(resume))actions.prepend(resume);
 }
 const firstHelp=document.createElement('button');firstHelp.type='button';firstHelp.className='and-first-help';
 firstHelp.innerHTML=svg('ayuda')+'<span><strong>¿Cómo crear un arte?</strong><small>Consultar la guía de uso</small></span><span class="and-quick-arrow" aria-hidden="true">›</span>';
 firstHelp.addEventListener('click',()=>{
  help.querySelector('p').textContent='Elegir una plantilla del catálogo o buscarla por su nombre. Completar los campos, revisar la vista previa y descargar el arte en el formato disponible.';
  if(!help.open)help.showModal();
 });
 quick.after(firstHelp);applyPreferences();
 const oldGuide=stage.querySelector('.ux-home-guide');if(oldGuide)oldGuide.hidden=true;
 // Evitar que la barra tape el campo activo cuando se abre el teclado.
 const vv=window.visualViewport;
 if(vv){const resize=()=>root.classList.toggle('and-keyboard',window.innerHeight-vv.height>150);vv.addEventListener('resize',resize);}
 setMode(location.hash.includes('zona=previa')?'preview':'form');sync();root.classList.add('and-ui-ready');
})();
