/* Exterior Android: navegación de aplicación. No interviene en el render ni en la exportación. */
(function(){
 'use strict';
 if(!document.documentElement.classList.contains('exterior-native'))return;
 const $=id=>document.getElementById(id);
 const stage=$('osStage'), main=document.querySelector('main.exterior'), map=$('mapaGenerador'), layout=document.querySelector('.exterior-layout'), editor=document.querySelector('.exterior-editor');
 if(!stage||!main||!map||!layout||!editor)return;
 const root=document.documentElement;
 const icons={
  ayuda:'<circle cx="12" cy="12" r="9"/><path d="M9 9a3 3 0 1 1 4 3c-1 .5-1 1-1 2m0 3h.01"/>',
  novedades:'<path d="M18 8a6 6 0 0 0-12 0c0 6-2 7-2 9h16c0-2-2-3-2-9m-8 12a2 2 0 0 0 4 0"/>',
  inicio:'<path d="m3 10 9-7 9 7v11h-6v-7H9v7H3z"/>',
  paleta:'<path d="M12 3a9 9 0 1 0 0 18h1.2a2 2 0 0 0 1.5-3.3 1.5 1.5 0 0 1 1.1-2.5H18a3 3 0 0 0 3-3A9 9 0 0 0 12 3Z"/><circle cx="7.5" cy="10" r=".8"/><circle cx="11" cy="7" r=".8"/><circle cx="16" cy="8" r=".8"/>',
  buscar:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
  reciente:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  atras:'<path d="m14 5-7 7 7 7M7 12h14"/>',
  cerrar:'<path d="m6 6 12 12M18 6 6 18"/>',
  crear:'<path d="M12 5v14M5 12h14"/>',
  ampliar:'<path d="M9 3H3v6m12-6h6v6M3 15v6h6m12-6v6h-6"/>',
  anterior:'<path d="m15 5-7 7 7 7"/>',
  siguiente:'<path d="m9 5 7 7-7 7"/>',
  editar:'<path d="M12 20H4v-8l10-10 8 8-10 10zM12 4l8 8"/>',
  ajustes:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2"/><circle cx="12" cy="12" r="8"/>',
  documento:'<path d="M6 3h8l4 4v14H6zM14 3v5h4M9 12h6m-6 4h6"/>',
  calendario:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4m10-4v4M3 10h18m-13 5h2m4 0h2"/>',
  aviso:'<path d="M3 10v4h4l11 5V5L7 10zM7 14l2 6h3"/>',
  consular:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c5 5 5 13 0 18m0-18c-5 5-5 13 0 18"/>',
  interno:'<rect x="3" y="5" width="18" height="15" rx="2"/><path d="m3 7 9 7 9-7"/>',
  sede:'<path d="M3 21h18M5 21V8l7-5 7 5v13M9 12h6m-6 4h6"/>',
  otros:'<rect x="3" y="5" width="18" height="14" rx="3"/><circle cx="8" cy="11" r="2"/><path d="M5 16c1-3 5-3 6 0m3-6h4m-4 4h4"/>'
 };
 const svg=k=>'<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">'+icons[k]+'</svg>';
 const nav=document.createElement('nav');nav.className='and-nav';nav.setAttribute('aria-label','Navegación de Exterior');
 const labels={inicio:'Inicio',buscar:'Buscar',crear:'Crear',editar:'Edición',ajustes:'Ajustes'};
 for(const [key,label] of Object.entries(labels)){
  const b=document.createElement('button');b.type='button';b.dataset.andNav=key;b.innerHTML='<span class="and-nav-icon">'+svg(key)+'</span><span>'+label+'</span>';nav.append(b);
 }
 document.body.append(nav);
 // Usar el alto real (incluida la zona segura), también al rotar o abrir el teclado.
 const measureNav=()=>root.style.setProperty('--and-nav-occupied',nav.getBoundingClientRect().height+'px');
 new ResizeObserver(measureNav).observe(nav);measureNav();
 // Inicio deja de ser modal: la navegación inferior también es accesible.
 stage.setAttribute('role','region');stage.removeAttribute('aria-modal');
 // Preferencias locales: sólo afectan la interfaz de Android.
 const prefKey='exterior.android.preferences.v1';
 const preferences={history:true,motion:true,guide:true};
 try{const stored=JSON.parse(localStorage.getItem(prefKey)||'{}');for(const k of Object.keys(preferences))if(typeof stored?.[k]==='boolean')preferences[k]=stored[k];}catch(_){}
 function applyPreferences(){
  root.classList.toggle('and-reduce-motion',!preferences.motion);
  const guide=stage.querySelector('.and-first-help');if(guide)guide.hidden=!preferences.guide;
 }
 function savePreferences(){try{localStorage.setItem(prefKey,JSON.stringify(preferences));}catch(_){}applyPreferences();persistNativeSettings();}
 const settings=document.createElement('dialog');settings.className='and-settings';settings.setAttribute('aria-labelledby','andSettingsTitle');
 settings.innerHTML='<header><button type="button" data-and-close aria-label="Cerrar ajustes">‹</button><h2 id="andSettingsTitle">Ajustes</h2></header><div class="and-settings-body"><section class="and-settings-card"><h3>Preferencias de uso</h3><label class="and-preference"><span><strong>Animaciones de navegación</strong><small>Activar transiciones entre pantallas.</small></span><input type="checkbox" data-and-pref="motion" role="switch"></label><label class="and-preference"><span><strong>Guía en Inicio</strong><small>Mostrar el acceso a la guía de uso.</small></span><input type="checkbox" data-and-pref="guide" role="switch"></label></section><section class="and-settings-card"><h3>Búsqueda y privacidad</h3><label class="and-preference"><span><strong>Guardar búsquedas recientes</strong><small>Conservar consultas en este dispositivo. Desactivar elimina el historial.</small></span><input type="checkbox" data-and-pref="history" role="switch"></label><button type="button" class="and-setting-action" data-and-clear-history>Borrar historial de búsqueda</button><p class="and-pref-status" role="status"></p></section><section class="and-settings-card"><h3>Archivos exportados</h3><p>Consultar los artes en Descargas/Exterior del dispositivo.</p></section><section class="and-settings-card"><h3>Acerca de Exterior</h3><p>Aplicación: <strong id="andVersion"></strong></p><p>Recursos: <strong id="andResourcesVersion"></strong></p><p>Ministerio de Relaciones Exteriores</p></section></div>';
 document.body.append(settings);
 $('andVersion').textContent=String(window.EXTERIOR_ANDROID_VERSION_NAME||'');
 $('andResourcesVersion').textContent=String(window.EXTERIOR_ANDROID_VERSION_NAME||'');
 const news=document.createElement('dialog');news.className='and-news';news.setAttribute('aria-labelledby','andNewsTitle');
 news.innerHTML='<header><button type="button" data-and-news-close aria-label="Cerrar novedades">'+svg('atras')+'</button><h2 id="andNewsTitle">Novedades</h2></header><div class="and-news-body"><div id="andUpdateSlot"></div><section class="and-settings-card"><p class="and-kicker">Mejoras incorporadas</p><h3>Exterior</h3><div class="and-news-entry"><strong>Búsqueda de plantillas</strong><p>Consultar resultados al escribir y recuperar búsquedas recientes.</p></div><div class="and-news-entry"><strong>Inicio y navegación</strong><p>Vuelva a abrir las plantillas recientes desde Inicio. Revise el arte y descárguelo en la misma pantalla.</p></div><div class="and-news-entry"><strong>Actualizaciones acumulativas</strong><p>Preparar la última versión compatible de los recursos sin instalar versiones intermedias.</p></div><div class="and-news-entry"><strong>Preferencias de uso</strong><p>Configurar el historial de búsqueda, las animaciones y la guía en Inicio.</p></div></section></div>';
 document.body.append(news);
 const updates=document.querySelector('.exterior-android-updates');
 if(updates)$('andUpdateSlot').append(updates);
 else $('andUpdateSlot').textContent='El servicio de actualizaciones no está disponible en este momento.';
 news.querySelector('[data-and-news-close]').addEventListener('click',()=>news.close());
 const steps=document.createElement('div');steps.className='and-steps';steps.setAttribute('role','group');steps.setAttribute('aria-label','Etapas de edición');
 for(const [key,label] of [['form','Editar'],['preview','Revisar arte']]){
  const b=document.createElement('button');b.type='button';b.dataset.andStep=key;b.textContent=label;b.setAttribute('aria-pressed',String(key==='form'));steps.append(b);
 }
 const editStep=steps.querySelector('[data-and-step="form"]');
 layout.prepend(steps);
 let mode='form',savedEditor=null,resuming=false,homeScroll=0,restoreFrame=0,homeEntryRoute='',regionalLanding=false;
 // Búsqueda independiente: consulta el mismo índice del catálogo y conserva la pantalla de origen.
 const searchScreen=document.createElement('section');
 searchScreen.className='and-search-screen';searchScreen.hidden=true;searchScreen.setAttribute('aria-label','Buscar plantillas');
 searchScreen.innerHTML='<header class="and-search-header"><button type="button" data-and-search-back aria-label="Volver">'+svg('atras')+'</button><form class="and-search-form" role="search"><span aria-hidden="true">'+svg('buscar')+'</span><input id="andSearchInput" type="search" aria-label="Buscar plantillas" placeholder="Buscar por tema o nombre" autocomplete="off" enterkeyhint="search" maxlength="120"><button type="button" data-and-search-clear aria-label="Limpiar búsqueda" hidden>'+svg('cerrar')+'</button></form></header><div class="and-search-content"><div class="and-search-heading"><h2></h2><div class="and-search-tools"><button type="button" data-and-search-all>Ver todo</button><button type="button" data-and-search-delete>Borrar todo</button></div></div><p class="and-search-status" role="status" aria-live="polite"></p><div class="and-search-list"></div></div>';
 document.body.append(searchScreen);
 const searchInput=$('andSearchInput'),searchList=searchScreen.querySelector('.and-search-list'),searchStatus=searchScreen.querySelector('.and-search-status');
 const searchHeading=searchScreen.querySelector('h2'),searchAll=searchScreen.querySelector('[data-and-search-all]'),searchDelete=searchScreen.querySelector('[data-and-search-delete]'),searchClear=searchScreen.querySelector('[data-and-search-clear]');
 const historyKey='exterior.android.recent-searches.v1',historyLimit=20;
 const templateKey='exterior.android.recent-templates.v1',templateLimit=4;
 const queryKey=q=>q.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('es').trim().replace(/\s+/g,' ');
 const tidy=q=>String(q||'').trim().replace(/\s+/g,' ').slice(0,120);
 let recent=[],recentTemplates=[],showAll=false,searchOrigin=null;
 function resolveTemplate(entry){
  if(typeof entry?.ruta!=='string'||typeof entry.id!=='string'||typeof entry.variante!=='string')return null;
  if(!Object.hasOwn(catalogoPlantillas,entry.ruta)||!Object.hasOwn(catalogoPlantillas[entry.ruta],entry.id))return null;
  const ficha=catalogoPlantillas[entry.ruta][entry.id];
  if(!entry.variante)return {ficha,variant:null};
  if(!Object.hasOwn(ficha.variantes||{},entry.variante))return null;
  return {ficha,variant:varianteCatalogo(entry.ruta,entry.id,entry.variante)};
 }
 const templateIdentity=({ruta,id,variante})=>JSON.stringify([ruta,id,variante]);
 function cleanTemplates(value){
  if(!preferences.history||!Array.isArray(value))return [];
  const valid=value.filter(resolveTemplate).map(({ruta,id,variante})=>({ruta,id,variante}));
  const keys=valid.map(templateIdentity);
  return valid.filter((entry,i)=>keys.indexOf(keys[i])===i).slice(0,templateLimit);
 }
 function currentTemplate(){
  const ruta=$('m').value,selector=familiasExterior[ruta]?.selector;
  const id=selector?$(selector).value:'';
  const ficha=catalogoPlantillas[ruta]?.[id];
  if(!ficha)return null;
  const valor=valorVarianteCatalogo(ruta,ficha);
  return {ruta,id,variante:Object.hasOwn(ficha.variantes||{},valor)?valor:''};
 }
 try{
  const stored=JSON.parse(localStorage.getItem(historyKey)||'[]');
  if(Array.isArray(stored))recent=stored.filter(q=>typeof q==='string'&&tidy(q)).map(tidy).filter((q,i,a)=>a.findIndex(x=>queryKey(x)===queryKey(q))===i).slice(0,historyLimit);
 }catch(_){}
 try{recentTemplates=cleanTemplates(JSON.parse(localStorage.getItem(templateKey)||'[]'));}catch(_){}
 if(!preferences.history)recent=[];
 const settingsPlugin=window.Capacitor?.Plugins?.ExteriorFiles;
 let settingsDirty=false,settingsRestored=false,settingsQueue=Promise.resolve();
 function persistNativeSettings(){
  settingsDirty=true;
  if(typeof settingsPlugin?.writeUserSettings!=='function')return;
  const snapshot=JSON.stringify({preferences:{...preferences},recent:preferences.history?[...recent]:[],templates:preferences.history?recentTemplates:[]});
  settingsQueue=settingsQueue.catch(()=>{}).then(()=>settingsPlugin.writeUserSettings({settings:snapshot})).catch(()=>{prefStatus.textContent='No se pudo guardar la copia de los ajustes. Se conserva la configuración local.';});
 }
 function persistRecent(){try{localStorage.setItem(historyKey,JSON.stringify(recent));}catch(_){}persistNativeSettings();}
 function storeTemplates(){
  try{if(preferences.history)localStorage.setItem(templateKey,JSON.stringify(recentTemplates));else localStorage.removeItem(templateKey);}catch(_){}
 }
 function clearTemplates(){recentTemplates=[];storeTemplates();persistNativeSettings();renderRecentTemplates();}
 function restoreNativeSettings(){
  const finish=()=>{settingsRestored=true;recordTemplate();};
  if(typeof settingsPlugin?.readUserSettings!=='function'){finish();return;}
  Promise.resolve(settingsPlugin.readUserSettings()).then(result=>{
   if(settingsDirty)return;
   if(!result?.settings){persistNativeSettings();return;}
   const stored=JSON.parse(result.settings);
   for(const k of Object.keys(preferences))if(typeof stored.preferences?.[k]==='boolean')preferences[k]=stored.preferences[k];
   recent=preferences.history&&Array.isArray(stored.recent)?stored.recent.filter(q=>typeof q==='string'&&tidy(q)).map(tidy).filter((q,i,a)=>a.findIndex(x=>queryKey(x)===queryKey(q))===i).slice(0,historyLimit):[];
   recentTemplates=cleanTemplates(stored.templates??recentTemplates);storeTemplates();renderRecentTemplates();
   try{localStorage.setItem(prefKey,JSON.stringify(preferences));localStorage.setItem(historyKey,JSON.stringify(recent));}catch(_){}
   for(const c of settings.querySelectorAll('[data-and-pref]'))c.checked=preferences[c.dataset.andPref];
   clearHistory.disabled=!preferences.history;applyPreferences();if(!searchScreen.hidden)renderSearch();
  }).catch(()=>{}).finally(finish);
 }
 function rememberQuery(value){
  const q=tidy(value);if(!q||!preferences.history)return;
  recent=[q,...recent.filter(x=>queryKey(x)!==queryKey(q))].slice(0,historyLimit);persistRecent();
 }
 function clearRecent(){recent=[];persistRecent();showAll=false;if(!searchScreen.hidden)renderSearch();}
 const prefStatus=settings.querySelector('.and-pref-status');
 const clearHistory=settings.querySelector('[data-and-clear-history]');
 const clearTemplateHistory=document.createElement('button');clearTemplateHistory.type='button';clearTemplateHistory.className='and-setting-action';clearTemplateHistory.textContent='Borrar plantillas recientes';
 clearHistory.after(clearTemplateHistory);
 clearTemplateHistory.addEventListener('click',()=>{clearTemplates();prefStatus.textContent='Plantillas recientes eliminadas.';});
 const historyControl=settings.querySelector('[data-and-pref="history"]');
 historyControl.labels[0].querySelector('strong').textContent='Guardar actividad reciente';
 historyControl.labels[0].querySelector('small').textContent='Conservar búsquedas y plantillas en este dispositivo.';
 for(const control of settings.querySelectorAll('[data-and-pref]')){
  const key=control.dataset.andPref;control.checked=preferences[key];
  control.addEventListener('change',()=>{
   preferences[key]=control.checked;savePreferences();
   if(key==='history'&&!preferences.history){clearRecent();clearTemplates();}
   if(key==='history')renderRecentTemplates();
   clearHistory.disabled=!preferences.history;
   prefStatus.textContent=key==='history'&&!preferences.history?'Historial eliminado.':'';
  });
 }
 clearHistory.disabled=!preferences.history;
 clearHistory.addEventListener('click',()=>{if(window.confirm('¿Borrar todas las búsquedas recientes?')){clearRecent();prefStatus.textContent='Historial eliminado.';}});
 function catalogResults(q){
  // El motor existente es la única fuente de coincidencias. Restaurar el filtro previo antes de regresar.
  const field=$('buscarPlantillas'),previous=field.value;
  try{
   field.value=q;field.dispatchEvent(new Event('input',{bubbles:true}));
   return [...$('resultadosPlantillas').querySelectorAll(':scope > button')].map((b,index)=>({
    index,name:b.querySelector('strong')?.textContent.trim()||b.textContent.trim(),
    detail:b.querySelector('small')?.textContent.trim()||''
   }));
  }finally{field.value=previous;field.dispatchEvent(new Event('input',{bubbles:true}));}
 }
 function searchRow(icon,name,detail,action,remove){
  const row=document.createElement('div');row.className='and-search-row';
  const button=document.createElement('button');button.type='button';button.className='and-search-result';
  const mark=document.createElement('span');mark.className='and-search-mark';mark.innerHTML=svg(icon);
  const words=document.createElement('span');words.className='and-search-words';const title=document.createElement('strong');title.textContent=name;words.append(title);
  if(detail){const sub=document.createElement('small');sub.textContent=detail;words.append(sub);}
  button.append(mark,words);button.addEventListener('click',action);row.append(button);
  if(remove){
   const del=document.createElement('button');del.type='button';del.className='and-search-remove';del.setAttribute('aria-label','Eliminar búsqueda '+name);del.innerHTML=svg('cerrar');
   del.addEventListener('click',remove);row.append(del);
  }
  searchList.append(row);return button;
 }
 function renderSearch(){
  const q=tidy(searchInput.value);searchClear.hidden=!searchInput.value;searchList.replaceChildren();
  searchAll.hidden=!!q||recent.length<=6;searchDelete.hidden=!!q||recent.length===0;
  if(!q){
   searchHeading.textContent='Recientes';searchAll.textContent=showAll?'Ver menos':'Ver todo';
   searchStatus.textContent=preferences.history?(recent.length?'':'No hay búsquedas recientes.'):'El historial de búsqueda está desactivado.';
   for(const value of recent.slice(0,showAll?historyLimit:6))searchRow('reciente',value,'',()=>{
    searchInput.value=value;renderSearch();searchInput.focus({preventScroll:true});
   },()=>{recent=recent.filter(x=>queryKey(x)!==queryKey(value));persistRecent();renderSearch();});
   return;
  }
  searchHeading.textContent='Resultados';
  const results=catalogResults(q);
  searchStatus.textContent=results.length?(results.length===1?'1 resultado':results.length+' resultados'):'No se encontraron plantillas.';
  for(const result of results)searchRow('documento',result.name,result.detail,()=>chooseResult(q,result));
 }
 function openSearch(initial=''){
  if(!searchScreen.hidden){searchInput.focus({preventScroll:true});return;}
  closeSettings();searchOrigin={stageInert:stage.inert,mainInert:main.inert,stageTop:stage.scrollTop,top:window.scrollY,left:window.scrollX};
  stage.inert=true;main.inert=true;searchScreen.hidden=false;root.classList.add('and-searching');
  showAll=false;searchInput.value=tidy(initial);renderSearch();searchScreen.querySelector('.and-search-content').scrollTop=0;
  sync();searchInput.focus({preventScroll:true});
 }
 function closeSearch(){
  if(searchScreen.hidden)return;
  searchInput.blur();searchScreen.hidden=true;root.classList.remove('and-searching');
  if(searchOrigin){
   stage.inert=searchOrigin.stageInert;main.inert=searchOrigin.mainInert;
   stage.scrollTop=searchOrigin.stageTop;window.scrollTo({top:searchOrigin.top,left:searchOrigin.left,behavior:'instant'});
  }
  searchOrigin=null;sync();
 }
 function chooseResult(q,result){
  homeEntryRoute='';rememberQuery(q);closeSearch();saveEditor();
  if(!stage.hidden){homeScroll=stage.scrollTop;stage.querySelector('[data-os-action="map"]').click();}
  else if(map.hidden)$('abrirMapa').click();
  else if(typeof cerrarSubmenuSede==='function')cerrarSubmenuSede();
  const field=$('buscarPlantillas');field.value=q;field.dispatchEvent(new Event('input',{bubbles:true}));
  const options=[...$('resultadosPlantillas').querySelectorAll(':scope > button')];
  const match=options.find(b=>(b.querySelector('strong')?.textContent.trim()||b.textContent.trim())===result.name&&(b.querySelector('small')?.textContent.trim()||'')===result.detail)||options[result.index];
  match?.click();sync();
 }
 searchInput.addEventListener('input',renderSearch);
 searchScreen.querySelector('form').addEventListener('submit',e=>{
  e.preventDefault();const q=tidy(searchInput.value);if(!q)return;
  rememberQuery(q);const results=catalogResults(q);
  if(results.length===1)chooseResult(q,results[0]);else{renderSearch();searchInput.blur();}
 });
 searchScreen.querySelector('[data-and-search-back]').addEventListener('click',closeSearch);
 searchClear.addEventListener('click',()=>{searchInput.value='';renderSearch();searchInput.focus({preventScroll:true});});
 searchAll.addEventListener('click',()=>{showAll=!showAll;renderSearch();});
 searchDelete.addEventListener('click',()=>{if(window.confirm('¿Borrar todas las búsquedas recientes?')){recent=[];persistRecent();showAll=false;renderSearch();}});
 searchScreen.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();closeSearch();}});
 // El buscador de Inicio utiliza el mismo espacio sin alterar el catálogo web.
 $('osHomeSearch').addEventListener('focus',()=>{if(searchScreen.hidden)openSearch($('osHomeSearch').value);});
 // Guardar sólo la posición y etapa de la edición; los datos siguen en el motor.
 const editorPosition=()=>({mode,top:window.scrollY,left:window.scrollX});
 const saveEditor=()=>{if(inEditor())savedEditor=editorPosition();};
 function restoreEditor(){
  if(!inEditor())return;
  const saved=savedEditor;savedEditor=null;
  if(!saved)return;
  resuming=true;setMode(saved.mode,true);
  cancelAnimationFrame(restoreFrame);
  const start=performance.now();let stable=0,previousHeight=-1;
  const stop=()=>{cancelAnimationFrame(restoreFrame);document.removeEventListener('pointerdown',stop,true);document.removeEventListener('wheel',stop,true);document.removeEventListener('touchstart',stop,true);};
  function frame(now){
   if(!inEditor()||mode!==saved.mode){stop();return;}
   const height=document.scrollingElement.scrollHeight;
   if(Math.abs(window.scrollY-saved.top)>1||Math.abs(window.scrollX-saved.left)>1)window.scrollTo({top:saved.top,left:saved.left,behavior:'instant'});
   stable=height===previousHeight?stable+1:0;previousHeight=height;
   if((stable>=8&&out.getAttribute('aria-busy')!=='true')||now-start>4000){stop();return;}
   restoreFrame=requestAnimationFrame(frame);
  }
  for(const event of ['pointerdown','wheel','touchstart'])document.addEventListener(event,stop,{capture:true,passive:true});
  restoreFrame=requestAnimationFrame(frame);
 }
 function finishResume(){requestAnimationFrame(()=>{if(inEditor())restoreEditor();resuming=false;sync();});}
 stage.addEventListener('click',()=>{if(!stage.hidden)homeScroll=stage.scrollTop;},true);
 function goHome(){
  homeEntryRoute='';saveEditor();closeSettings();
  if(stage.hidden){$('osHomeHeader').click();requestAnimationFrame(()=>{if(!stage.hidden)stage.scrollTop=homeScroll;});}
  sync();
 }
 const inEditor=()=>stage.hidden&&map.hidden&&!layout.hidden;
 // 1.0.48: herramientas sobre los controles originales. No copiar, recrear ni
 // trasladar inputs, archivos, listeners, datos o lienzos del generador.
 const toolDefs={
  info:['Información','Título y contenido','documento'],
  representation:['Representación','Membrete institucional','sede'],
  activities:['Actividades','Agenda y agrupaciones','lista'],
  time:['Fecha y horario','Fechas, días y horas','calendario'],
  photo:['Fotografía','Imagen y encuadre','foto'],
  directory:['Directorio','Sedes, lugares y contactos','lista'],
  logos:['Logotipos','Entidades colaboradoras','otros'],
  appearance:['Formato','Diseño y tamaño','formato'],
  import:['Importar contenido','Pegar desde un documento','documento'],
  extra:['Más opciones','Controles de la plantilla','ajustes']
 };
 icons.foto='<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="8" cy="9" r="2"/><path d="m4 18 6-6 4 4 3-3 4 4"/>';
 icons.lista='<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>';
 icons.formato='<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 8h8M8 12h8"/>';
 const workspace=document.createElement('section');workspace.className='and-workspace';workspace.hidden=true;workspace.setAttribute('aria-label','Herramientas de edición');
 const workspaceHeading=document.createElement('h3');workspaceHeading.textContent='Editar arte';
 const workspaceHint=document.createElement('p');workspaceHint.textContent='Completar los campos o ir directamente a un apartado.';
 const workspaceGrid=document.createElement('div');workspaceGrid.className='and-tool-grid';
 const allTools=document.createElement('button');allTools.type='button';allTools.className='and-tool-all';allTools.textContent='Todas las opciones';
 const acceso=document.createElement('div');acceso.className='and-editor-entry';
 const herramientas=document.createElement('details');herramientas.className='and-editor-options';
 const tituloHerramientas=document.createElement('summary');tituloHerramientas.textContent='Más opciones';
 herramientas.append(tituloHerramientas,workspaceGrid,allTools);
 workspace.append(acceso,herramientas);
 editor.querySelector('.exterior-editor-top').after(workspace);
 const sheetHeader=document.createElement('header');sheetHeader.className='and-tool-sheet-header';sheetHeader.hidden=true;
 const sheetTitle=document.createElement('h3');sheetTitle.id='andToolSheetTitle';
 const sheetClose=document.createElement('button');sheetClose.type='button';sheetClose.setAttribute('aria-label','Cerrar herramienta');sheetClose.innerHTML=svg('cerrar');
 const sheetApply=document.createElement('button');sheetApply.type='button';sheetApply.className='and-tool-apply';sheetApply.textContent='Listo';
 sheetHeader.append(sheetClose,sheetTitle,sheetApply);workspace.after(sheetHeader);
 const sheetVeil=document.createElement('div');sheetVeil.className='and-tool-veil';sheetVeil.hidden=true;document.body.append(sheetVeil);
 let toolBlocks=[],toolGroups=new Map(),toolFamily=null,openTool='',toolOrigin=null,showAllTools=true,toolFrame=0;
 const originalVisible=e=>{for(let n=e;n&&n!==editor;n=n.parentElement)if(n.hidden||n.style.display==='none')return false;return true;};
 const fold=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 const contextTools=window.exteriorEditingTools;
 function activeImageFamily(){
  return ['dui','dse','ad','mov','sede','proy'].map($).find(n=>n&&originalVisible(n))||null;
 }
 function isPress(){return contextTools.press();}
 function regionalPalette(){return contextTools.regional();}
 function toolLabel(key){
  if(regionalPalette()){
   if(key==='info')return ['Editar información','Contenido de las oficinas','documento'];
   if(key==='appearance')return ['Formato y colores','Diseño, tamaño y paleta','paleta'];
  }
  if($('m').value==='esquelas'){
   if(key==='appearance')return ['Autoridad institucional','Seleccionar el formato de la esquela','formato'];
   if(key==='time')return ['Lugar y fecha','Datos de emisión','calendario'];
  }
  if(isPress()){
   const labels={info:['Contenido','Título y texto','documento'],time:['Fecha','Fecha del documento','calendario'],appearance:['Tipo y formato','Documento breve o extenso','formato']};
   if(labels[key])return labels[key];
  }
  if(key==='photo')return ['Fotografía e ilustración','Imagen y encuadre','foto'];
  return toolDefs[key];
 }
 function setSheetGeometry(){
  const viewport=window.visualViewport;
  root.style.setProperty('--and-tool-viewport',Math.round(viewport?.height||window.innerHeight)+'px');
  root.style.setProperty('--and-tool-offset',Math.max(0,Math.round(window.innerHeight-(viewport?.height||window.innerHeight)-(viewport?.offsetTop||0)))+'px');
 }
 window.visualViewport?.addEventListener('resize',setSheetGeometry);
 window.visualViewport?.addEventListener('scroll',setSheetGeometry);
 function closeTool(restoreFocus=true){
  if(!openTool)return;
  openTool='';root.classList.remove('and-tool-open');delete root.dataset.andPressTool;sheetHeader.hidden=true;sheetVeil.hidden=true;
  editor.removeAttribute('role');editor.removeAttribute('aria-modal');editor.setAttribute('aria-labelledby','editorTitulo');
  toolBlocks.forEach(b=>b.classList.remove('and-tool-active'));
  if(restoreFocus&&toolOrigin?.isConnected)toolOrigin.focus({preventScroll:true});
  toolOrigin=null;
 }
 function applyToolVisibility(){
  toolBlocks.forEach(b=>b.classList.toggle('and-tool-active',!!openTool&&!!toolGroups.get(openTool)?.blocks.has(b)));
  root.classList.toggle('and-tool-compact',!workspace.hidden&&!showAllTools);
 }
 function openToolPanel(key,origin){
  // Reconsultar los campos originales: una variante puede haber sustituido los nodos.
  syncWorkspace();
  const group=toolGroups.get(key);if(!group||!group.controls?.size)return;
  if(openTool)closeTool(false);
  openTool=key;toolOrigin=origin;sheetTitle.textContent=toolLabel(key)[0];sheetHeader.hidden=false;sheetVeil.hidden=false;
  if(isPress())root.dataset.andPressTool=key;
  setSheetGeometry();root.classList.add('and-tool-open');editor.setAttribute('role','dialog');editor.setAttribute('aria-modal','true');editor.setAttribute('aria-labelledby',sheetTitle.id);
  applyToolVisibility();editor.scrollTop=0;sheetClose.focus({preventScroll:true});
  for(const control of group.controls){
   if(!control.isConnected)continue;
   if(control.matches('summary'))control.parentElement.open=true;
   for(let d=control.closest('details');d&&editor.contains(d);d=d.parentElement?.closest('details'))d.open=true;
  }
 }
 // Avisos: solo una ruta para editar los mismos campos, sin duplicar los datos.
 const avisoConfiguracion=$('adConfiguracion'), avisoContenido=$('adF')?.closest('.card');
 const avisoComparar=$('compararVariantes'), avisoCompararSiguiente=avisoComparar?.nextElementSibling;
 let avisoReordenado=false,avisoManualAbierto=false;
 function syncAvisoForm(activo){
  root.classList.toggle('and-aviso-forma',activo);
  if(!activo){
   if(avisoReordenado){
    avisoContenido.before(avisoConfiguracion);
    avisoCompararSiguiente.before(avisoComparar);
    avisoReordenado=false;
   }
   return;
  }
  if(!avisoReordenado&&avisoContenido&&avisoConfiguracion&&avisoComparar&&avisoCompararSiguiente){
   avisoContenido.after(avisoConfiguracion);
   $('ad').after(avisoComparar);
   avisoReordenado=true;
  }
  const panel=$('adF');
  if(panel.querySelector('.and-aviso-secciones'))return;
  const original=panel.querySelector('.aviso-opciones'), mensaje=$('editorial-ad-mensaje');
  const resumen=panel.querySelector('.sede-importar-cartelera summary');
  if(!original||!mensaje||!resumen)return;
  const contenedor=panel.querySelector('#aviso-bloque-pie')?.parentElement;
  if(!contenedor)return;
  resumen.textContent='Pegar el aviso';
  const importar=resumen.parentElement;
  const detalle=importar.querySelector('p.field-help');
  if(detalle)detalle.textContent='Pegar el texto completo. Escribir una sede por línea si hay un listado.';
  const enviar=importar.querySelector('button');
  if(enviar){
   enviar.textContent='Generar vista previa';
   enviar.addEventListener('click',()=>{
    if(!enviar.isConnected)queueMicrotask(()=>{if(inEditor()&&$('m').value==='avisos')setMode('preview',true);});
   });
  }
  mensaje.placeholder='Ejemplo: Informamos que las siguientes oficinas…';
  const indicacion=mensaje.parentElement.querySelector('small');
  if(indicacion)indicacion.remove();
  const pie=$('editorial-ad-pie');
  if(pie){
   const etiqueta=pie.labels[0];
   if(etiqueta)etiqueta.textContent='Texto final';
   pie.placeholder='Ej.: Permanecerán cerrados el jueves…';
   const ayuda=pie.parentElement.querySelector('small');
   if(ayuda)ayuda.textContent='Separar el cierre y la reapertura con una línea en blanco.';
  }
  const secciones=document.createElement('div');secciones.className='and-aviso-secciones';
  for(const [clave,titulo] of [['sedes','Ubicaciones'],['pie','Cierre y reapertura'],['contactos','Contactos']]){
   const control=$('aviso-incluir-'+clave), grupo=$('aviso-bloque-'+clave);
   if(!control||!grupo)continue;
   const opcion=document.createElement('div');opcion.className='and-aviso-opcion';
   if(clave==='sedes')control.addEventListener('change',()=>{
    const ficha=fichaAviso(datosEditoriales('aviso'));
    if(!control.checked||ficha.sedesInicializadas)return;
    ficha.sedesInicializadas=true;
    ficha.sedes.splice(0,ficha.sedes.length,'');
    montarSedesAviso(grupo,ficha);
    requestAnimationFrame(()=>grupo.querySelector('textarea,input:not([type=hidden])')?.focus());
   },true);
   const label=control.closest('label');
   label.replaceChildren(control,document.createTextNode(titulo));
   grupo.querySelector('legend')?.classList.add('and-aviso-leyenda');
   opcion.append(label,grupo);secciones.append(opcion);
  }
  original.replaceWith(secciones);contenedor.remove();
  const boton=document.createElement('button');boton.type='button';boton.className='g and-aviso-revisar';
  boton.textContent='Revisar arte';
  boton.addEventListener('click',()=>setMode('preview',true));
  const manual=document.createElement('details');manual.className='and-aviso-manual';
  const apertura=document.createElement('summary');apertura.textContent='Editar aviso';
  manual.append(apertura,mensaje.parentElement,secciones,boton);
  manual.addEventListener('toggle',()=>{if(manual.isConnected)avisoManualAbierto=manual.open;});
  manual.open=avisoManualAbierto;panel.append(manual);
  const identidad=panel.querySelector('.aviso-identidad');
  if(identidad){identidad.querySelector('summary').textContent='Más opciones';panel.append(identidad);}
  // La primera entrada abre el pegado; tras importar no se vuelve a pedir el texto.
  importar.open=!importar.querySelector('[role=status]')?.textContent.trim();
 }
 // Abrir el panel original de importación o llevar al primer campo del arte.
 const entradaPorRuta={
  prensa:['Ir al título','#editorial-sede-titulo'],
  sede:['Editar datos de la oficina','#sede-titulo'],
  ad:['Editar el texto','[data-campo-editorial="titulo"],#adf_t0,#adf_intro'],
  efemerides:['Editar la actividad','#adf_t0,#d1'],
  'atencion-consular':['Editar la jornada','#editorial-ad-titulo'],
  interno:['Editar los datos','#editorial-sede-nombre,#adf_t0'],
  esquelas:['Ir al nombre','#editorial-ad-nombre'],
  'otras-instituciones':['Editar la primera sede','[id^="dui_city_"]']
 };
 const camposPegables={
  titulo:['[data-campo-editorial="titulo"]','#adf_t0','#d1','#sede-titulo','#t'],
  subtitulo:['#adf_t1','#d2','#sede-subtitulo','#s'],
  texto:['[data-campo-editorial="cuerpo"]','#adf_info','#editorial-ad-texto2','#sede-nota'],
  fecha:['[data-campo-editorial="fecha1"]','[data-campo-editorial="fecha"]','#adf_fecha','#df','#dui_date_0'],
  hora:['[data-campo-editorial="hora"]','#adf_hora','#dh','#sede-horario','#dui_time_0'],
  lugar:['[data-campo-editorial="lugar"]','#adf_lugar','#du','#dui_address_0','#editorial-sede-direccion'],
  nombre:['#editorial-ad-nombre','#editorial-sede-nombre'],
  cargo:['#editorial-sede-cargo'],correo:['#editorial-sede-correo'],ciudad:['#dui_city_0'],
  representacion:['[data-campo-editorial="repre1"]','#adInvitacionRepre1','#editorial-sede-sede']
 };
 function pegarCampos(familia,contexto){
  const encontrar=(selectores)=>selectores.map(sel=>familia.querySelector(sel)).find(e=>e&&originalVisible(e)&&!e.disabled);
  const objetivos=new Map();
  for(const [clave,selectores] of Object.entries(camposPegables)){
   const campo=encontrar(selectores);
   if(campo)objetivos.set(clave,campo);
  }
  if(objetivos.size<2)return null;
  const propuesta=document.createElement('details');propuesta.className='and-structured-paste';
  const titulo=document.createElement('summary');titulo.textContent='Pegar datos';
  const etiqueta=document.createElement('label');etiqueta.textContent='Texto con los nombres de los campos';
  const texto=document.createElement('textarea');texto.rows=4;texto.maxLength=12000;
  const disponibles=[...objetivos.keys()];
  const rotulo={titulo:'Título',subtitulo:'Subtítulo',representacion:'Representación'};
  texto.placeholder=disponibles.slice(0,2).map(k=>(rotulo[k]||k[0].toUpperCase()+k.slice(1))+': …').join('\n');
  etiqueta.append(texto);
  const nota=document.createElement('p');nota.className='field-help';
  nota.textContent='Escribir el nombre del campo seguido de dos puntos. Revisar lo que se reconoce antes de descargar.';
  const aplicar=document.createElement('button');aplicar.type='button';aplicar.className='g';aplicar.textContent='Usar estos datos';
  const resultado=document.createElement('p');resultado.setAttribute('role','status');resultado.className='field-help';
  aplicar.addEventListener('click',()=>{
   const valores=new Map();let actual=null,omitidos=0;
   for(const linea of texto.value.split(/\r?\n/)){
    const m=linea.match(/^\s*([\p{L} ]{2,30}):\s*(.*)$/u);
    if(m){
     const k=fold(m[1].trim());actual=objetivos.has(k)?k:null;
     if(actual){if(valores.has(actual)){omitidos++;actual=null;}else valores.set(actual,m[2]);}
     else omitidos++;
    }else if(actual)valores.set(actual,valores.get(actual)+'\n'+linea);
    else if(linea.trim())omitidos++;
   }
   const cambios=[];
   for(const [clave,valor] of valores){
    const campo=encontrar(camposPegables[clave]),normalizado=valor.trim();
    if(!campo?.isConnected||!normalizado||campo.maxLength>=0&&normalizado.length>campo.maxLength||campo.tagName==='INPUT'&&normalizado.includes('\n')){omitidos++;continue;}
    cambios.push([campo,normalizado]);
   }
   if(!cambios.length){resultado.textContent='No se reconocieron campos. Revisar el ejemplo o completar el formulario.';return;}
   if(cambios.some(([campo,valor])=>campo.value.trim()&&campo.value.trim()!==valor)&&!confirm('¿Reemplazar los datos de los campos identificados?'))return;
   for(const [campo,valor] of cambios){campo.value=valor;campo.dispatchEvent(new Event('input',{bubbles:true}));}
   resultado.textContent=cambios.length+(cambios.length===1?' campo completado.':' campos completados.')+(omitidos?' Parte del texto quedó sin asignar. Se conserva aquí.':'');
  });
  propuesta.append(titulo,etiqueta,nota,aplicar,resultado);
  return propuesta;
 }
 const importadores=new Map([['mvPegado','Pegar convocatoria'],['sedeTextoCartelera','Pegar actividades'],['svpTextoPegado','Pegar convocatorias'],['proyRaw','Pegar proyección']]);
 function sincronizarEntrada(familia,contexto){
  if(acceso.dataset.contexto===contexto)return;
  acceso.dataset.contexto=contexto;acceso.replaceChildren();
  const encontrarImportador=()=>[...familia.querySelectorAll('textarea')].find(n=>importadores.has(n.id)&&originalVisible(n));
  const importador=encontrarImportador();
  const [texto,campo]=entradaPorRuta[$('m').value]||['Editar contenido','textarea,input[type=text]'];
  const titulo=document.createElement('strong');titulo.textContent=importador?'Empezar con un texto':'Contenido del arte';
  const ir=document.createElement('button');ir.className='g';ir.type='button';
  ir.textContent=importador?importadores.get(importador.id):texto;
  ir.addEventListener('click',()=>{
   if(!inEditor())return;
   if(!showAllTools){showAllTools=true;syncWorkspace();}
   const objetivo=encontrarImportador()||(campo||'textarea,input[type=text]').split(',').flatMap(sel=>[...familia.querySelectorAll(sel)]).find(originalVisible)||
    [...familia.querySelectorAll('textarea,input[type=text],input[type=file]')].find(originalVisible);
   if(!objetivo)return;
   for(let d=objetivo.closest('details');d&&editor.contains(d);d=d.parentElement?.closest('details'))d.open=true;
   objetivo.focus({preventScroll:true});
   objetivo.scrollIntoView({block:'center'});
  });
  acceso.append(titulo,ir);
  if(!importador){const pegado=pegarCampos(familia,contexto);if(pegado)acceso.append(pegado);}
 }
 function syncWorkspace(){
  const enAviso=inEditor()&&$('m').value==='avisos'&&$('adT').value==='aviso';
  syncAvisoForm(enAviso);
  const family=inEditor()&&mode==='form'&&!enAviso?activeImageFamily():null;
  if(!family){
   closeTool(false);toolBlocks.forEach(b=>b.classList.remove('and-tool-block','and-tool-active'));toolBlocks=[];toolFamily=null;toolGroups.clear();workspace.hidden=true;root.classList.remove('and-tool-compact');return;
  }
  const discovered=contextTools.discover(family,editor),blocks=discovered.blocks;
  if(!blocks.length){workspace.hidden=true;closeTool(false);toolGroups.clear();root.classList.remove('and-tool-compact');return;}
  const previous=Array.from(toolGroups.keys()).join(',');
  const context=[$('m').value,family.id==='sede'?$('sedeDiseno')?.value:'',family.id==='sede'?$('sedeVersion')?.value:'',family.id==='ad'?$('adT')?.value:'',regionalPalette()].join('|');
  const contextChanged=workspace.dataset.andContext!==context;
  if(contextChanged){closeTool(false);showAllTools=true;herramientas.open=false;workspace.dataset.andContext=context;}
  sincronizarEntrada(family,context);
  const same=family===toolFamily&&blocks.length===toolBlocks.length&&blocks.every((b,i)=>b===toolBlocks[i]);
  if(!same){toolBlocks.forEach(b=>b.classList.remove('and-tool-block','and-tool-active'));toolBlocks=blocks;toolFamily=family;}
  toolGroups=new Map([...discovered.groups].filter(([,group])=>[...group.controls||[]].some(c=>c.isConnected&&!c.matches(':disabled,[aria-disabled="true"]'))));
  toolBlocks.forEach(b=>b.classList.add('and-tool-block'));
  if(openTool&&!toolGroups.has(openTool))closeTool(false);
  const keys=Object.keys(toolDefs).filter(k=>toolGroups.has(k));
  if(!keys.length){
   closeTool(false);workspace.hidden=true;workspaceGrid.replaceChildren();root.classList.remove('and-tool-compact');return;
  }
  workspace.hidden=false;workspaceGrid.hidden=false;workspace.classList.toggle('and-direct-form',showAllTools);
  if(contextChanged||previous!==Array.from(toolGroups.keys()).join(',')||!workspaceGrid.children.length){
   workspaceGrid.replaceChildren();
   for(const key of keys){
    const [label,sub,icon]=toolLabel(key),b=document.createElement('button');
    b.type='button';b.className='and-tool-tile';b.dataset.andTool=key;
    const mark=document.createElement('span');mark.className='and-tool-mark';mark.innerHTML=svg(icon);
    const strong=document.createElement('strong');strong.textContent=label;
    const small=document.createElement('small');small.textContent=sub;
    b.append(mark,strong,small);b.addEventListener('click',()=>openToolPanel(key,b));workspaceGrid.append(b);
   }
  }
  allTools.textContent=showAllTools?'Editar por apartados':'Todas las opciones';allTools.setAttribute('aria-expanded',String(showAllTools));
  applyToolVisibility();
 }
 allTools.addEventListener('click',()=>{closeTool(false);showAllTools=!showAllTools;syncWorkspace();});
 sheetClose.addEventListener('click',()=>closeTool());sheetApply.addEventListener('click',()=>closeTool());sheetVeil.addEventListener('click',()=>closeTool());
 document.addEventListener('keydown',e=>{
  if(!openTool)return;
  if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();closeTool();return;}
  if(e.key==='Tab'){
   const nodes=Array.from(editor.querySelectorAll('button:not([disabled]),input:not([disabled]):not([type=hidden]),select:not([disabled]),textarea:not([disabled]),summary,[tabindex="0"]')).filter(n=>n.getClientRects().length&&getComputedStyle(n).visibility!=='hidden');
   if(!nodes.length)return;
   if(e.shiftKey&&(document.activeElement===nodes[0]||!editor.contains(document.activeElement))){e.preventDefault();nodes.at(-1).focus();}
   else if(!e.shiftKey&&(document.activeElement===nodes.at(-1)||!editor.contains(document.activeElement))){e.preventDefault();nodes[0].focus();}
  }
 },true);
 new MutationObserver(records=>{
  if(!records.some(r=>['dui','dse','ad','mov','sede','proy'].some(id=>$(id)?.contains(r.target))))return;
  cancelAnimationFrame(toolFrame);toolFrame=requestAnimationFrame(syncWorkspace);
 }).observe(editor,{childList:true,subtree:true,attributes:true,attributeFilter:['hidden','disabled','aria-hidden','aria-disabled','style']});
 editor.addEventListener('change',()=>{cancelAnimationFrame(toolFrame);toolFrame=requestAnimationFrame(syncWorkspace);});

 // Reutilizar las acciones reales del motor; no duplicar paletas ni estado.
 const originalPalette=$('sedePaletaAleatoria'),originalUndo=$('sedePaletaDeshacer'),out=$('out');
 const previewTitle=$('previewTitulo');
 const previewVariant=document.createElement('p');previewVariant.className='and-preview-variant';previewVariant.hidden=true;
 previewTitle.parentElement.after(previewVariant);
 const paletteBar=document.createElement('div');paletteBar.className='and-palette-bar';paletteBar.hidden=true;
 const random=document.createElement('button');random.type='button';random.className='and-palette-random';random.innerHTML=svg('paleta')+'<span>Colores aleatorios</span>';
 const undo=document.createElement('button');undo.type='button';undo.className='and-palette-undo';undo.textContent='Deshacer';undo.setAttribute('aria-label','Deshacer combinación de colores');
 paletteBar.append(random,undo);acceso.after(paletteBar);
 const paletteAvailable=()=>inEditor()&&regionalPalette()&&!originalPalette.hidden;
 const formatoRapido=document.createElement('div');formatoRapido.className='and-preview-formats';formatoRapido.hidden=true;
 formatoRapido.setAttribute('role','group');formatoRapido.setAttribute('aria-label','Formato del arte');
 out.before(formatoRapido);
 let selectorFormato=null;
 for(const [formato,rotulo] of [['post','Publicación'],['historia','Historia']]){
  const boton=document.createElement('button');boton.type='button';boton.textContent=rotulo;boton.dataset.andFormato=formato;
  boton.addEventListener('click',()=>{
   if(!selectorFormato)return;
   const valor=selectorFormato.id==='f'?(formato==='post'?'1350':'1920'):formato;
   if(selectorFormato.value===valor)return;
   selectorFormato.value=valor;
   selectorFormato.dispatchEvent(new Event(selectorFormato.id==='sedeFormato'?'change':'input',{bubbles:true}));
   sincronizarFormatoAndroid();
  });
  formatoRapido.append(boton);
 }
 function sincronizarFormatoAndroid(){
  const familia=activeImageFamily();
  const id={ad:'adV',sede:'sedeFormato',dui:'f'}[familia?.id];
  const select=id?$(id):null;
  const opciones=select?[...select.options].filter(x=>!x.disabled&&!x.hidden).map(x=>x.value):[];
  const apto=!(id==='sedeFormato'&&$('sedeFormatoWrap')?.hidden)&&opciones.includes(id==='f'?'1350':'post')&&opciones.includes(id==='f'?'1920':'historia');
  // Jornada individual ya tiene su selector propio en el motor común.
  const propio=id==='adV'&&$('adT').value==='actividad-consular-individual';
  selectorFormato=inEditor()&&mode==='preview'&&apto&&!propio?select:null;
  formatoRapido.hidden=!selectorFormato;
  if(!selectorFormato)return;
  for(const boton of formatoRapido.children){
   const v=id==='f'?(boton.dataset.andFormato==='post'?'1350':'1920'):boton.dataset.andFormato;
   boton.setAttribute('aria-pressed',String(v===selectorFormato.value));
  }
 }
 function syncPalette(){
  sincronizarFormatoAndroid();
  const available=paletteAvailable()&&(mode==='preview'||!workspace.hidden);
  const regionalReview=inEditor()&&mode==='preview'&&regionalPalette();
  const variant=regionalReview?resolveTemplate(currentTemplate())?.variant?.nombre:'';
  root.classList.toggle('and-regional-review',regionalReview);
  const title=regionalReview?'Oficinas regionales':'Vista previa';
  const editLabel=regionalReview?'Editar información':'Editar';
  if(previewTitle.textContent!==title)previewTitle.textContent=title;
  if(editStep.textContent!==editLabel)editStep.textContent=editLabel;
  if(previewVariant.textContent!==(variant||''))previewVariant.textContent=variant||'';
  previewVariant.hidden=!variant;
  const busy=out.getAttribute('aria-busy')==='true';
  paletteBar.hidden=!available;
  if(mode==='form'&&paletteBar.parentElement!==workspace)acceso.after(paletteBar);
  if(mode==='preview'&&paletteBar.parentElement!==out.parentElement)out.before(paletteBar);
  random.disabled=!available||busy||originalPalette.disabled;
  undo.disabled=!available||busy||originalUndo.hidden||originalUndo.disabled;
 }
 // La regeneración puede vaciar temporalmente #out y reducir la altura del
 // documento. Mantener su espacio y el scroll hasta que terminen los lienzos.
 let paletteScroll=null;
 function runPaletteAction(action){
  paletteScroll?.cancel();
  if(mode==='form'){action.click();syncPalette();return;}
  const scrolling=document.scrollingElement||root;
  const positions=[{el:scrolling,top:scrolling.scrollTop,left:scrolling.scrollLeft}];
  for(let el=out.parentElement;el&&el!==scrolling;el=el.parentElement){
   if(el.scrollTop||el.scrollLeft||(/auto|scroll/.test(getComputedStyle(el).overflowY)&&el.scrollHeight>el.clientHeight))positions.push({el,top:el.scrollTop,left:el.scrollLeft});
  }
  const height=out.style.getPropertyValue('min-height'),priority=out.style.getPropertyPriority('min-height');
  const minHeight=Math.max(out.getBoundingClientRect().height,parseFloat(getComputedStyle(out).minHeight)||0);
  out.style.setProperty('min-height',Math.ceil(minHeight)+'px');
  paletteBar.dataset.andPaletteRendering='true';
  const started=performance.now();let lastChange=started,frame=0,closed=false;
  const changes=new MutationObserver(()=>{lastChange=performance.now();});
  changes.observe(out,{childList:true,subtree:true,attributes:true,attributeFilter:['src','aria-busy']});
  const restore=()=>{
   if(mode!=='preview'||!paletteAvailable())return;
   for(const {el,top,left} of positions){
    if(Math.abs(el.scrollTop-top)>0.5||Math.abs(el.scrollLeft-left)>0.5)el.scrollTo({top,left,behavior:'instant'});
   }
  };
  function cleanup(preserve){
   if(closed)return;closed=true;cancelAnimationFrame(frame);changes.disconnect();
   document.removeEventListener('pointerdown',interrupt,true);
   document.removeEventListener('touchstart',interrupt,true);
   document.removeEventListener('wheel',interrupt,true);
   document.removeEventListener('keydown',interrupt,true);
   if(height)out.style.setProperty('min-height',height,priority);else out.style.removeProperty('min-height');
   if(preserve)restore();
   delete paletteBar.dataset.andPaletteRendering;
   if(paletteScroll===operation)paletteScroll=null;
  }
  function interrupt(e){
   if(e.type==='keydown'&&!['ArrowDown','ArrowUp','PageDown','PageUp','Home','End',' '].includes(e.key))return;
   if(paletteBar.contains(e.target))return;
   cleanup(false);
  }
  function tick(now){
   if(closed)return;
   if(mode!=='preview'||!paletteAvailable()){cleanup(false);return;}
   restore();
   const busy=out.getAttribute('aria-busy')==='true';
   const loaded=Array.from(out.querySelectorAll('img')).every(img=>img.complete);
   if((!busy&&loaded&&now-lastChange>=400)||now-started>=15000){cleanup(true);return;}
   frame=requestAnimationFrame(tick);
  }
  const operation={cancel:()=>cleanup(false)};paletteScroll=operation;
  for(const event of ['pointerdown','touchstart','wheel','keydown'])document.addEventListener(event,interrupt,{capture:true,passive:true});
  try{action.click();syncPalette();restore();frame=requestAnimationFrame(tick);}
  catch(error){cleanup(true);throw error;}
 }
 random.addEventListener('click',()=>{if(!random.disabled&&paletteAvailable())runPaletteAction(originalPalette);});
 undo.addEventListener('click',()=>{if(!undo.disabled&&paletteAvailable())runPaletteAction(originalUndo);});
 const paletteObserver=new MutationObserver(syncPalette);
 for(const el of [originalPalette,originalUndo,$('sedePanelColores'),out,stage,map,layout])paletteObserver.observe(el,{attributes:true,attributeFilter:['hidden','disabled','aria-busy']});
 document.addEventListener('change',()=>queueMicrotask(syncPalette));
 document.addEventListener('input',()=>queueMicrotask(syncPalette));
 // Vista inmersiva: sólo presenta las imágenes que ya produjo el motor.
 const immersiveOpen=document.createElement('button');
 immersiveOpen.type='button';immersiveOpen.className='and-viewer-open';immersiveOpen.hidden=true;
 immersiveOpen.innerHTML=svg('ampliar')+'<span>Ver a pantalla completa</span>';
 out.before(immersiveOpen);
 const viewer=document.createElement('dialog');viewer.className='and-viewer';viewer.setAttribute('aria-labelledby','andViewerTitle');
 viewer.innerHTML='<header><button type="button" data-and-viewer-close aria-label="Cerrar vista completa">'+svg('cerrar')+'</button><h2 id="andViewerTitle">Vista previa</h2><span class="and-viewer-count" role="status"></span></header><div class="and-viewer-stage"><img alt=""></div><footer><button type="button" data-and-viewer-prev aria-label="Arte anterior">'+svg('anterior')+'</button><button type="button" data-and-viewer-edit>Editar</button><button type="button" data-and-viewer-next aria-label="Arte siguiente">'+svg('siguiente')+'</button></footer>';
 document.body.append(viewer);
 const viewerImage=viewer.querySelector('img'),viewerCount=viewer.querySelector('.and-viewer-count'),viewerPrev=viewer.querySelector('[data-and-viewer-prev]'),viewerNext=viewer.querySelector('[data-and-viewer-next]');
 let viewerArts=[],viewerIndex=0,viewerTouch=null,viewerPosition=null,viewerEditing=false;
 function availableArts(){return [...out.querySelectorAll('figure img')].filter(i=>i.getAttribute('src')&&i.complete&&i.naturalWidth>0);}
 function syncImmersive(){
  immersiveOpen.hidden=!(inEditor()&&mode==='preview'&&availableArts().length);
  if(root.classList.contains('and-regional-review')){
   if(out.nextElementSibling!==immersiveOpen)out.after(immersiveOpen);
  }else if(out.previousElementSibling!==immersiveOpen)out.before(immersiveOpen);
 }
 function showViewerIndex(index){
  if(index<0||index>=viewerArts.length)return;
  viewerIndex=index;const art=viewerArts[index];viewerImage.src=art.src;
  viewerImage.alt=art.alt||'Arte '+(index+1);
  viewerCount.textContent=(index+1)+' / '+viewerArts.length;
  viewerPrev.disabled=index===0;viewerNext.disabled=index===viewerArts.length-1;
 }
 immersiveOpen.addEventListener('click',()=>{
  viewerArts=availableArts().map(i=>({src:i.currentSrc||i.src,alt:i.alt}));
  if(!viewerArts.length||viewer.open)return;
  viewerPosition={top:window.scrollY,left:window.scrollX};viewerEditing=false;showViewerIndex(0);viewer.showModal();
 });
 viewer.querySelector('[data-and-viewer-close]').addEventListener('click',()=>viewer.close());
 viewer.querySelector('[data-and-viewer-edit]').addEventListener('click',()=>{viewerEditing=true;viewer.close();setMode('form',true);});
 viewerPrev.addEventListener('click',()=>showViewerIndex(viewerIndex-1));
 viewerNext.addEventListener('click',()=>showViewerIndex(viewerIndex+1));
 viewer.addEventListener('keydown',e=>{
  if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();showViewerIndex(viewerIndex+(e.key==='ArrowLeft'?-1:1));}
 });
 const viewerStage=viewer.querySelector('.and-viewer-stage');
 viewerStage.addEventListener('touchstart',e=>{viewerTouch=e.touches.length===1?{x:e.touches[0].clientX,y:e.touches[0].clientY}:null;},{passive:true});
 viewerStage.addEventListener('touchend',e=>{
  const start=viewerTouch;viewerTouch=null;if(!start||e.changedTouches.length!==1)return;
  const dx=e.changedTouches[0].clientX-start.x,dy=e.changedTouches[0].clientY-start.y;
  if(Math.abs(dx)>55&&Math.abs(dx)>Math.abs(dy)*1.5)showViewerIndex(viewerIndex+(dx<0?1:-1));
 },{passive:true});
 viewerStage.addEventListener('touchcancel',()=>{viewerTouch=null;});
 viewer.addEventListener('close',()=>{
  viewerImage.removeAttribute('src');viewerArts=[];viewerTouch=null;
  if(viewerPosition&&!viewerEditing){const saved=viewerPosition;requestAnimationFrame(()=>window.scrollTo({top:saved.top,left:saved.left,behavior:'instant'}));}
  viewerPosition=null;
 });
 new MutationObserver(syncImmersive).observe(out,{childList:true,subtree:true,attributes:true,attributeFilter:['src']});
 out.addEventListener('load',syncImmersive,true);
 const resumeAvailable=()=>!$('osContinue')?.hidden||(!$('cerrarMapa')?.hidden)||inEditor();
 const setMode=(next,focus=false)=>{
  if(focus||next!=='preview')regionalLanding=false;
  mode=next;root.dataset.andEditor=mode;syncWorkspace();syncPalette();syncImmersive();
  for(const b of steps.children)b.setAttribute('aria-pressed',String(b.dataset.andStep===mode));
  if(!inEditor()||!focus)return;
  $(mode==='form'?'uxEdit':'uxPreview').click();
 };
 function sync(){
  const searching=[$('osHomeSearch'),$('buscarPlantillas')].includes(document.activeElement);
  const active=!searchScreen.hidden?'buscar':settings.open?'ajustes':searching?'buscar':!stage.hidden?'inicio':!map.hidden?'crear':'editar';
  for(const b of nav.children){
   if(b.dataset.andNav===active)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');
   b.disabled=b.dataset.andNav==='editar'&&!resumeAvailable();
  }
  root.classList.toggle('and-editing',inEditor());syncWorkspace();syncPalette();syncImmersive();recordTemplate();
 }
 function closeSettings(){if(settings.open){settings.close();stage.inert=false;main.inert=false;sync();}}
 function openSettings(){if(!settings.open){settings.show();stage.inert=true;main.inert=true;sync();}}
 settings.addEventListener('close',()=>{stage.inert=false;main.inert=false;sync();});
 settings.querySelector('[data-and-close]').addEventListener('click',closeSettings);
 const help=document.createElement('dialog');help.className='and-help';help.setAttribute('aria-labelledby','andHelpTitle');
 help.innerHTML=`<header><div><p class="and-help-kicker">GUÍA RÁPIDA</p><h2 id="andHelpTitle">Ayuda</h2></div><button type="button" data-and-help-close aria-label="Cerrar ayuda">×</button></header>
 <p class="and-help-description"></p>
 <section class="and-help-updates" aria-labelledby="andHelpUpdates">
  <div class="and-help-section-title"><span class="and-help-icon" aria-hidden="true">↻</span><div><h3 id="andHelpUpdates">Actualizar Exterior</h3><small>Guía paso a paso</small></div></div>
  <ol class="and-help-steps">
   <li><strong>Descargar la versión nueva</strong>
    <p>En Exterior, abrir Ajustes y pulsar «Buscar actualizaciones». Si hay una versión nueva de la aplicación, pulsar «Instalar actualización» y esperar la descarga.</p>
    <div class="and-help-path">${svg('ajustes')}<span>Ajustes de Exterior</span><span aria-hidden="true">›</span><span>Buscar actualizaciones</span></div>
   </li>
   <li><strong>Dar permiso si Android lo pide</strong>
    <p>En el aviso de Android, pulsar «Ajustes». Activar «Permitir desde esta fuente» solo para la app que abrió el archivo. Volver al instalador. Si se cerró, volver a abrir el APK o pulsar «Instalar actualización» otra vez.</p>
    <div class="and-help-path">${svg('ajustes')}<span>Permitir desde esta fuente</span><span aria-hidden="true">◉</span></div>
   </li>
   <li><strong>Confirmar la actualización</strong>
    <p>Cuando Android muestre «¿Quieres actualizar esta app?» y el nombre Exterior, pulsar «Actualizar». Abrir Exterior y comprobar la versión en Ajustes. Retirar el permiso que se habilitó para instalar.</p>
    <div class="and-help-path">${svg('documento')}<span>Exterior</span><span aria-hidden="true">›</span><span>Actualizar</span></div>
   </li>
  </ol>
  <div class="and-help-casos">
   <details><summary>Si ya descargó el archivo APK</summary>
    <p>Abrir «Descargas» en el navegador o en «Mis archivos». Tocar el APK más reciente obtenido de g-polex.github.io. Si Android pide permiso, seguir el paso 2.</p>
    <div class="and-help-path">${svg('documento')}<span>Descargas</span><span aria-hidden="true">›</span><span>Exterior…apk</span></div>
   </details>
   <details><summary>Si Samsung bloquea la instalación</summary>
    <p>El aviso puede decir «Aplicaciones desconocidas bloqueadas». En los ajustes del teléfono, entrar en Seguridad y privacidad y abrir «Bloqueador automático».</p>
    <div class="and-help-path">${svg('ajustes')}<span>Ajustes del teléfono</span><span aria-hidden="true">›</span><span>Seguridad y privacidad</span><span aria-hidden="true">›</span><span>Bloqueador automático</span></div>
    <p>Si el APK es el oficial y el teléfono permite cambiar ese ajuste, desactivar el bloqueador durante la instalación. Si Samsung lo pide, confirmar con el desbloqueo del teléfono. Volver al instalador y activar el bloqueador de nuevo al terminar. En un equipo administrado, consultar a soporte si el ajuste no está disponible.</p>
   </details>
   <details><summary>Si aparece Google Play Protect</summary>
    <p>Si solicita analizar el archivo, aceptar y esperar el resultado. Continuar solo si Android permite instalarlo. Si Play Protect detecta una aplicación dañina o bloquea la instalación, cancelar y consultar a soporte. Mantener Play Protect activado.</p>
   </details>
   <details><summary>Actualizar solo los recursos</summary>
    <p>Si Exterior ofrece «Descargar actualización» para los recursos, pulsar ese botón. Al terminar, tocar «Reiniciar y aplicar». Esta opción no requiere abrir un APK.</p>
   </details>
  </div>
 </section>`;
 document.body.append(help);
 help.querySelector('button').addEventListener('click',()=>help.close());
 function openHelp(){
  const description=!stage.hidden?'Elegir una plantilla desde los accesos rápidos o el catálogo. Para retomar un arte, seleccionar Continuar edición.':
    !map.hidden?'Buscar por nombre o seleccionar una categoría. Elegir la variante que corresponda al arte.':
    mode==='form'?'Completar los campos del arte y pulsar «Revisar arte». Abrir «Más opciones» si hace falta ajustar el formulario.':
    'Revise el arte y descárguelo desde esta pantalla. Exterior guarda los archivos en Descargas/Exterior.';
  help.querySelector('.and-help-description').textContent=description;if(!help.open)help.showModal();
 }
 function openNews(){
  closeSearch();closeSettings();
  if(!news.open){news.showModal();news.scrollTop=0;}
 }
 if(updates){
  const checkUpdates=document.createElement('button');
  checkUpdates.type='button';checkUpdates.className='and-setting-action';checkUpdates.textContent='Buscar actualizaciones';
  settings.querySelector('#andVersion').closest('section').append(checkUpdates);
  checkUpdates.addEventListener('click',()=>{openNews();updates.querySelector('.and-update-check').click();});
 }
 function topActions(container){
  const bar=document.createElement('div');bar.className='and-top-actions';
  for(const [key,label,action] of [['ayuda','Ayuda',openHelp],['novedades','Novedades',openNews]]){
   const b=document.createElement('button');b.type='button';b.dataset.andTop=key;b.setAttribute('aria-label',label);b.title=label;
   b.innerHTML=svg(key)+(key==='novedades'?'<span class="and-news-dot" hidden></span>':'');
   b.addEventListener('click',action);bar.append(b);
  }
  container.prepend(bar);
 }
 topActions(stage.querySelector('.os-stage-toolbar'));topActions(main.querySelector('.exterior-marca'));
 function syncNews(){const available=document.querySelector('.exterior-android-updates')?.dataset.andNews==='true';for(const dot of document.querySelectorAll('.and-news-dot'))dot.hidden=!available;}
 const updatePanel=document.querySelector('.exterior-android-updates');if(updatePanel)new MutationObserver(syncNews).observe(updatePanel,{attributes:true,attributeFilter:['data-and-news']});syncNews();
 settings.addEventListener('click',e=>{if(e.target===settings){const r=settings.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeSettings();}});
 nav.addEventListener('click',e=>{
  const b=e.target.closest('[data-and-nav]');if(!b||b.disabled)return;
  const key=b.dataset.andNav;
  if(key==='buscar'){openSearch();return;}
  closeSearch();
  if(key==='ajustes'){openSettings();return;}
  if(key==='inicio'){goHome();return;}
  closeSettings();
  if(key==='crear'){
   homeEntryRoute='';saveEditor();if(!stage.hidden)homeScroll=stage.scrollTop;
   if(!stage.hidden)stage.querySelector('[data-os-action="map"]').click();
   else if(map.hidden)$('abrirMapa').click();
   else{ $('buscarPlantillas').value='';$('buscarPlantillas').dispatchEvent(new Event('input',{bubbles:true})); }
  }
  if(key==='editar'){
   if(inEditor()){sync();return;}
   resuming=true;
   if(!stage.hidden)$('osContinue').click();
   else{if(!map.hidden&&!$('cerrarMapa').hidden)$('cerrarMapa').click();finishResume();}
  }
  sync();
 });
 $('osContinue').addEventListener('click',()=>{resuming=true;finishResume();},true);
 for(const input of [$('osHomeSearch'),$('buscarPlantillas')]){input.addEventListener('focus',sync);input.addEventListener('blur',()=>queueMicrotask(sync));}
 steps.addEventListener('click',e=>{const b=e.target.closest('[data-and-step]');if(b)setMode(b.dataset.andStep,true);});
 // Los accesos internos y el historial preexistentes siguen funcionando.
 document.addEventListener('click',e=>{
  if(!inEditor())return;
  if(e.target.closest('#uxEdit,#volverEdicion,#proyBackEdit'))setMode('form');
  if(e.target.closest('.prensa-generar')){closeTool(false);setMode('preview',true);return;}
  if(e.target.closest('#uxPreview,#irVistaPrevia,#proyPreviewJump'))setMode('preview');
 },true);
 let wasEditor=inEditor();
 const observer=new MutationObserver(()=>{
  const now=inEditor();
  if(now&&!wasEditor&&!resuming){savedEditor=null;regionalLanding=regionalPalette();setMode(regionalLanding?'preview':'form');}
  wasEditor=now;sync();
 });
 for(const el of [stage,map,layout,$('osContinue'),$('cerrarMapa')])if(el)observer.observe(el,{attributes:true,attributeFilter:['hidden']});
 const oldBack=window.exteriorAndroidBack;
 window.exteriorAndroidBack=function(){
  if(openTool){closeTool();return;}
  if(viewer.open){viewer.close();return;}
  if(help.open){help.close();return;}
  if(news.open){news.close();return;}
  if(!searchScreen.hidden){closeSearch();return;}
  if(settings.open){closeSettings();return;}
  if(inEditor()&&mode!=='form'&&!regionalLanding){setMode('form',true);return;}
  // El catálogo general siempre permite regresar a Inicio. Si se abrió una
  // categoría directamente desde Inicio, volver a ese origen sin un paso extra.
  const sameEntry=homeEntryRoute&&homeEntryRoute===entryRouteKey();
  if(stage.hidden&&!map.hidden&&!$('buscarPlantillas').value&&
     (history.state?.vistaExterior==='plantillas'||sameEntry)){goHome();return;}
  if(inEditor()&&sameEntry&&!$('disenosExterior')?.open&&!$('compararVariantes')?.open){goHome();return;}
  if(typeof oldBack==='function')oldBack();
 };
 const categoryIcons={prensa:'documento',sede:'sede',ad:'calendario',efemerides:'calendario','atencion-consular':'consular',avisos:'aviso',interno:'interno','otras-instituciones':'otros'};
 function decorate(){
  for(const b of $('osFamilyList').querySelectorAll('[data-os-family]')){
   const icon=b.querySelector('.os-stage-number');if(icon&&!icon.querySelector('svg')){icon.innerHTML=svg(categoryIcons[b.dataset.osFamily]||'documento');icon.setAttribute('aria-hidden','true');}
  }
 }
 new MutationObserver(decorate).observe($('osFamilyList'),{childList:true});decorate();
 // La identidad es informativa: no es un acceso de regreso a la portada.
 const brand=stage.querySelector('.os-stage-brand');
 if(brand){const identity=document.createElement('div');identity.className=brand.className;while(brand.firstChild)identity.append(brand.firstChild);brand.replaceWith(identity);}
 const headerBrand=$('osHomeHeader');if(headerBrand){headerBrand.removeAttribute('href');headerBrand.removeAttribute('title');headerBrand.removeAttribute('aria-label');headerBrand.setAttribute('tabindex','-1');headerBrand.addEventListener('click',e=>{if(e.isTrusted){e.preventDefault();e.stopImmediatePropagation();}},true);}
 // Unificar la identidad en catálogo, editor, vista previa y ajustes.
 if(headerBrand){const block=headerBrand.querySelector('.exterior-identidad');if(block){const ministry=document.createElement('span');ministry.className='and-ministry';ministry.textContent=stage.querySelector('.os-stage-identity span').textContent;block.append(ministry);}}
 // Inicio se concentra en la barra inferior permanente.
 const settingsHeader=settings.querySelector('header');
 const compactBrand=stage.querySelector('.os-stage-brand').cloneNode(true);compactBrand.className='and-compact-brand';for(const node of compactBrand.querySelectorAll('[id]'))node.removeAttribute('id');
 settingsHeader.insertBefore(compactBrand,settingsHeader.querySelector('h2'));
 // Inicio: marca original completa, con las dos franjas superiores.
 // La identidad institucional se conserva en las pantallas de trabajo y Ajustes.
 const homeBrand=stage.querySelector('.os-stage-brand');
 homeBrand.querySelector('.os-stage-identity').hidden=true;
 homeBrand.setAttribute('role','img');
 homeBrand.setAttribute('aria-label','Exterior');
 // Registrar la ruta de entrada directa, sin duplicar el historial del motor.
 function entryRouteKey(){const p=new URLSearchParams(location.hash.slice(1));return JSON.stringify([p.get('vista'),p.get('tipo'),p.get('arte')||'']);}
 function openHomeFamily(family){
  const target=$('osFamilyList').querySelector('[data-os-family="'+family+'"]');
  if(!target||stage.hidden)return;
  homeEntryRoute='';target.click();
  queueMicrotask(()=>{if(stage.hidden&&(!map.hidden||inEditor()))homeEntryRoute=entryRouteKey();});
 }
 // Accesos de uso habitual: reutilizan los botones reales del catálogo.
 const quick=document.createElement('section');quick.className='and-quick';quick.setAttribute('aria-labelledby','andQuickTitle');
 quick.innerHTML='<h2 id="andQuickTitle">Accesos rápidos</h2><div class="and-quick-grid"></div>';
 const shortcuts=[['prensa','Comunicados','documento'],['avisos','Avisos','aviso'],['sede','Artes para sede','sede'],['atencion-consular','Atención consular','consular']];
 for(const [family,label,key] of shortcuts){const b=document.createElement('button');b.type='button';b.dataset.andQuick=family;b.innerHTML='<span class="and-quick-mark">'+svg(key)+'</span><span>'+label+'</span>';b.addEventListener('click',()=>openHomeFamily(family));quick.querySelector('.and-quick-grid').append(b);}
 stage.querySelector('.os-stage-grid').append(quick);
 // Explorar categorías con miniaturas reales y representativas del catálogo.
 const recentSection=document.createElement('section');recentSection.className='and-recent-templates';recentSection.setAttribute('aria-labelledby','andRecentTitle');
 recentSection.innerHTML='<div class="and-recent-head"><h2 id="andRecentTitle">Más recientes</h2><button type="button" data-and-catalog>Ver todas</button></div><div class="and-recent-list"></div>';
 quick.after(recentSection);
 const recentList=recentSection.querySelector('.and-recent-list');
 recentSection.querySelector('[data-and-catalog]').addEventListener('click',()=>nav.querySelector('[data-and-nav="crear"]').click());
 const muestras = {
  "consular-cartelera": "data:image/webp;base64,UklGRjAOAABXRUJQVlA4ICQOAACwOgCdASqKAKUAPj0ci0QiIaEUaOUAIAPEsrd+PkxwBZdgqDNCDzP477H+k8g19b/VfrX7m/zN5u3ru/6vqv/rX/L9Qn7M/tB70/ok/z/qG/17qKPQg8ur9pvhf/yv/f9Kfr89Qh4Xfi/xs9A/EB5P9tf6r7QWX/qa/mfQ3+T/Yz8V/Xf3F9hP7x4M++b+l/HT4AvxP+Z/2b8o/baeRaJ+gR6j/L/8n+avncf2voN9Qv8T+YH0AfxX+Sf4r+ofuZ6t3hJfQ/8p7AH8n/oP/D/w37k/8b6YP5T/if438tfcT+df2z/e/4/95f8R9gv8n/pP+v/uH74/6H5jvYV+t/svfrgYuW5Rb7qvQqJ1rgHnHp6qovvp+aDSS561wNoXqfdjhbVvmO6y1rKouvjMFmxvySFLevQkzXIRQEAvjAM6ScGtn8o0LyFnqWD8ZDwjJ1LUYATEfV/nZofH1Fsc0Di0Q5n60trlaZHnT3s1dbgSP76UpmUriPRLWVDajm5ulmjSuvZwg+8SxkH6XjUbalYPMAQLiY9qH71sDTqfmich6VO5etvxNAlcCLzPqWRR8tZ5IYYJodj+UQZok8KnRp/KpcgP6ckRo5Xx7Ipk9t92krEt8DLfdpKxLfAy31oAAP7/qcYdENkbd+6Pw043KwhpLvQa7GNvGzVFFqnu/xHNOFR5pHtMmz5bki9zQlwBaJTWZ7N+JtlXQCtBfoTSlu+2v+HXy2TJX8EHAr+tOAiI0WuAa/hNYiyAhHO58Ylbf8RT/+WPsg0F601foZos7N8ghSC11VJjntOQh20sJeT+HESpD4kKaqvGrWdNbCY8vxyOhfrPLkiOawlcQ1RpKknXQgGmIuyJ6ACOl7d0svDcKzpwCxkWJ/ZM95uQARhz+AX3Y79oHhTvMQAJQ19RaFrtUFVTDZ38aHELjVgsP46c9IEPHihNriFtoQus8jQ/nhD8penoTuI5p1Md0x6B32kdnwWF7hlpyl4vGwTEnMZ4LSDPa0eBRVSFhYJtXOuWXA8pvkTrKLWE8iORI3w+ty6kzYGI8bJbk6Zivinj8yqkscXKKzrCE5K0Oex3v1eLJFn/nJpZ9Mze74C5VuS7TrIJXxkf1F2FlyigMn8teEshw5qBptzOmOFUGgeSyQfTRqZc/ll4Tl6trR+Z6V1ZYW97r5AB2IYFJaYreQlVbFVtEiIhfXzneSPoRoZ7IOloYqEGCWfG5qBkCfnITPqAWyd8iiuvhAihu2gAXLLl9phigM6t7Ow6btbyHY9Bnfcc/LEqABFPFfa7FxF3KKQ/4MZmKw5/la3UisoUgkQ7LqiE8VzytQYkmTxDMzS6WgyGa62wr3NWAQL8b74cWf7JRHmmbuXiiCmNeZ9DoO3X4L24lmR2Ry/xjKCFp99pPtD0a1nkG1t41ZG2ceTcssUwNMNrb2S/sV04QAkh1eIhmQ5d1kDsZkUcnDGCNpPV31WK3MASaFdUjiDxZoOaEYiA+U9+wBMj/YqzehYyLKrjWP7VuVXhvtxXlYrdNcArJuZQJ0EnF2Xrn5PbZXsp1oWj1AEjxBmcUq+5hEmp6pBypJuLnDo5i0cdKTKdfsWXmkltfuNdmkWyXRhhDo/3Sfvey3mbYwIOjtF8gGVQx8aQQYRYjs53QxEkA8NqXM41VY+sa3v7gAu+mF7iDrNVl0c46ikFSYNcALuAd9N7B0FqjCGuEZhLJNAZwCl/5nlo78F71D1X99tq2TISSCCRs01iGINbiTYxA/4I8byyYke74ydwQAx797hEiEyDyzSJjvJK6Atp8BDSYk7IpXvxTv6VUwXYMLIoirV8dD+JWJgE4rSec9cPaxULbyE6B6KCuI5nBIDeLVv+23vOL4Kzbi13+mgAsOivfdRuQf6q4p8uw3fEmNYjhCHkldiDlJOY1HTSZKpnUdjzwVhip95+7vs7a/Jp3FNjDnGB3h2PLVH0Wd7EKqMdVARwofyO8wxShTpBTUYjP7KqSMV1c/+wUqt/6GUaYUpWi9OcMQOUmqibb3H1WHhwT3v8QIXwRARB8DBcHd2I0Q7/XLm51A1jvB2e+/93Uv+EjEU/mJ3z/NkptTH+KRNBmIdLf78dH8RV3n+PVhVM/4ZyzNl9DP6iFSIQYsBv8wP1614am51cb7Xeeb8VPlatLtWW8DESaBwcv+rz5Y2LS9qeO6UXpSXIvjxyXrJeQ3AYpA6qVkbuM6Mt7zeDvAEvxpi1I1T2tm0AX3nlI6Dsz8o7YR57GGzrUlS38VYm/Ls875YJfgnGDG9CyJGhjisBcncES20yXrhN8nsyTak8ka1XRnVIBDNG3PHRpyrIx75yIWILTIMgHiLMPHse81AkBXyiEPsJ7bAqskWyeJNGn9aqpp+nN4DqN5lFrnvmG6W1/n99VJNPtc2zzJfucIY/QIBprAeEgMLSZBpatkL2DguWpe7xbRk2hxnshjm/Rit3BDya0X/Ffrqo4R1gc9Gv96XYxEwb0V46yeDZ+xaFdLoJJh6RJ43b+4pIQrmu7gs/nrPxpehXFoJYXkvgiKjIqsfqIGp+XL9pJbnAyry8ogIwv6pE9vu3lEEJBubPy6PzYSEb3PG6BbAcxq8icH/1EbKZrFRsHz4r4y4aTm/y81nWzzy6cjHHUhBm5KjBhvl3S3q7V1FyUaftvt6Tqqj4rNV+g1KZI/LqSwXJ+rDrnwa7H11SAbe6BkHkyWBssx/1qGlvktSxpmhhPlngkPViTl41guxfyrJRrQ9HhSfDlEqRrKEOd8kS4j4m/0C41kX3MC/6AcYYrUf6uJPRzm3A1Wdao0WxM28AgB45KFjST3lrUkfcNOig3rCsPhxs+KglZ40OlMIDcW/GlBbX3ZMT5n2AfSCNQRCsD7YQZempjmv4mzorS15X6Kp/2lrH/4+6bdCwLQKMWbQj21tFuhnPZQE84Gz0VC5vIhmMTot66jPo3wv8eRZ7Apv7V12AQe7EMcxNGwaut9RiybXaa+uf+i0BjXzkFn+38T/4N5CHmLN9xT4GgyhXVVnL2suvxj5JlXsSazY7Q543eJXxs02zpKnYjXvMga9wXj2F9ODCeAO7iaBKfjmpN/i8PxykoIBoQzWncg7wnx0WBWSKJO9iepRPYnIpKQW6lICbJc8q+GT2SeOqueUqRVqL/WOMLF8DkG6/pvph/ZE+bG8hJSNAG0OVt3PS0/2K4tmsmfVtd8OAPjcsz+9wcQLfjIIHALOrOEHeioT5BsFEmaGxmaAbVLmyKdMbL8Gfzy+tgHy4ET7hJu0DvQRpz3xeDVf4a2+ObmUipha+jmnf+UPZW/PCf4h4IIHji3RzhtLT5RDkn2yiHwgVsG4by+mQuR5Bc3z4C3g5AXbo8jnzCgCn1mY8j2U6IhKtIVINLwGlLfz86ulE4ClPUs2J0W6EnT3RHdUczAwgu0q9HaBlm1aHupdXQlBRYLL0fw8oJNLyEWLj6qCYKhgvE8gQcJyUfJt+AsTmbj5TXWWcTUA5e31gadRhc/Zp7q24rRzJOBk4rsFwRnHjXDhqaU9LTP8gOCkNsfNHxm52IKpts8vf8XulXuYI0hzRaVyPcBrFzZc3KoSegbPOzhyd5big86P3IR30X5n72emk9P3qDK4c8T4ddVyhfDMLRkIJpoGrcEJhG5cLiDYLzCKaaI+F6cX3M5qzpd2uhYHmKjpbEhEmlexnhDZ1EKWw4iZezuuK4o+7UQMUtexPQk7iTtg4NYC+g88pGnMaT255iG1ADV796SOamuucME4f+23XCri78KhV/5StuaQvULWDPN9fSnjb4ivRQk8EqV33x9ScCSPwyHPvoflw4hZez4aBFQNqbAVJGqnAlI8hGDdRZMOpRMmcVqjQpNmCSY/Zy6IZPjIAavyxiC3ZNg6En7d0bod+ahxgKOYWLPJ8XpVz6Ua0G5sMn8BF7YR4+YkuTs9old0xNBa33Y3mEi3pXjG/8Qty1B+H/717wnZIjXOJLDEBVmSi0P8te9O9RdZNEcFW1uLUWTsSvhvCKvsbus3phDtUvUAQUl9JetvwpbWR/e9H6I4pRtFGo2S/pf6pvoUO6mcato78jjVeh5LixiV+uQuzQheZhe2Kt9bB+SpE9OaFzQZvPsaCLCAlC9LRYaDNrhIKkaR510JpRWbDcnxuL6JLEhsXyddI7pzqb9XfITeNWk2sTysmFEsbD3YOSX02c4zGq+GrPnCVPTrZgCrzkMrC12bxqkVSkecMGJEk+zAe9jjrRrPtU2Azzih+iEl5LWyXeup6hmiWMaLkVqLtrOWqpCU3njBI7D0txe+rKU0gCdfOLz8Kc1PCVpwbazZKtOEJ/0Y/6hVEUi+Ps+js9EMzOj9edYBtVnlLaCqb5PwbZifslQKMpnAaXiwAQmznBV9FCETXMhy35S08NX3SSkJ3Kw8lyL8rcYuXaEDqLToGJt2zBLxtypX7vsPhsSPmtZe/ztujtdPrGN507LYVQFvoouWcWYXqUHvAq0C88cfJ3K1cQKvV1/Gt1Fck8xGhOHjPOnU8I7RAu+T9CuJxQv/NMlJnQDTEPT2z0/4UvXb2GNTu0VtV9jfe40+IUcqkBFlKGXS5RK0l9ax4mtLaPO70s+K2ZAwloWPoxIlUk9wJZvA50M4j2TzajoCVSaoA1KQZ/rkiLGSvq74MthlApal0z0733L2f2yQtKYdhk3MpQy8+dUa/d8PTaYBiH8zOVxHdm9nciPMDcjhv7gvwH8HNP/wAhccYO4IgfkzzNX2cYfzXS4l/TU2NzqZyDU8XfEhXh62hvo/f9rZjnP4PtA0QEA/gTRhpUOtD1laKvV7yjwAA8YAAAAAAAA==",
  "interno-proyeccion": "data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2052%2064%22%3E%3Crect%20width%3D%2252%22%20height%3D%2264%22%20rx%3D%228%22%20fill%3D%22%23e9edf7%22%2F%3E%3Cg%20transform%3D%22translate%289%2015%29%20scale%281.42%29%22%20fill%3D%22none%22%20stroke%3D%22%23172660%22%20stroke-width%3D%221.9%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%3Cpath%20d%3D%22M6%203h8l4%204v14H6zM14%203v5h4M9%2012h6m-6%204h6%22%2F%3E%3C%2Fg%3E%3C%2Fsvg%3E",
  "efemerides-imagen-c": "data:image/webp;base64,UklGRlYDAABXRUJQVlA4IEoDAADwEgCdASpiAH8APmEwlUekIyIhIlv5OIAMCWkA1jip/aayt5Au6pPRTP70bUCkCsgTw7z5+ql/U+MT6j9gbo+ehb+twp3uEnAQsKsFv8uhqc8OWw6k8jchRymAq5vy5rxvXcamipxOaVGIQ5QhhbcLeFV3a1ErsT7i1JW0ZCrn2U/XOU36imOq1uhLgyJyLdJgSp5knr0Q9VKodBCqIAgAAP76GFfbKBPW/oPivuPvC6+TZZT62OIOxACh/WL4UTOfFx/Px/nrPiSoFsIyMeouOcqoL2y2Fk5T03zNPPxsLBz9pH6QmkymTb3pAJcWng12R019ybBI+S+LyMv5YULe4M279K49P41O4FyC5QDIJOBhCesF+YIV0iOeBaBUebiftvat3q+Az30cRs2sUUW83OtGiTOmG18806DsLzrL5Ez/XKOwKMo4AAFP5/ZNaOhC6VAxhB+t3fASLHAIRneQ7dK59mwVxSmsSnfotgfS2XYvs51ovs8o2xn599klOzUb/pUmFAIIqXRbzTWu2IEAAHcFZ1KO4TOlO/WrzKJYPRjN66OZIwLLzI087rPFpTDLjaPetVbmJpMoJ5+R+3v3aH96oPW8Tbiu+b10VspwxJSJDMDiallbadGSUCJKHPqwMHKrkGlTm1QMIK/oPIybvu4zTlcNJHrfvSQm5xqUPipXrvO2fgGFInJyYFTOPjRDGNbOCjw2c8ItONxXOR4Y/fby+YK7jL9CDljBO/fUGC4HJWJCeLtGWkm1bauUIn20HHyv6fWCJaSfgMrIkwITryDP8tqTrZ1nNkpw/DQH8T/Ot33/0xNR68zRf9tfXlzBpTNjf23//tFIRk9/+tw+jfYvwO15ahassyDB6+QN5WKQXtY6L6ClhgQOYP1Q0vYtNhUX55UHaLi2t327PnuC2KWR2Ue1S14NJY9iFIvveCEpHrXig+U1y3oVvEJS7Aht/PWF7S3DmWsNhT505JiQVTon/K4X6dds1nG1FlHru5nbJGVNunjGdqFEL7mE12/LP4gtQJX5nOrNXc8iu95uxHjZ47sJiE9gXBuuwwFz/jvpi2tX9xcRQ5Ti3HXzcED9qAlxT6todpNLRyQQpqLipw7SKiAAAAAAAA==",
  "navidad-v1": "data:image/webp;base64,UklGRsAJAABXRUJQVlA4ILQJAADQLQCdASqYAL4APmEwlEckIyIhJBd50IAMCWVu4XNBApisjOAe3l5v88foX2zvmA/Yb9XfeE9F/oAfrv1nfoV+XP7NH7iftV7TOrH+Heyj/U+GPln9jyXCUvEjvd9VXk+/yG9Z6p/nf916gXsT9Q74LUp8H+al6G/6rwb/OfYF/LH/Y9mX+98b/1F7Av669Z391fZm/cchAMzMzMzMT23HatioeiRUI1OW+zHHvKSYmc+JebmqlZR4cnEeqQyV67s6+k4JJyBQY6fM5i/CSte3y+YeruKXi8ve6vXgkLZCa9NQW7rlbspwI+CepmT1vNHTzinWzYBKiHAjPVYaF+FlhIjQwz/sJPUUqsCEsQnQ6rA6UyFvigfdRaFaWAELN5gM9ldG/+Et/K1vyKyF7zYAv01k1qxu5fdOCfLnoMBgNMw3VxF+EgoKPDESydnqGKihZH6MfAcinKzDpq4GnyZChKzLNYWRqqqsQBmZmZmZmZmZmZmZbAAA/v9yxgwswoBdl0JTLiRY4q8/Jl11z1ar5bxM1aK0Qx0HRWTG3rxsPYQ3oe+IqKc0oLlCKgjtPqloEWYqsLte4cw+FceaZUfM/tBvBU8N9b1M273EaCB4zSpwaPRXe0iNDNKztfmuJIJzHTXmXSd326PkLiiIhgDjq2LRIJt0hmNbatHwV518I6C/hQeIE+gF9oaOt26zXn3AFtmRvJwnQLNqq73AWgDAER3o8zMQtV4uFj819rZOv/kMS19ddCwjBRIE/cWJFzqEEQFxSTkaOXUNMmQdzcsaEQBucGyIA21T5Z1tmwwGMyYVlGe5+PSDxtNz4TvcXGXpnOZb7rTNnL7A5lyluBLjwbe7HBP0xd7Q3krJYeKqcVzxaXfq2N+5/eaCJ+yOzFzzdunaAm+cDmhXbOvacSOA6026El4G4m8XxGb0JzJ7PIzd9Whk4B5SPa6xaMmyIQVOKxBEKVP/hDmoxzv3wlZgXYbFNevPrj1K4QvBX3LxM9Jq56LzvyxAVoZS2vAbnpBKeLP0HJFGlp8Qu+/RWr7GlwE32B/snDqG2rq+6QRCvF3MZ7CvxSOciYLju2C6jgWQ3gMNqYoKzVMjdvfSJ81ur5AZPjEshB6C+M6ChPq2TCZ6fK/3Lh4A66L6B+8eb4F+0GPsppq93BU3K34fv16lunq4NNrRK2geLv8UNlxsG/tkiiqk+vT0tDt3neb+UnE9Rzk+WWTeEhleQHwDXDSLL0JdaqfXltAhqICSaXBt7coVtLOm8odIhZjk3c85XAvZW4fnlz57Fkxv9/7J1+jm47amu43Pnipe9Xogbd/18rffteuiEqjhMGi6jfeGuSaHv6bbwMseNdJQf0BrcToGT0NcXzqhyv22xfovw7k1oEYUeEOXrYcSTobHR+Gv8ATuSTi33aLGwzJy6tAP2N/NUgVbV1jqZmGbK13Ij+eAeoE0y8jc6jugSsuElcZ+mH/mv2nuHtTM+jxtpE19hQRo9+/z4nf5anyjt+PtoTWZ8pLEiGbQbf08sENMLUvugcq7/+ufYuFH+WXpjMPVwqGuf2l6PD3FQaM3VNSFJ25P0UEwf4N8tW+iP4kGgLuzlPU1S/PyX6ngzdlBcaR1xphJnToq4oplAFyLtLb/juPtDjIDehKmEDXKjqlsnuXMvfoWo5EmtwbKeYaRTH2OQLMtlwB1o/su/8uyoCjxkXi6iK7vUpsd8LPwqEnDVfnPJ8A492AX0/yioRxmtPNhb62hwZdJcapG11xCYo4M1nnT8cMtHQNbICUVBG3igTKn4SixzYdRWKEtZv4ZlkXCMaZKzZ7bYtDdCxrCDj//uT9c7Jeox+pf+XH/4XAnRKPL8Li/w8rnEFP8FvfgjChxfvjEh3LLyMdvUq4dOjbz3BiJyA+TbS1SRhw+AbzfWjrCL4jJHTIU6wDNta+vcU9djmg//x1d9koCASX5d3/rjeO+ZJo8rIqr867yF+Rt+E9Da9VfPnojEueXg4lH/It0MMC6/THq8DdAQVL6G/+0eNmRqD42MHdYrH55MSedyWuL5sbpPubADrdrHpXEvWm26V9saL4gx9X+gEpI46cRDBjmU+1x+r/muQEO8TXZi4unZXOznZ1Q78ATbVAH4DcLkiWw8yhBvRZ/ljQ3jkHWS46j7413fbFvzk6PrT4MX0k1631bRkCV7wisY3P4vqquHItATRfT7DZ4DVWSrimdi8kmGMjxSx2Dh4+XUdf/3rZFDvlzwkIW+TrsHxzDwfp8R4Js0+Fi8pHudoqJsV6qj7br9esZe0qFPHoJjtu+vYc6D/uGsPFOD/3yK/fuoIotPBkN430DoaXSU3D844nnoVz+Qa009Vhfz9WFBDyvRXJ7r5jlzo+BXIDah/0zht7x5mwZ2pa259ASNg2UX0sJQ5PyGg8Autk1ejeEIMo3el+Bz0qNVuuTNoP+54b7qd/Gr2BkD4xppeHpSGWv6jDB148oWnmLukFI8s1xh4CvsHqTkqqnR1tQ9IZfiHqWHij2y5IXPZeM/Ty4U0T/nMkCFUb8FBgBML4fAsc46fP9F/DRggL6WYjGz69fIdG5uCGZvtBOBIk5ANsQ2d8fm8AecpUJGBqerbE+ma06xkhaVr/bJiu3AhTWuqefOgrOyyGOFjWnQ1TgnQpF30YJtvdlT+3PdREJc5sUTZg7roxEQ/XRpFzen7gRQgbPp6ShfjKH5AxjP78+899c+/JSZcsxikuUQ9Vt2BW/7El+qDCGtIeOhpbB7aefHjAuyaQwispQ51U0Vn/NiWaTHuWakxgzmrJObndy+zfBYEP2tMJ4gNkIGIDQ+MPAX6H8qkSW2cwdQEaekriTesIOlIcM9ge50AcSGGQx27eh4Bbsc6HtcfigbTIpDLcE+F0mBDNDeJeWVBXe0wxPykFral5Nk+nKhNAMKrf8xkHNfRt76MePEakh+vp+KAOoUUvpn4gEpZHMCMb0jk2gWIBYx0op9OFAMghzB5572bxyOFpdJ+0w/s3bEoBB6JfaSxBefkJ1/o3JfyuSocsemO97+QCmqNwIunpQ0qq7drzRGiL7Zl6PvFXDaxPLnDslL4uorUtNkqWa39oMnvCrZfKkL2CJMHD8Ica01AACI1p1ANyG4mwOtEy6oTW8AO1XddKgrFxj1m2UYOLz/Nq+miCC57+9N9uzVo6YLomIHBt++3c2uYlc8CW1e3Fi/JVYBUCoYMHAHme/F6VjGNiiNtMfgo2ypRfCKzrWbdkgTAy0GeSsivCrWhjJLmoDhGDZbWgD2joBAx/vpflWJpnK3hJamB6xBj12Llhg3AAAAAA=",
  "navidad-v2": "data:image/webp;base64,UklGRioLAABXRUJQVlA4IB4LAABQMgCdASqYAL4APmEsk0ckIiGhJrXJgIAMCWNu/HyYw+cfLgga4/m+CuLvYZ9SX+F3XHmG/YD9tPdp9Fnkgda96EXl0+zh/lPOx1XroB21/6Lwj8QHuv9i8zTIHaR9WUYLJN4e/3vqBex/NI+C/2PbSWU/1XqEesv1f/k+EXqX94Ofz/X+Fd9s/2PsCfmz0PPp/z9fUX/t9wb9fusd6RH7VE5+1ebV5oHaCgPueS5wJjlUF87tvo2F0J+GXIknCMucxiSezQYAa2Y0lLmorvzWM5IdxCa8Jx9CvthqX896hIs36dvyBjDC31UaX08Nm7XmaQKVR0FjbrdZY1D0I2YXZYkdXwe0AkWbtdvnKcSCvMOHvUM3v8zjhkBDspif5/AHANO6rh1WBV6dKvsGI3AR/0Zyjx3a37RErVabv1i5/zc6Y1/ZVnlAM4YQUeRX1ltkb+FZk/aJwAWlccFhR2o4WceDo0snmgHI6FyEujSq/bc1mHQVnVrW8uq+SP0oqNN2XZs2/UgQ24SGnRHkRiq4VkG1ebV5oJF+oAAA/v8sEqeEAa6YmzusBH8g/mqOTB0ln1JBnQHw71dSUeSmawJLC4iyGvcemtXdXZQES1ZwvXr3G5dUCS1+39k88CLTsZN4a9Gug1jJ2uCIWJaS5/MiVF6p47kmqeJFbeP9Zllo0zNeQSDqQ/5e86qWM9C3ZVXqx9dDJ/DqmgReiS0JwFBlL7RolaBqIwoiIS204Sjb+AmC4wmMqvGqwtFzet0jHTvDOtMBWuMu79El2ETYLyiI71YOoROBJjnoNkNgYcYwjsEdT4b/qyL1Gg1DnksqlI1MgnFAAR6ltkBHUfhZEMr/ngmMX8Z8N6DlAEWFUVIC8aynfKe9oHZ4+3CTfsMQHe/CbVC9HSiiQ/Z//8Cb/qih8J/Vm2fum2pcHZdD3SwT+mUrZ7PEPIc7/A56mfH1jY9WcbxGSoVmeIC74j4OCbhigR8rZPNiaseuhKIczcHtFCQRiG/uK05uB6mwhi7kX0ntc24dt3Gs2UVy6PGtbGg5oVoaw0q6arU62K5eWLb2M730t9CekzxOVuzQ8GUAoOWziM6vm5JiqKocvy+oKcL1mEZdqRc0jU9+DIdYZV2hwO/7Rxq0w80mZ33z5BLLcK22CUgcZWG67yQM+iPn+fiwrlaVNf5xn6u/mVLCyHW0nXERf3XpmsLxjTIwWjav/8BK5eZwuyvKuRqUO7jnfN4X6iLUdmC/MBzdXrAz338IIQ1pzqS+0LvpuD0NyPamsr35ItYq+sSS1tEaayuqwepaU+vmc+Ht61bdfU0yxVrG/07m6vH5xYVf82zpvf2lLHMUZOJdMwHxL7rOnnagqAoER3PDzPhn4byaGyA2+nzM3zSn3t4phMOwd+7SkdIK7CK5TCN6WjsXfTnhSuvzbd0YY1eeBRADr/1H2FOlsPe2qsPthFQCXZxycfxPlpXcKesOWgAhIFdT1mRXkoFUMO/Y5ZFifvAzmnX/RcsR1G2U6fEimqgVfWiiYsXQVOPsSYE0LgKSoswAAuy5uv9eiu+x7ez0ficAmoqpiV4gfmUqOm4ZxlSchdDCHnTeqS196RNu6gfZFFHh81gtLTU/sp5gLaypqDPYUt1lesI8TVR7SgNv/sNtRC50y6n+echrDpWsz3ErvU3H7O8GHzYBSvHIVdnxhDVzSqR9BovxwE/Yv6MNn+K1VEwHTMwgf+fBd+WqQ2908s/Ww2vIxGb4qHtaYute1PVdxR0BVxXtKKF2KkeZlM2TYN/hwbgm7VhiGTnFSsbvDul8eEEaWlbyGxcB1Lc2AS3jMoDJpmsH60BhudsAbNSCpUIrDAKSe3uWDHkr5yfRTfsx/PDRzBbPwMj2aus7YpqKHqI+RHEu6oCQOv2q3/RYarwFHqcw4B4Cv3L/D1jCr1a0ijnfcJh2rIVSKJChMhb2/EzvA1cWYZgCIR4zaPvSAv/edExpRoM+IitCnPVh44AhzUpXZVlSfGD+lSiDCgRHZZwLy5LfkFaf0W215R9Wo0+ZA3fCB/z1osQGIQGmRrMUqNnp6qrRUyM8B7uZxQQ/4ZJozqCVBr1RlwPttP5wxyBcJfufG8x/vRlzxijDYl6xTe8aB1z+YUUpPE9iiNPDpjZJtgGL543bA+rCLKllkYwkoJcEGu/IKmNaQWeGZ+L9rvUHtugZDfDwzVihl0iWYdQ203vDqsIbK3FZM1Q71pO3bz0eZYvvgWW8V/6Jt640Pdz4Up9d1bEEPHJCZfv8nhCr2rkZVxkvZZVHR8Z6+d6mVz5IdR4kGjkwYhinNr/vGlXnbvgPCkoWIfc8d5G58ARQzV1IrAJzmmFBtfoBLniBhAqpZehX4axGXyHXIjkIB62mf3n+rgx5egIJCVxlWtxWvEKDXfrhLk76jmBBsL13Dtr7uhNMXYlGEiqrmOlKSSRC1wenAgfSPnoRYtNLIbb1oTOlnVr/T2alu0sHLWJl65YPelhREZqXBHHbhiy7lJo3wRd/ypX7jgKkRzFW+nc0VB1XcOXe8lMWKFV4l5PY+7CvS/0skvtunZhZQ+QDICfewygaorrBE1ejU99RuvFh28dUamaTxckXjdmil+T7mMfj+nLckqPc/4Bsoru7aHlvCP3JjFfLh/plsUiEB6BMH8N4FN9K59vhRHw084qCpjIaCyUjTnwo9tmq4QWx+xiVMTKDZRJ8T9VKVbmI3JMINp0pjXtgtGbSIK7qH8/JnPRzz7UquqnE7j+heq2dSVE9vIxsLBlSRylssM3JNyaoNNJGaOPbSkitJ7rxrAj7/8MiwQbEgMI+2rbyvwRjccO6R1T/HaNeDhyWJuCNpfuXiJeCwU6QwTwm1CNFQWzmK1E5amUfBMO84wIOgEFtiwXRWl5sJc15IQX06m2Z7w2pn/cCVsIu4SR5zEesUr2RCa0kUCRRXi4sdUZIuAbjqHwdjbjK2lpzjZLIQkd/61GhEHOtnQzxohKologBKepHanAkZJyZ+bLQ0jyNmMcSXmvi2762dL0Fw37jsJ+ZySyVCtQkrCsWlobJr3GbuLSWY2r26LjeXvwpVzX52jLAYeJCHwaOj+LHaP9oyE28Ea6GuqVFYpZbLGzhazY9IJ203T3dUF19FVwgCSr5Hv/DSwobg9FUKMO5dAkfuPQKHyzj65Bc8BU+Leb0NLDIdngoUw2U05k8g3T481rnn2TStdx932ECQE+tow1zd4gWNbSNnz7f18GPrvfPdGDdo/GVnCxeKy7fig9nEU/rNxP+GWvJ0vi2xuZ9ROwvUqtrhK+JVqavItt6ECI4YrvQWdyXq0JaLdF4Liu7BOfz9LpGX8lnLERY2OtNjM8syOvcX42dGW2kFQlJwIGVglFNgD8NixDkXeOmxb8Qk93a+axRQNLWf3H9UC4xzVuwLTOG9d9L9u1DROqjLESesyWXvQXJxgho3J7nvdc96okZRckipFhV60FjmK1jirivaHUJGW2Y+Ep2nOwU6gPMENdkoI6FWpPOT4HBE/u51icsOhHTohBvBJ0u4sG4F+Y0recN+jGzxcJdo6LmqAD/1nG7fTR/XZ7NjiQXUkGmim7WuI0Li8Rm4CHh5z7rNQnhnFiU2UhtiGW5a2je++Kxt2ARhjVotmM2eKnepwiPC9w9tSDIP6M/lJsOjGSFxYoReAsv2xI8MpIvnKhEc9srupeufojBrrAzUGtdPu4o/4K31rMl+SzT+gkGpCDgBiWPAK5CH7Kp0LTM6NdZEwIg6CVG7WKH/2hvr9x6Jh8Hkn6sPCi0SANMIAAAAA==",
  "navidad-v3": "data:image/webp;base64,UklGRgYMAABXRUJQVlA4IPoLAAAQNACdASqYAL4APmEskkckIiGhJbkqQIAMCWVu7mD5A9wPOcW+Jp/0/HkeKdK82+SD1N/mTee/0L/KepH9fP2I9330M+gf/S+oq9ADpdv3E9I/VZWLf6Twr8kPtDOgyV9dGpT23/v/ML/geBfxM/l/UC9ef57xE/6/t29X/zf/F9Qj2z+l98vqTeCv9f6I/pr/nPCn8u9gb9F/8j2Zf7vx0fUfsFdKr0hCmLlarY7VVSkunJEhbCBKtr7xXU7LfVab+T0URLhActLwVWR7ixV6gCDwVaBDUYd57SK+cPK2r1ASniUdL/tFdzasWgEphQDnBHYJjEFJY+A//RuhFNUrd1TmL2nsAj0H/QhIKx7L8RVVyis3qkN/mTSIVHtMTnn4g368egBp+sX6NcH2BmzfpGYgT299DA+LeppkyYVQsmEumuaECHYC1UolyyoeYFYTVhuHa8U/1kOUFxQHkOUPDydV7iG01HaZDpxBDY0HZwyvXx3xehKifdICgq85h+NGpQ8OuUrmFcXROATXtkNK4h3U2W+0BLTQWhpvm2qgK/hVqUjTVqtioAD+/AaSHuAAEeb5m1pp4jX2OqV8rYHa2Hcb8pHyZvDhbxLiTVztVJUSkOr0WRtHwwdLoy+veKQk3+aWt3m0CXpGoztSKndEdmAsfxGJTZc+bHN5mtz8xr3tFCxs4+v0OM3ZIh8DcxSu0kiOGDK14xQTgx8w70RhIJE48L9DOXaXDlpk9w3bRGt2jukKuaJ4sZAefcU2MxrA8fOSD1ixMuhE6CTAd/B9quPTAVVOOL5HKYRApReqHj5B1WqFDgTrMI//rVDfHbxhkyzXLwmU5cP6qKMcFxIOitHs5gAI27h5yXutTHTgF1ZLqKRyBfwx4TDb2P1bYEOBx5GMwIacAXiq8w1pcI0ctD3qYGowdlFDn4yHxwjAso5VnLcV+N+BOLXJ2ZTRud7tnxfKjkHr/kr9T4EGsttRrMjAAhhCD466aSQfeww+LN+jK6ElfowfQ3U627fYlCm6vigEip1bdpV6uhxFdXpebhIroHo3gh71+6BdMZ53ZHgh62ra+u2ZPoLDUr/HVYyGyERD/OYSvr//g1X8bHB8cj88ZvILUFENn2lxJ5r8CPilYQDCHR5E3tESc9O/dJTcgpsZCiFEqpUfKWBaixQFDhia8YV3UgE+4F75MlMucDvLZ9SLTkn67q6K8ikB+3jaHKBBZTZiG1XLyObDmUUsB1nHJBQRz+c/LT15E4I6FxlLc0t24c4CCZzlVcSuv9nFN45zDAV20UgXFbpQQ0B17434GuDUmqcJo5vWadIPLLAWbfVvE+Snrnhv69Lcmw7wXGyHo1+tFdIzlX+yUV5aNhvRMKhGQG6ZCRyebDsmAY0z318Mr1CeVDpRuzY/o9/Aif4Q8UidL9Wty4zy5K/XGyy9Vok8j2y26bwvjjMruwpxWnUqtGQUt73lfAjhBMghegDS6cAFFVqDjKY2WY3xiMi2eO8wAKnLaIVbMQG1VkLrMn8FZLJYBmd/QDMZrJMcdqcHSXvoce2KTYLDcdtQEqR2a5orONjnA82W064qXu/Erv1nmkMBicvWzLm/mS4K0xNyFdKF1Ls+86VXubHrxuUxLyosojQqXemktrhT2/U520F4N8d22jdAwg3jqe+3QAWARbWjFS4uUfOO6XcAfsaEumX6OgcZk+jFe+qdQmxNZD92e9qe5g1G2Uod9KBGdgoWc1wtO3JvyM1vCZFq15rjP9OmB9hWv7AcGuBuoSLR4bS+ebMKwthM+jT7mHRMOm+i0KBEoqzKZOduF9nxB360ik3ZXHrPAR1LqFrnh+j995BafhnHnv71JI27Mk57qJpTaMA46VPQCwQEFg0YqXsuRGWG8/uD90N1DMqCq5iMrcI174v/vVHPEF5YpXqezSjQvWD85P1SPwMuHZDQ13Jp4gKMiZxTwm0bbI5i+Ki7W90tWbm6Pz6gWWWPUnobjNhrX0LRd3kexvjFosuDvgLSdwTFRtGhPeXkCtYsfyuPrsxJtLDmRw2/NkhRt13GH5yppZ8SnOBnEjD0245bk98xsEr643c83Mm0clkPAuG1MMj0uXEjkAZp01RbUd4zevh+yJY2dJXsab9DW4YPw9JNmXFmr1SgfGiFkOlXVBjthV2ULPUQ5TMBjfAAizOwy/ZkinNDyJdWsDe08uIbxJeqwpH9EEFolffZHLsUzHEtaSeA0okz74yS4ZUSbTty9DKsuYvxGq65V3zLSiFL+pl5qIH1BMWpIj1NfIDG3QiN8Eo5OnmoSceMhYgHxDox7jSEjDFDpAs3UNXQhkaOwlPrcHr/J9NnzEckdfusBHE9ff9A9s41Kq3POY1RT9sP6C6Adt+tdiurGcZGHAHqSvZvTA2WXQnVuJbJlukhZXfPJgDbmeXij3UY77uIexdfUnU7YW9P10TlGI0mgsox5XJUVLJrJffVxe8HL5HeqbfuANW6O2V3cxcCCcU+WFh2Qn5RLPvLeuMVIPiNm+OMhl/Eoi32uO3Z9lUmnvpkKJbslYHvvx/C5+zNP7AVki3sq16EbiCTwa5UTA0XpOJqx9XmG3ifwOH6DyWLKZK1sMrEFWlNFy7alGIGVmJFgD9NccOd3TmwXIWjRKm5KATfZ4RsbJ+2DTH/W5ktpgvNQ1aIVyg/CBLxS3zu4szKIMtAWz8qJMv3oyI0xf3eGOV2lQyytjf3f0Sd2TwZ7YDB4N9m4VDuGQqDaPtkEgpqXY4rlNEH4tKT7B/THvxxk/V0q1XcXLKK5SuSMupJhJ7fMm5eTND8WA82qk7JcmgNKzYPBsBYm3ljPj9iD/n8+1WgsIjyAjpXKTb3tHUwhHArqbe5rakGrY6KzZPUSH0M5wBwf+kyT+nKRBoUCJBWjhU8w08E8T58mdVtI6wsegMGoNuBClYAoOV6eOUoNORzDzVKGNb1uWItNH93uD7M2Nxj+r/u6yNBfBNJy8/3wQX0YGa9LuHCC7p/ZoK/JAn6Sh7pzF+kOxKaYBRAq1ByvMbqRBs739940OgMp7NHXWvGhQJykGP72Vfk5Rw0T7Z/50BRzH4fVCUBABF/Uu/G8uj6GHFTUjgzAs8ot42qVjDNQZKLKy2P3e7Shts0oytlSbzVM5FW27tfFHiSmY+TXxLN/bSM4fCcZnaBCAYOKZNgxJiVIPQIs+QBCAX/Odk8gDqwNCRLhWoEIu8tPn4Rj2VDvNhh23ibrbtQZ30jqJokhSihMgPeA3i6zFlHkFudCI7fAsxSv9f1x9cYyRcd8n7fhFrjbjtMf7+imk5mAhEvmAbsTzdMsmGAd+tnTT1x1dphjDEDgzQIXqF3QqnToYvjcOkLyzMoYXfltPN++qkMmWUbMfcrn0oHmpA4mnUloGflSNW2+JEMq34UZZVJ5qBjaPTax66qJQK2fBc9k46CpduwQOMyqQBiIqLznEltT0jF5a/4HBtSRnqhMqyePwVOAFcc2JBZ/qIy/Doi+wn1jb86CAnGt3sG8vIu3e9UVynlofZGHaeDxY1v6IMuFKLBNGGC7nfJ6If5t6LMkCE+ZGph5oDZRCpNHvTl/rewccCsB6h83qgH//KRhHBCC2/pF0ikpQucynvNkYOdeVaOh/I7R3PeeM9rv+0o7E6F6s37Hx1TSSetLF+VemOmJC1eQEHRS/DDlEPZ7bftngdlXD91YLe6oM5EeajVhgGCDUKrmcifTcuzP4DxWhSABZDlpqC6Txd0lKnAD9KCXZ3Yvdh22wzOxXySeNotCEelm0IvIt8KJmFBFxG4o8yEGiZLpIHnoszyNxmjsyePrZaDjBan8lHLi7MTASYFGELMUX2ym7Ey/WJSHUnVbYRILBJ9a/8OeL9P7FTJZumjn+qlELzW3hACNuG+CdNMUeIaB5x6l+glOQLbL6CEb5YGU5svuJgf45xLpduvyzw8tXdQEgLdjK3EtKqkp7TYNub8cfCfrPFys32FLlCSgknZUo6KOO2CEFiIFI/z9bhTDJ7OBi2cO179gBegYRDgQXCZrKBiFyGdwX7eUCN16e5L0awVd1ocdIDfctDt8sEdlbCCIGkjsnCAHAAAAAA=",
  "navidad-v4": "data:image/webp;base64,UklGRvIIAABXRUJQVlA4IOYIAACwKQCdASqYAL4APmEuk0ekIiGhJJPJkIAMCWdu4XNA9+07uAbPbv+YDzotNL3n7IZNvuLj3LIuuG+nuOVkO7/v7X1Avxj+Q/5jxC9kHmfmBetf0f9d/Gy1Du+nQf/yPBF+x/8P2CP0L/vvZb/rP/h5UPqH2B/1360XpB/tyQRG/i0idJhdulOdnnWgCUZj3n9qLVXDRanoXM1tjq9QB6F9Pdr9UE3tZiVtfPUc+psGo6JWPZkmV9RVVCH2T6tn9N9gIiRGMCSfgusy30e2nfXIXGOX0RH559XD5JGbcN7q5BA2rLlZFzBYDthOFALr32eymnVTcv1bXaum9Q3xlDXE41kX2fVsw1nplnYODY2fByg96eidR4rclKjetkZq7rquvEhvTuwenaLHqKLFivkZzZPrx/IMgxI48irrPvuDaCfex+DbwDPn1XHRxN7KaNFpOdURzYAA/v9DE1tPf2R2S3nI5eYbTdNNngK2j4Kadq+HtsOqWMMV1bDHKdQef1kfHKWVRuONCiecmRnocOaI4kOTZYT+fqD3O7i6EPaMYllakYImIXhh+I/KQQurjQ4lX6IzqN/gKSSsf8GaYGapNRgDGIyJvRsQMd17t4Gisnd67vw65aRlcPgKw064d2OUKh+a7TRk3us+Py8NGYp4SDIML5oJrK22ZrCULf4fJ4DQD+uZnOWuJ6HK84Bq8vdx2ifyyJRNXxlJkHb6rQtUqgi6v8+BJclz70HsM9RletAJABL7iLqQXkMizYwJjy8MBy/dpHRBNBBwEk22iw2zzA5ktTDB5gj6tTvcr9t/Ry68PAVmsexz0BdQSnHG+dwtSQq6Om7rL0jvr8k6fvDUzBti7+zrSfl6khGvoJBHdqZt10OKbiDi6ztmdrfeSFFDpsBOeTwCUfVd6BYVXHinW+y+3uehgy8N1yUfgJXo03k7NeJ2kf9M07eGgGGxTgAFBxut5PVevt1AcfDM6TyvLPUuxqdFqvBM6esXA846M4KIKgM2FZOXl9aKYFW/ZnBlgEu2PCG08owCJ+Smi7655Y5R8wbGdDQA/+T8oI8BiEzAkSxoJazzbICf3bz1qCgf8swQVPEBqIL2brJQtx1XV+k7c48E4mMC4dLRy//G2xkbIwQ9vfRA3coIZztpo7rBE2O2Oj7JfMaMh/P+xC6RjhMWg0n6ZahMJT93LXIzM+Qodwqdqv5lCsJ24oyxDRUIkYtO9dW6qjefvjixCT8hHrKziF0VLBdPvWv6zcpIR5DS7UBoYu9o9xkylDELvYHPNe4cbd/xtgqKhkZx/Pek3pPIhg+VheyHlH0ONKmU+O5AW8h704SCqct1ct2Rb/eNsvxUWX/M4pj/SrWaj66TqloRrdVkzZxZzONicYb53PeYMpPqijzAqm9JR06CZM90/GDIqrDXFCU7DQhntJkzZ0e3EtAuBFf4TIwYfVt0SzU1+7GZI4FUAb//c9kjjdzsiU053e1ihUCEn7omNr28i9b9yVNgkGJQxrcZgZl3t9ZmmCyLK33LrjSKXg6kldx3NcD2Pcd2/7mXU/mMxZKEZrFDXeVnVtngjlLCFwBTcdN7ihnptBTeIZ1m6Sl28eV78ERY4emXxNd83U0ZlceNNWrfoao+KjK+TuX7bH2d2q5E/sdncKnhzmY42BNwsgYsZ2nHRToDsX++S0zGT4qyObOFE3fADW73uFRuO5O4mR3UFV9Jiq8u3rIekG5GuFV2Gk16zRG4RL7CJGs1piG6pM0xXkAkAcXJqvUdgv1zvE7dr8TmXsXbCyOufoYKdlvfBlkffOWGMPgVpMQUxWWnGGqeJ5X24dtxid/Fj2fWB9mJ1LNjnhGqjWfytcoflbRudk/KtUqRw/r7cKX970XJNEm6hBTJ6F8h9vDs4vvas6hiv+xFTATiEPC1gMWude0Y39c04oHyIJogeOXcru1eb8N4HoMDOff6XL924F/3qEQDHuSTRdOBP4y+n3cNfU84lkJ32QmO65xoRjPiPn6uI1BWyHsb9sWQqDsg5KgJjrMxYZNxItfO62B9gacmqAyF0U65asNXE4rClE6TaBCt7Kq+DZws0bb4uE8cmp0wugRtpxzU5VdY6fME22mSRT/fou3ukwJ6m9RP4Hs7o38GI4zUYNvocg4DdVeCpY84o/Y9kXrFNnfvO8SdnLXBzGRA4PG1lH5TdS2RJ+v8L8wOunv/Zr4y+GTuLrTJsufMwud8hMJszUhhqiBiHRyPIiLm6uuPH0/exVwM66P9Ji7c3R2fa/c3Y5hOjmNvTIXX4ppFPAvgyfo2jYkvmtSsPh2W3F0L0xGMWTPnwkFAaQ2wMNAsWB0tCO/m1xy9j6lDgf60k91D/pHB9LMwlHhPGZQ4z0mGsIOJBYz6LABrAS56TtFa7yPWyXIvCk+/9VlPxhY/SuoPn09He7W8Pw+dQejwS9ULTvuFZ+X6bj9ue4lyfdNLyJyR/UNfJVXh4ZW/ntPbRKzHfrofIbyE49j+rU2eczMTJ/AozLEa1pEdHD9SJEpnIxsxIXvQDedn4QeFhGlPc5UnSn6A14QDKiXH+mZejk2tT6V7PKsZY4EyFDgI1OCyDr8Km0z4fAxHh4HBYjmx4MgyeMKTv8j2DMNQwk4NQztmlR+L/cEdHUv8cvfCNkpPoXvaBnURKwhkv1cbAupuBoPCzZrcK/GrFM6LkfBixZHVYmx5NjEfPvyiv9exjBJTHa/IT/5uX44pZJVRFA0z3q/l3sjKMQM72Mm8ejr3/c08m1wwaVWzzZgtXpxzY/9o2XwXW9waJ5eTUbZclA95zdAvs6+9q12dViAsZK0NkJaf2WJAVUB9NakBD+5+4qWaqc78LaLwWWyJ73iDUhNSNKZk4+iXN7FYDD5uh+7tFbxElt+nA5Mm70JglN1hv8/3atg0bVWP78n0XrMmgLh2KjDffouX4/Bha42CepkgoCi/zAqNEti4ttSriWthrd8zwZOVB/S3pmmyz1k82sTmnK6dSJmjQk5LrXAMkVEfSeLOYszDzpFLV2kI3t/4CngAAAAA",
  "esquela-canciller": "data:image/webp;base64,UklGRgYEAABXRUJQVlA4IPoDAAAwGQCdASqCAKIAPmEwlEckIyIhJpWYmIAMCWlu4C4wMpWjHP4Mxo35J0CanEP3G/oJ/afA3+o+g5/cPVS/ovGV9O+wL5VXrr9DH9hxNFe8DOG/iGQClsOse8V3UzMh22K0GC8IdGwHmE70F/PbQBK5sQhv1Xfjxp75q2mT0XADncMQqxaDgAgYulU1HVqZjMlwZ/a71dHXCuff/Ulx6VRKvKpFhIB2fEEdWMExa1XcTv+msmn9bWc3TEZvrU6XeoQ4rtiOml8lqrJNyiB4qQf/nAAA/vr4wZSbEzAPOUAN1KCnVXZg/5bVcSue2+Fv4/h3RIveGcDhOAD9MMAUtu0NLsluy8gVZVXvDlyujPmMoYxdEX+8VFBT+XDugWe1AR+ABZG3VQ4Z2KSYmwKXaWa62poMRJSBKLtz8/JcP4ukHK2gKeaAE5adcS0JJJo4Ac4zA+pOam1ccZ9kLKPSW8nrlx9HIx8mqV2Etm50cVu/8BbyCxJqU0l5E+4m68Dbpe+YuYzCcVUhe1f0rheRUl/8nD6w74IxSMpn1fyb3Z4/M2fEsvgYtz67/ri5do4AxuTPCZ+z+kNEZQ5ErED2rNofX9rFAn7FtXjn66sZA3L/UNdQAZEor+k4aZmeab3vQKpDdM7a8R6IOXe9giv7RYnjMFUK7VqBioAm2Ypc5mpLpQaI4pW1VmLyd8lGPk2GId204+vKlmgMciQXT/NffDJrx+F7i5iTG6yP3Bu3tynWS5Q910bfYe9afp9bX/w4PF0y5hSlnc3KIfMKntPEHBxDfbzOw3E4ubvRXm34WU/ZeTU9P2NkKe+woNTRj/ALkuOt7oSwBaSNDcfWV9yL98EYHDfO7RP/wXE6ED0OWx/0ytYsVG90aqfZt5kzBgX8X2JYkc/LGSTRnr9rlFM/0IhVGYkIrxW38tiQ0eY4umb7N+5Wycur2tfI4KRYJcrb1NRzZ05qo+n8Vz0vRtbWxueAYXyjMssXNTK9jDQnc7qvp99heIzjqMxrxIfnnGK9ihZ5T1rT5e1gfOIPnnmYEgMSivqonAAiSLCKybFberySjpCGPHTTYdA7bXWG9mIpY7O73NZMJRlAsilHGSl4ATpP+B/+0n88UMGDsynw6xnWeG2RjlzczcLU7TiJbmb/B2lP+I8mz3DuVp291C+93kgNfd/8L9+x2Tht6u5rHfOP6dii+8ncUB8Cr6vKjqKVaDlMEU/GDWZSLwVHs2EsOva2vcDHCVYLxkQ9ND33imJdFNTgzokVuWLA2POD9/YHL2tWp3O+n9wphbsNHIrMNNvrWpyk0UVM3anyMZhxOMWDbMUaM4OKcQpq5+MzQvq1HX5ngA+yxeAAAAAA",
  "esquela-vicecanciller": "data:image/webp;base64,UklGRjIEAABXRUJQVlA4ICYEAADwHACdASqCAKIAPmEqkkYkIqGhKxRK0IAMCWlu3QppNpd+Mr0/DzvP99OSHdYsq8Q3BFeFB9X/2HqLf2v/mf1r3Vv63xcfUXsC+WT64/219jP9wB5bF5cZPRgMr7qI2QKJvBpRDIQU31WkoFkPIwvxV1Wy0y83cNDb/Gc2TML1u/Pvt21vQWr1wotCA7w7Nd9TJoHWXEBhi+wAzGFHqHdsWPrdrZ1iRkWO5PHh3Isvm3xe2Nc/ygSrQ6M8byAYIanaWDBH4HcJYWdICUMnRdY8hgXQPmYyAK6G4yfTQRl8R7N9KyVXvEwNJk/n359+fTAA/vvn2DG+yTK05hj3+DMjuebZEDKpk8Js+t1NO4/D/f5E959x/vHJY4BIONqwptgAWJqkM2gLmagRBq5++aq4zz4OCtDaoOGZuAiMBzgpE1LLXuQkYr9KEP1caL+DwHDegFffORGZ3P+eUEaj/FC8TbQ87h38vPaZUWwnK6BaqUPP5K6R9T77GwS4VuPKWnO80BX/VOQ9fPf5BlJe6enNdeL+YY4ZaDtwnTVPj6e0dXAJ7kmRdYOlfkmFNL4ag5y3UrB2SUgQlIvif1bZA8zRgvvwCemL6zBu1Anfc+ZJGYxnX5Itkl+usk3f/bIhNjm+5tLKCGvdvx3kYTF9Kr6vc7L3vR7QOKH1YKll4IVgUGdqyluvyxD2PUTYPBMj18BSAu3LZCSpIOxUMCZuqrAn/bWhUIyMbYj9EExejtQF3fYqxNlTyNKf68KsLQMPOh0X8f4VajB1cy07hlkib96dQfCoG1Xrezkf+/cwojY6fUAc/IHYxtGevRiw1MhVASqXpMLTs9sq59vs50e6OVxiKdh7zavN/7dUTQ/CoxeD9OZhgDPQjhmfXuEjYnP9jT7+RReSNJaVsEYvVBefLSZZz4ZYOYk1KPZ5O7UEh7Qt0eN5Eylm0RyNtVuWQcNCcYiOJEO+lwsKFC+bP8EJ38nhooJH7V0ney7WJxD+1Hc3I25BSXPcc20myzu5DyzZvzUXAB9aML1I6CZUlpCvRhat5bXQD3TtX8yvozHMxLcvGRAEH8jXdv3aqLw8MkdEtSl/fJtMeHWY6D8QwNIW/QSNOxjx9m3Zlhf3c9xq43dC9ecpUxg8vJT0sBn+WLiuJB6tpEu3z6j3d6jka+FC2+RWFxeY4hHM1TZMcVzgrikww+BveGU/15/5lzhI24ZNoLDdGCl8mDDrTagRq0SimWCjqgdkI34PAQrgGxxsmmHVFTJImr4SgnDcWDPTfYYVwGiS4tu8rS+8IQa8kr1oU5Cb40fhcpe6fHXXQlqrSRyx0CqgunS/JOmEaUsQB2Rvl20ANQdQCcH4sNF6mahj+gGh2zeJ+8Oeew112hhk/CpKjULW7WcPVRCmgA8sWyh8u9BFJgAAAAA=",
  "esquela-viceministro": "data:image/webp;base64,UklGRuQDAABXRUJQVlA4INgDAACwFgCdASqCAKIAPmEwlUekIyIhJjXoaIAMCWkAFs9tNq7RwKTPXAV5N6D/4fwmY3f1N91L+q8Y/1D7A3ldeuv9ufYp/cAbc+3XjahMZsnxnhGHIuUUY1Wm19REf1N/5T4c/+7gobiFlUaYCPZexHnSPr/8bDW12w+o0NS/ZQChseMIN8CPSz3dShnaLo2go1fSibfowXqkluZq74jJvSbbaNl7xSZKtejpZi0id1Tz8fHUgGfU2l5FcqZpJUzAAP7755PmCA7Xkr+VUq9hl17J/DDPs3x5jS/jBePwE+8hWFKUnR1XNIfCN/igDOPAyh/wpaFV/r+5+v7HTfYssHy4tk8F5p/MqbW9e+115TI/++o6R330bRNR/uVLPXaFAzqJb7WfYMI2y8uer+t8MNUGTPxisgP+Jw5vRuXUqxTkMC/+8QoH8sk0Yg1ycXnhrK3PSlEpSra+So6nxO1Uy6/EMJQnySwAB9Jfo/G/xfD4Pkr5stRy5XPttv/sNPwKyvDzENfW9JDCYnHoHNdm9C1L1780lpaqOtl9EboIj1j+4iKyCLtQNwucX6Yf7pWt1kMkNBbU8h9AY7vjMjGZEfnLSDG3ObEFX0hEGDFw75CRC2b3BA7csLuWMxIxgHOgC7ODvJIbX5MZUY3uWBdrxcmfJ0+qiLw6Ae3B2mWfBJIjwA2+Qhtsdi0NAxICQV7zClXri8qNVwXDfhoOUUhUh6SIrGGisRz981DQ5EHa1ZX7u+j3zYBK2QHZ/1DqUYMTEXN3MngY27CGZcwudIRvFcLWbv0kYBJW7uaB0RnbnkhHyoKDS9x3BmPVZ54einGpW6oONqQftqtbkMyjAx9VqQb9OflQBT11C0f8c1yxDi0OfIWCn3BS3dve/9Gmm4hjjFN3v8bwMEQdGKrM30OSurVP9/+6UhvWkTPomQEd4TLvuT9DIs83HC8zv2ssQC6EOgQ6KxkPj16Cv3RZh78gCfSkJX9kbBzh9tipnbyy3Q/fYOBpnDl3GP2OfOQP/6GDIQinDES3H46x4ERe9AtLeelBZoWNROJ2q4zuWOYLxOH6KH6txZTU+cj4/4fV43blWInHITmnkuo26QvykcqWc8hUjTuiHC6WNqgUM19I0Z4+hIj11IlKihEnb904x4fBq4bd42CVZWDP4CRcx32DdVIya74eBNafHj8FHBRIq1PC8UsGojO7rk2pbztSiXURROdytRSgLZoNKxPLI/Z6/uI4BS1qIDlmrp9ZNxbh+3SrpeSKqmswhG5mz/Q8FzmDewqhMAtyAnJmQs1XztsQ55S2BXzukB8AAAA=",
  "esquela-otro": "data:image/webp;base64,UklGRqIDAABXRUJQVlA4IJYDAAAwFgCdASqCAKIAPmEwlUekIyIhJjXoaIAMCWluugpn709anLA7hf0R/uHgDRo/qr7p/9j4wfqD2A/K19gH7gexb+0g3AKH6CmSfIce4DcuqPxGruHIm1icmiYU37DAb4rpOEd6QpXCgd3FoIYlPy+uiES31KGh3sINgFu48bvc/VK/TbEIzym1qZjMlwZ/av1dHWYllb0vpvmAuASsRKgNHHE65jDUICQpXzZ4ZMJY1wF2XgkhRZUzPQAA/vvoZW3KOplmDV1+uNQOa1b5S48bZ2u/w+efF/u1TEpRAskxKVp8LFrph1AOuQGMnL7NkWgHhiAa/Nj/TzwVndCaWqf/147TQ8XFx9hGcT2P/BLtV2TPqOv8+f6rw39SB+k6oV5a1Djndqch7koPjij1kSaylKtr6V28s4AYeuT8G0/To6OAWOukyfeJPO+L/6gmnVZHje4917NWfXBUJeD6SLDPAvsdP7FKkNhP7HzvRtayLjudjs9iuwUnqDxVrIanZzjxxIseL9MOCTn4VhO5HBwDKYqpcqzlbOlOlfaruGGXdlxeMU9gyiVumg3yeknQXUsQapivYVxUxk8/WjG18x5MwTeVCd7YruCI5nmpiFg41yr4qJA6FoQk9huAXmjoBkliQOFZMmDy8+LT0jsP3d9Cu8amUZnpIePy6Wf+NdgevmnEn/s6157F9iXCOb7MrZAa//UMxOfjphD+5k9DGz7RVr0xDMI15ni42UekjAJKXH9LHCn5+C0csFni+TQR7DNZ4+6BujTnqyx6RFuWc5giHkdvV2+8zb8yJUBZ/AmXDqd766hmfnsEk/PsbL5Se5TI0iGPsQl7dejXu3OcIioSCfcbvDZCVC4SFH4f8tyWF/598mOP0C2mNGe2pvuavNvs0hES/b39ZxiSgT/iq4ys+P7uVufFbibNzxlUhPrK/MjU0kVcbC/BXUf/gvGNT2EfeppZx6Yh9jBwIAN4LK8oCxIKP9HxSryxhHuJtnYtxtraHxc51aHsSrVH7mXZ/iMrPGQfVYzRm/KRyGiYd60vLLiCQQMiDqO5+fZCKFAviHrOXMBsm/IbAMHZZYv3aivSGB2rGE3OKhc1zESnnW6ig/ZKg/bXqYXVzW/eKKs8OOhVXSgCa5H/HZFiq7bsi+AqDjWkU3iC0iM7U674AB2LLn9BEtnKvw2sly4qgCLEUtI/mXpO4d1zf/GAr/CAFQn5SIMAAAA="
};
 const muestra=(clave)=>clave&&(miniaturasPlantillas[clave]||muestras[clave]);
 function exteriorEntradaReciente(boton,ficha,ruta,id,supra=''){
  const principal=catalogoPlantillas[ruta]?.[id];
  const especial=ruta==='atencion-consular'&&id==='mixta'?'consular-cartelera':
   ruta==='interno'&&id==='proyeccion'?'interno-proyeccion':null;
  const opciones=[muestra(ficha.miniatura),muestra(especial),muestra(principal?.miniatura)];
  for(const valor of Object.keys(principal?.variantes||{})){
   opciones.push(muestra(varianteCatalogo(ruta,id,valor)?.miniatura));
  }
  // Si un recurso no se puede cargar, probar otra muestra de la misma ficha.
  const fuentes=[...new Set([...opciones.filter(Boolean),'exterior-32.png'])];
  entradaCatalogo(boton,{...ficha,miniatura:null},supra);
  const imagen=document.createElement('img');
  imagen.alt='';imagen.width=52;imagen.height=64;
  imagen.loading='lazy';imagen.decoding='async';
  imagen.addEventListener('error',()=>{
   const siguiente=fuentes.shift();
   if(siguiente)imagen.src=siguiente;
  });
  imagen.src=fuentes.shift();
  boton.prepend(imagen);
 }
 function renderRecentTemplates(){
  recentList.replaceChildren();clearTemplateHistory.disabled=!recentTemplates.length;
  if(!recentTemplates.length){
   const text=document.createElement('p');text.textContent=preferences.history?'Las plantillas que abras aparecerán aquí.':'El historial está desactivado.';recentList.append(text);return;
  }
  for(const entry of recentTemplates){
   const {ficha,variant}=resolveTemplate(entry),b=document.createElement('button');
   b.type='button';b.className='and-template-card';b.dataset.andTemplate=templateIdentity(entry);
   exteriorEntradaReciente(b,{...(variant||ficha),nombre:ficha.nombre,detalle:variant?.nombre||''},entry.ruta,entry.id);
   b.addEventListener('click',()=>{
    if(stage.hidden)return;
    nav.querySelector('[data-and-nav="crear"]').click();
    abrirEntradaCatalogo(entry.ruta,entry.id,variant?.pasos||[]);
    queueMicrotask(()=>{if(inEditor())homeEntryRoute=entryRouteKey();});
   });
   recentList.append(b);
  }
 }
 let lastTemplate='';
 function recordTemplate(){
  if(!inEditor()){lastTemplate='';return;}
  if(!settingsRestored)return;
  const entry=currentTemplate();if(!entry)return;
  const key=templateIdentity(entry);if(key===lastTemplate)return;lastTemplate=key;
  if(!preferences.history||recentTemplates[0]&&templateIdentity(recentTemplates[0])===key)return;
  recentTemplates=[entry,...recentTemplates.filter(old=>templateIdentity(old)!==key)].slice(0,templateLimit);
  storeTemplates();persistNativeSettings();renderRecentTemplates();
 }
 for(const event of ['change','input'])editor.addEventListener(event,e=>{
  if(eventosDiseno.has(e.target.id)||familiasExterior[$('m').value]?.selector===e.target.id)queueMicrotask(recordTemplate);
 });
 renderRecentTemplates();
 // Inicio orientado a tareas: conservar la identidad y los accesos efectivos.
 const guide=stage.querySelector('.ux-home-guide p');if(guide)guide.textContent='Elegir una plantilla y completar los campos. Revisar la vista previa antes de descargar.';
 const title=$('osStageTitle');title.innerHTML='Generador <span class="and-title-accent">de artes</span>';
 const lead=stage.querySelector('.os-stage-lead');if(lead)lead.hidden=true;
 const overline=stage.querySelector('.os-stage-overline');
 if(overline){overline.textContent='Dirección de Comunicaciones';title.before(overline);}
 const originalForm=$('osHomeSearchForm'),originalResults=$('osHomeSearchResults');
 if(originalForm){
  originalForm.hidden=true;
  if(originalResults)originalResults.hidden=true;
  const searchButton=document.createElement('button');searchButton.type='button';searchButton.className='and-home-search';
  searchButton.innerHTML=svg('buscar')+'<span>Buscar por tema o nombre</span>';
  searchButton.addEventListener('click',()=>openSearch());originalForm.before(searchButton);
 }
 const actions=stage.querySelector('.os-stage-actions'),resume=$('osContinue');
 if(actions&&resume){
  actions.querySelector('[data-os-action="map"]').hidden=true;
  // Continuar sólo cuando el motor tiene una edición abierta.
  resume.textContent='Continuar edición';
  if(actions.contains(resume))actions.prepend(resume);
 }
 const firstHelp=document.createElement('button');firstHelp.type='button';firstHelp.className='and-first-help';
 firstHelp.innerHTML=svg('ayuda')+'<span><strong>¿Cómo crear un arte?</strong><small>Consultar la guía de uso</small></span><span class="and-quick-arrow" aria-hidden="true">›</span>';
 firstHelp.addEventListener('click',()=>{
  help.querySelector('.and-help-description').textContent='Elegir una plantilla del catálogo o buscarla por su nombre. Completar los campos, revisar la vista previa y descargar el arte en el formato disponible.';
  if(!help.open)help.showModal();
 });
 recentSection.after(firstHelp);applyPreferences();
 const oldGuide=stage.querySelector('.ux-home-guide');if(oldGuide)oldGuide.hidden=true;
 // Evitar que la barra tape el campo activo cuando se abre el teclado.
 const vv=window.visualViewport;
 if(vv){const resize=()=>root.classList.toggle('and-keyboard',window.innerHeight-vv.height>150);vv.addEventListener('resize',resize);}
 regionalLanding=inEditor()&&regionalPalette()&&!location.hash.includes('zona=previa');
 setMode(regionalLanding||location.hash.includes('zona=previa')?'preview':'form');sync();restoreNativeSettings();root.classList.add('and-ui-ready');
})();
