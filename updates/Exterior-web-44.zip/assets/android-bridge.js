(function(){
 'use strict';
 const native=window.Capacitor;
 if(!native?.isNativePlatform?.())return;
 const plugin=native.Plugins?.ExteriorFiles||(typeof native.registerPlugin==='function'?native.registerPlugin('ExteriorFiles'):null);
 let ocupado=false,updateShown=false;
 function base64(blob){
  return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=()=>reject(r.error);r.readAsDataURL(blob);});
 }
 async function guardar(blob,nombre){
  if(!plugin)throw Error('El gestor de archivos de Android no está disponible.');
  if(ocupado)throw Error('Hay una descarga en curso.');
  ocupado=true;
  try{
   await plugin.begin({name:nombre,size:blob.size});
   const bloque=256*1024;
   for(let i=0;i<blob.size;i+=bloque){
    const data=await base64(blob.slice(i,Math.min(i+bloque,blob.size)));
    await plugin.append({data});
   }
   await plugin.finish();
  }catch(error){try{await plugin.abort();}catch(_){}throw error;}
  finally{ocupado=false;}
 }
 window.exteriorGuardarAndroid=guardar;
 document.addEventListener('click',event=>{
  const link=event.target.closest?.('a[download]');
  if(!link||!link.href.startsWith('blob:'))return;
  event.preventDefault();event.stopImmediatePropagation();
  const nombre=(link.getAttribute('download')||'Exterior.png').replace(/[\\/:*?"<>|]/g,'_');
  fetch(link.href).then(response=>response.blob()).then(blob=>guardar(blob,nombre)).catch(()=>{});
 },true);

 let local=Number(window.EXTERIOR_ANDROID_VERSION_CODE||1);
 const live=window.exteriorLivePlugin?.();
 const version=String(window.EXTERIOR_ANDROID_VERSION_NAME||local);
 const footer=document.querySelector('#osStage .os-stage-footer');
 if(!footer||!plugin?.checkRelease)return;
 const panel=document.createElement('section');
 panel.className='exterior-android-updates';
 panel.setAttribute('aria-label','Actualizaciones de Exterior');
 const title=document.createElement('strong');title.textContent='Actualizaciones';
 const installed=document.createElement('span');installed.textContent='Versión instalada: '+version;
 const status=document.createElement('p');status.setAttribute('role','status');status.setAttribute('aria-live','polite');status.textContent='Consultar si hay una nueva versión.';
 const controls=document.createElement('div');controls.className='exterior-android-update-actions';
 const check=document.createElement('button');check.type='button';check.textContent='Buscar actualizaciones';
 const update=document.createElement('button');update.type='button';update.textContent='Descargar actualización';update.hidden=true;
 const restore=document.createElement('button');restore.type='button';restore.textContent='Recuperar versión anterior';restore.hidden=true;
 controls.append(check,update,restore);panel.append(title,installed,status,controls);
 function showState(state){
  local=Number(state.binaryVersion||local);
  installed.textContent='Aplicación: 1.0.'+local+' · Recursos: 1.0.'+Number(state.contentVersion||local);
  const label=document.getElementById('andVersion');if(label)label.textContent='1.0.'+local;
  restore.hidden=!state.canRestore;
 }
 function showPending(state){
  panel.dataset.andNews='true';
  status.textContent='Recursos 1.0.'+state.pendingVersion+' preparados. Finalizar la edición y volver a abrir Exterior.';
  check.textContent='Buscar actualizaciones';
 }
 if(live?.info)live.info().then(state=>{showState(state);if(state.restoreRequested)status.textContent='Restauración preparada. Finalizar la edición y volver a abrir Exterior.';else if(state.pendingVersion>0)showPending(state);}).catch(()=>{});
 footer.insertBefore(panel,footer.querySelector('.ux-home-guide'));
 let checking=false,latest=null,lastCheck=0,noticeVersion=0;
 async function comprobar(manual=false){
  if(checking||update.disabled||restore.disabled||(!manual&&Date.now()-lastCheck<60000))return;
  checking=true;lastCheck=Date.now();check.disabled=true;update.hidden=true;latest=null;panel.dataset.andNews='false';
  status.textContent='Buscando actualizaciones…';
  let pending=null;
  try{
   if(live){
    const state=await live.info();showState(state);
    if(state.restoreRequested){status.textContent='Restauración preparada. Finalizar la edición y volver a abrir Exterior.';return;}
    if(state.pendingVersion>0)pending=state;
    const resource=await live.check();showState(resource);
    if(resource.available===true){
     latest={...resource,kind:'resources'};panel.dataset.andNews='true';
     status.textContent='Recursos 1.0.'+resource.versionCode+' disponibles ('+Math.ceil(Number(resource.size)/1048576)+' MB). Incluyen las mejoras anteriores. No requieren instalar una APK.';
     update.textContent='Preparar actualización interna';update.hidden=false;
     if(!manual)check.textContent='Nueva versión disponible';
     return;
    }
    if(!resource.requiresApk){
     if(pending){showPending(pending);return;}
     status.textContent=state.failedVersion>0?'Se recuperó una versión anterior. Se esperará una nueva publicación compatible.':'Exterior está actualizado.';
     return;
    }
   }
   const data=await plugin.checkRelease();
   if(data?.available===true&&Number(data.versionCode)>local&&typeof data.apkUrl==='string'&&data.apkUrl){
    latest={...data,kind:'apk'};panel.dataset.andNews='true';update.textContent='Descargar actualización';status.textContent='Versión '+String(data.versionName||data.versionCode)+' disponible.'+(live?' Requiere actualizar la aplicación Android.':'');
    update.hidden=false;
    if(!manual&&noticeVersion!==Number(data.versionCode)&&!document.getElementById('osStage')?.hidden){
     noticeVersion=Number(data.versionCode);check.textContent='Nueva versión disponible';
    }
   }else if(data?.published===true&&data?.signed===true&&data?.compatible===false){
    status.textContent='La firma ha cambiado. Descargar Exterior desde la página web y reinstalar si Android lo solicita.';
   }else if(data?.published===true&&data?.signed===true&&data?.compatible===true&&Number(data.versionCode)===local){
    status.textContent='Exterior está actualizado.';
   }else if(data?.published===true&&data?.signed!==true){
    status.textContent='La firma de distribución aún no está disponible.';
   }else{
    status.textContent='No hay una actualización compatible disponible.';
   }
  }catch(_){if(pending)showPending(pending);else status.textContent=live?'No se pudo verificar la actualización. Se conserva la versión actual.':'No se pudo consultar. Volver a intentar cuando haya conexión.';}
  finally{checking=false;check.disabled=false;if(check.textContent!=='Nueva versión disponible'||!latest)check.textContent='Buscar actualizaciones';}
 }
 check.addEventListener('click',()=>{check.textContent='Buscar actualizaciones';comprobar(true);});
 update.addEventListener('click',async()=>{
  if(!latest)return;
  update.disabled=true;check.disabled=true;restore.disabled=true;
  try{
   if(latest.kind==='resources'){
    status.textContent='Consultando la versión más reciente…';
    const current=await live.check();
    if(!current.available){
     if(current.pendingVersion>0&&!current.requiresApk){showState(current);showPending(current);latest=null;update.hidden=true;return;}
     throw Error('La publicación cambió.');
    }
    status.textContent='Descargando y verificando recursos 1.0.'+current.versionCode+'…';
    const state=await live.download({versionCode:Number(current.versionCode)});
    showState(state);showPending(state);latest=null;update.hidden=true;
   }else{await plugin.openUpdate({url:latest.apkUrl});status.textContent='Continuar la instalación desde Android.';}
  }
  catch(_){status.textContent='No se pudo preparar la actualización. Consultar la versión más reciente y volver a intentar.';}
  finally{update.disabled=false;check.disabled=false;restore.disabled=false;}
 });
 restore.addEventListener('click',async()=>{
  if(!live||!window.confirm('¿Recuperar la versión anterior de los recursos al volver a abrir Exterior?'))return;
  check.disabled=true;update.disabled=true;restore.disabled=true;
  try{await live.restore();latest=null;update.hidden=true;status.textContent='Restauración preparada. Finalizar la edición y volver a abrir Exterior.';}
  catch(_){status.textContent='No se pudo preparar la restauración.';}
  finally{check.disabled=false;update.disabled=false;restore.disabled=false;}
 });
 // Comprobar sin interrumpir el arte que se está editando.
 setTimeout(()=>comprobar(),2200);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)comprobar();});
})();
