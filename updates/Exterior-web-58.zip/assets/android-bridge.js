(function(){
 'use strict';
 const native=window.Capacitor;
 if(!native?.isNativePlatform?.())return;
 const plugin=native.Plugins?.ExteriorFiles||(typeof native.registerPlugin==='function'?native.registerPlugin('ExteriorFiles'):null);
 let queue=Promise.resolve(),statusTimer;
 const saveStatus=document.createElement('div');saveStatus.className='and-save-status';saveStatus.setAttribute('role','status');saveStatus.setAttribute('aria-live','polite');saveStatus.hidden=true;document.body.append(saveStatus);
 function reportSave(message,error=false,done=false){
  clearTimeout(statusTimer);saveStatus.textContent=message;saveStatus.hidden=false;saveStatus.classList.toggle('and-save-error',error);
  if(done)statusTimer=setTimeout(()=>{saveStatus.hidden=true;},error?8500:4500);
 }
 function base64(blob){
  return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=()=>reject(r.error);r.onabort=()=>reject(Error('Lectura cancelada.'));r.readAsDataURL(blob);});
 }
 async function writeFile(blob,nombre){
  let begun=false;
  try{
   if(!plugin||typeof plugin.begin!=='function')throw Error('El gestor de archivos de Android no está disponible.');
   if(!(blob instanceof Blob)||!blob.size)throw Error('El archivo está vacío.');
   const extension=String(nombre||'').toLowerCase().split('.').pop();
   if((extension==='png'||extension==='zip')&&blob.size>20_000_000)throw Error('Los artes PNG y ZIP no pueden superar 20 MB.');
   nombre=String(nombre||'Exterior.png').replace(/[\\/:*?"<>|\u0000-\u001f]/g,'_').trim();
   if(nombre.length>180){const dot=nombre.lastIndexOf('.');const ext=dot>=0?nombre.slice(dot):'';nombre=nombre.slice(0,180-ext.length)+ext;}
   reportSave('Guardando '+nombre+'…');
   await plugin.begin({name:nombre,size:blob.size});begun=true;
   const bloque=256*1024;
   for(let i=0;i<blob.size;i+=bloque){
    const data=await base64(blob.slice(i,Math.min(i+bloque,blob.size)));
    await plugin.append({data});
   }
   await plugin.finish();begun=false;
   reportSave('Archivo guardado en Descargas/Exterior: '+nombre,false,true);
  }catch(error){
   if(begun)try{await plugin.abort();}catch(_){}
   const failure=new Error(error?.message||'Volver a intentar.');
   failure.code=error?.code||'ANDROID_SAVE_FAILED';
   failure.exteriorSave=true;
   reportSave('No se pudo guardar el archivo. '+failure.message,true,true);
   throw failure;
  }
 }
 function guardar(blob,nombre){
  const job=queue.then(()=>writeFile(blob,nombre));
  queue=job.catch(()=>{});
  return job;
 }
 window.exteriorGuardarAndroid=guardar;
 // El motor PNG crea enlaces desconectados del DOM. Interceptar el guardado
 // directamente, esperar la escritura nativa y conservar el lote secuencial.
 if(typeof window.guardarPng==='function')window.guardarPng=(nombre,blob)=>guardar(blob,nombre);
 // Compatibilidad con enlaces de descarga conectados al documento.
 document.addEventListener('click',event=>{
  const link=event.target.closest?.('a[download]');
  if(!link||!(/^(blob:|data:)/.test(link.href)))return;
  event.preventDefault();event.stopImmediatePropagation();
  const nombre=link.getAttribute('download')||'Exterior.png';
  fetch(link.href).then(response=>response.blob()).then(blob=>guardar(blob,nombre)).catch(error=>{
   if(!error?.exteriorSave)reportSave('No se pudo leer el archivo para guardarlo.',true,true);
  });
 },true);

 let local=Number(window.EXTERIOR_ANDROID_VERSION_CODE||1);
 const live=window.exteriorLivePlugin?.();
 const canCheckApk=typeof plugin?.checkRelease==='function';
 const version=String(window.EXTERIOR_ANDROID_VERSION_NAME||local);
 const footer=document.querySelector('#osStage .os-stage-footer');
 if(!footer||(!live&&!canCheckApk))return;
 const panel=document.createElement('section');
 panel.className='exterior-android-updates';
 panel.setAttribute('aria-label','Actualizaciones de Exterior');
 const title=document.createElement('strong');title.textContent='Actualizaciones';
 const installed=document.createElement('span');installed.textContent='Versión instalada: '+version;
 const status=document.createElement('p');status.setAttribute('role','status');status.setAttribute('aria-live','polite');status.textContent='Consultar si hay una nueva versión.';
 const apkStatus=live?document.createElement('p'):status;
 if(live){apkStatus.className='and-apk-release-status';apkStatus.setAttribute('aria-live','polite');apkStatus.hidden=true;}
 const progressBox=document.createElement('div');progressBox.className='and-update-progress';progressBox.hidden=true;
 const progressLabel=document.createElement('span');progressLabel.className='and-update-progress-label';
 const progressBar=document.createElement('progress');progressBar.max=100;progressBar.setAttribute('aria-label','Avance de la actualización');
 progressBox.append(progressLabel,progressBar);
 let progressKind='',busy=false;
 function beginProgress(kind){
  progressKind=kind;progressBox.hidden=false;progressBar.removeAttribute('value');progressLabel.textContent='Preparando descarga…';
 }
 function endProgress(){progressKind='';progressBox.hidden=true;}
 function reportProgress(kind,event){
  if(!busy||progressKind!==kind)return;
  const total=Number(event.total),written=Math.max(0,Number(event.written)||0);
  if(event.phase==='download'){
   if(total>0&&Number.isFinite(total)){const percent=Math.min(100,Math.floor(written*100/total));progressBar.value=percent;progressLabel.textContent='Descargando · '+percent+' %';}
   else{progressBar.removeAttribute('value');progressLabel.textContent='Descargando · '+(written/1048576).toFixed(1)+' MB';}
  }else{progressBar.removeAttribute('value');progressLabel.textContent=event.phase==='verify'?'Verificando integridad y firma…':event.phase==='prepare'?'Preparando recursos…':'Preparando actualización…';}
 }
 try{Promise.resolve(live?.addListener?.('updateProgress',event=>reportProgress('resources',event))).catch(()=>{});}catch(_){}
 try{Promise.resolve(plugin?.addListener?.('apkInstallProgress',event=>reportProgress('apk',event))).catch(()=>{});}catch(_){}
 const controls=document.createElement('div');controls.className='exterior-android-update-actions';
 const check=document.createElement('button');check.type='button';check.textContent='Buscar actualizaciones';
 const update=document.createElement('button');update.type='button';update.textContent='Descargar actualización';update.hidden=true;
 const apkUpdate=document.createElement('button');apkUpdate.type='button';apkUpdate.textContent='Instalar actualización';apkUpdate.hidden=true;
 const official=document.createElement('a');official.className='and-update-website';official.href='https://g-polex.github.io/';official.textContent='Abrir la web oficial';official.hidden=true;
 const restart=document.createElement('button');restart.type='button';restart.textContent='Reiniciar y aplicar';restart.hidden=true;
 check.className='and-update-check';update.className='and-update-install';restart.className='and-update-install';apkUpdate.className='and-update-install and-apk-install';
 controls.append(check,update,restart,apkUpdate,official);panel.append(title,installed,status);
 if(live)panel.append(apkStatus);
 panel.append(progressBox,controls);
 function hasEdition(){return document.querySelector('.and-nav [data-and-nav="editar"]:not([disabled])')!==null;}
 function allowRestart(){return !hasEdition()||window.confirm('Actualizar Exterior cerrará la edición. Descarga o finaliza el arte antes de continuar. ¿Continuar con la actualización?');}
 function lockActions(locked){
  busy=locked;
  for(const control of [check,update,apkUpdate,restart])control.disabled=locked;
 }
 function showRestore(){panel.dataset.andNews='true';status.textContent='Restauración preparada. Reiniciar Exterior para aplicarla.';restart.hidden=typeof live?.restart!=='function';}
 restart.addEventListener('click',async()=>{
  if(busy||checking||!allowRestart())return;
  lockActions(true);
  status.textContent='Reiniciando Exterior…';
  try{await live.restart();}catch(_){status.textContent='No se pudo reiniciar automáticamente. Cerrar y volver a abrir Exterior.';}
  finally{lockActions(false);}
 });
 function showState(state){
  local=Number(state.binaryVersion||local);
  installed.textContent='Aplicación: 1.0.'+local+' · Recursos: 1.0.'+Number(state.contentVersion||local);
  const label=document.getElementById('andVersion');if(label)label.textContent='1.0.'+local;
  const resourceLabel=document.getElementById('andResourcesVersion');if(resourceLabel)resourceLabel.textContent='1.0.'+Number(state.contentVersion||local);

 }
 function showPending(state){
  panel.dataset.andNews='true';
  const canRestart=typeof live?.restart==='function';
  status.textContent='Recursos 1.0.'+state.pendingVersion+' preparados. '+(canRestart?'Reiniciar Exterior para aplicar la actualización.':'Finalizar la edición y volver a abrir Exterior.');
  restart.hidden=!canRestart;
  check.textContent='Buscar actualizaciones';
 }
 if(live?.info)live.info().then(state=>{showState(state);if(state.restoreRequested)showRestore();else if(state.pendingVersion>0)showPending(state);}).catch(()=>{});
 footer.insertBefore(panel,footer.querySelector('.ux-home-guide'));
 let checking=false,latest=null,apkVersion=0,lastCheck=0;
 async function checkApk(){
  if(!canCheckApk)return;
  official.hidden=true;apkUpdate.hidden=true;apkVersion=0;
  apkStatus.hidden=false;
  apkStatus.textContent='Consultando la versión Android…';
  try{
   const release=await plugin.checkRelease();
   const installedCode=Number(release.installedVersionCode||local);
   if(release.status==='security-review'){
    apkStatus.textContent='La descarga de la aplicación Android está suspendida por revisión de seguridad.';
   }else if(release.available===true&&Number(release.versionCode)>installedCode){
    return release;
   }else if(release.available===true){
    apkStatus.textContent='La aplicación Android está actualizada.';
   }else if(release.published===true&&release.verified===true&&release.supported===false){
    apkStatus.textContent='La versión publicada requiere un Android más reciente.';
   }else if(release.published===true){
    apkStatus.textContent='No se pudo verificar la actualización Android. Se conserva la versión actual.';
   }else{
    apkStatus.textContent='No hay una actualización Android disponible.';
   }
  }catch(_){apkStatus.textContent='No se pudo consultar la versión Android. Volver a intentar cuando haya conexión.';}
 }
 async function comprobar(manual=false){
  if(busy||checking||update.disabled||(!manual&&Date.now()-lastCheck<60000))return;
  checking=true;lastCheck=Date.now();check.disabled=true;apkUpdate.disabled=true;update.disabled=true;restart.disabled=true;
  update.hidden=true;restart.hidden=true;latest=null;panel.dataset.andNews='false';
  status.textContent='Buscando actualizaciones…';
  const apkCheck=checkApk();
  let pending=null,compatibleResourceVersion=0;
  try{
   if(live){
    const state=await live.info();showState(state);
    if(state.restoreRequested){showRestore();return;}
    if(state.pendingVersion>0)pending=state;
    const resource=await live.check();showState(resource);
    const resourceVersion=Number(resource.versionCode);
    if(resource.compatible===true&&(resource.available===true||Number(resource.pendingVersion)===resourceVersion||Number(resource.contentVersion)>=resourceVersion)){
     compatibleResourceVersion=resourceVersion;
    }
    if(resource.available===true){
     latest={...resource,kind:'resources'};panel.dataset.andNews='true';
     status.textContent='Recursos 1.0.'+resource.versionCode+' disponibles ('+Math.ceil(Number(resource.size)/1048576)+' MB). Incluyen las mejoras anteriores. No requieren instalar una APK.';
     update.textContent='Preparar actualización interna';update.hidden=false;

     return;
    }
    if(!resource.requiresApk){
     if(pending){showPending(pending);return;}
     status.textContent=state.failedVersion>0?'Se recuperó una versión anterior. Se esperará una nueva publicación compatible.':'Los recursos de Exterior están actualizados.';
     return;
    }
   }
   if(pending){showPending(pending);return;}
   if(live)status.textContent='Esta mejora requiere una nueva versión de la aplicación Android.';
  }catch(_){if(pending)showPending(pending);else status.textContent='No se pudo verificar la actualización de recursos. Se conserva la versión actual.';}
  finally{
   const release=await apkCheck;
   if(release){
    const candidate=Number(release.versionCode);
    if(candidate===compatibleResourceVersion){
     apkStatus.hidden=true;
    }else{
     panel.dataset.andNews='true';
     apkStatus.textContent='Exterior '+release.versionName+' está disponible para Android.'+(release.releaseNotes?' '+release.releaseNotes:'');
     if(release.installerEnabled===true&&typeof plugin.installUpdate==='function'){
      apkVersion=candidate;apkUpdate.hidden=false;
     }else official.hidden=false;
    }
   }
   checking=false;lockActions(false);check.textContent='Buscar actualizaciones';
  }
 }
 check.addEventListener('click',()=>{check.textContent='Buscar actualizaciones';comprobar(true);});
 apkUpdate.addEventListener('click',async()=>{
  if(!apkVersion||busy||checking||!allowRestart())return;
  lockActions(true);
  apkStatus.textContent='Verificando la publicación oficial…';
  beginProgress('apk');
  try{
   const result=await plugin.installUpdate({versionCode:apkVersion});
   if(result?.permissionRequired===true){
    apkStatus.textContent='Si autorizas a Exterior en los ajustes de instalación de Android, vuelve y pulsa «Instalar actualización» para continuar.';
   }else if(result?.installerOpened===true){
    apkStatus.textContent='Descarga verificada. Confirma la instalación en Android.';
    apkVersion=0;apkUpdate.hidden=true;
   }else throw Error('El instalador de Android no se abrió.');
  }catch(error){
   const details={APK_MANIFEST:'La actualización no está disponible o ya cambió. Vuelve a buscar actualizaciones.',APK_PERMISSION:'No se pudieron abrir los ajustes de instalación de Android.',APK_STORAGE:'Comprueba el espacio disponible en el dispositivo.',APK_DOWNLOAD:'La descarga no se completó. Comprueba la conexión y el espacio disponible.',APK_INTEGRITY:'La descarga no superó la verificación de integridad, firma o versión.',APK_INSTALL:'No se pudo abrir el instalador de Android. Vuelve a Exterior e inténtalo de nuevo.'};
   apkStatus.textContent=details[error?.code]||'No se pudo preparar la actualización de Android.';
   if(error?.code==='APK_MANIFEST'){apkVersion=0;apkUpdate.hidden=true;}
  }finally{endProgress();lockActions(false);}
 });
 update.addEventListener('click',async()=>{
  if(!latest||busy||checking)return;
  if(latest.kind!=='resources')return;
  lockActions(true);
  try{
   if(latest.kind==='resources'){
    status.textContent='Consultando la versión más reciente…';
    const current=await live.check();
    if(!current.available){
     if(current.pendingVersion>0&&!current.requiresApk){showState(current);showPending(current);latest=null;update.hidden=true;return;}
     throw Error('La publicación cambió.');
    }
    status.textContent='Descargando y verificando recursos 1.0.'+current.versionCode+'…';
    beginProgress('resources');
    const state=await live.download({versionCode:Number(current.versionCode)});
    showState(state);showPending(state);latest=null;update.hidden=true;
   }
  }
  catch(error){
   const details={UPDATE_MANIFEST:'No se pudo verificar la publicación.',UPDATE_VERSION:'La publicación cambió. Consultar la versión más reciente.',UPDATE_STORAGE:'Comprobar el espacio disponible en el dispositivo.',UPDATE_DOWNLOAD:'No se completó la descarga. Comprobar la conexión.',UPDATE_INTEGRITY:'La descarga no superó la verificación de integridad.',UPDATE_EXTRACTION:'No se pudieron extraer los recursos.',UPDATE_STAGING:'No se pudieron preparar los recursos en el dispositivo.'};
   status.textContent=(details[error?.code]||'No se pudo preparar la actualización.')+' Se conserva la versión actual.';
  }
  finally{endProgress();lockActions(false);}
 });
 // Comprobar sin interrumpir el arte que se está editando.
 setTimeout(()=>comprobar(),2200);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)comprobar();});
})();
