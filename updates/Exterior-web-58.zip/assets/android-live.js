(function(){
 'use strict';
 const root=document.documentElement;
 // Este script se ejecuta en head, antes de construir la portada web.
 // Mantener la superficie azul hasta que Android haya terminado de componer Inicio.
 root.classList.add('and-starting');
 let startupTimeout=0;
 const started=()=>root.classList.contains('and-ui-ready');
 function finishStartup(){
  if(!started())return;
  clearTimeout(startupTimeout);
  document.querySelector('.and-startup-error')?.remove();
  root.classList.remove('and-starting');
 }
 const startupObserver=new MutationObserver(()=>{
  if(started()){startupObserver.disconnect();finishStartup();}
 });
 startupObserver.observe(root,{attributes:true,attributeFilter:['class']});
 // No bloquear indefinidamente si un recurso falla. El mecanismo nativo
 // conserva su comprobación de integridad y reversión independiente.
 startupTimeout=setTimeout(()=>{
  if(started()){finishStartup();return;}
  if(!document.body)return;
  const panel=document.createElement('section');panel.className='and-startup-error';panel.setAttribute('role','alert');
  const title=document.createElement('strong');title.textContent='No se pudo iniciar Exterior.';
  const detail=document.createElement('p');detail.textContent='Volver a intentar la apertura de la aplicación.';
  const button=document.createElement('button');button.type='button';button.textContent='Reintentar';button.addEventListener('click',()=>location.reload());
  panel.append(title,detail,button);document.body.append(panel);
 },20000);
 let failed=false;
 // A resource error or uncaught startup error prevents acknowledgment of a new bundle.
 window.addEventListener('error',event=>{
  const tag=event.target?.tagName;
  if(event instanceof ErrorEvent||tag==='SCRIPT'||tag==='LINK')failed=true;
 },true);
 window.addEventListener('unhandledrejection',()=>{failed=true;});
 window.exteriorLivePlugin=function(){
  const native=window.Capacitor;
  if(!native?.isNativePlatform?.())return null;
  if(native.isPluginAvailable&&!native.isPluginAvailable('ExteriorUpdates'))return null;
  return native.Plugins?.ExteriorUpdates||(native.isPluginAvailable?.('ExteriorUpdates')?native.registerPlugin('ExteriorUpdates'):null);
 };
 window.addEventListener('load',()=>{
  const plugin=window.exteriorLivePlugin();if(!plugin?.ready)return;
  const started=Date.now();
  function acknowledge(){
   if(failed)return;
   const ready=document.documentElement.classList.contains('and-ui-ready')&&
    document.querySelectorAll('#osFamilyList button[data-os-family]').length===8&&
    typeof window.exteriorGuardarAndroid==='function'&&typeof abrirEntradaCatalogo==='function';
   if(ready){
    plugin.ready({versionCode:Number(window.EXTERIOR_ANDROID_VERSION_CODE)}).catch(()=>{});
   }else if(Date.now()-started<30000)setTimeout(acknowledge,150);
  }
  setTimeout(acknowledge,500);
 },{once:true});
})();
